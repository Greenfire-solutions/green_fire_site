# Catalog

Everything in this kit, one line each. BUILD MY DASHBOARD reads this first, then
opens the pieces that fit the business. Add a line here for anything you build.

## HQ, the command center (`app/`, opens with START HERE)

| Agent | What it does |
|---|---|
| Inbox Concierge | Reads the inbox (read only), sorts each message to an offer, drafts the reply for your yes |
| Audience Scout | Searches the web for the people who buy each offer; keeps only addresses printed on their own site |
| Pitch Writer | Writes the first letter to each prospect in your voice, from your credentials only |
| Follow-up Keeper | Nudges at 3 weeks and 6 weeks, then stops |
| Application Scribe | Fills applications and guest forms in a Chrome window you can watch |
| Studio | Turns photos and clips from Drop Media Here into scheduled posts, with Comment-to-get |
| Chief of Staff | The morning brief and the "What do you want to do?" box |

Code map: `app/lib/agents.mjs` (the agents), `guards.mjs` (checks on every outgoing word),
`voice.mjs` (caption rules), `mail/` (IMAP and SMTP), `forms.mjs` and `browser.mjs`
(form filling), `router.mjs` (plain-words requests to the right agent or skill).

## Skills (`.claude/skills/`, Claude Code uses them by name)

| Skill | What it is for |
|---|---|
| `audience-finder` | Find the exact people who buy each of the owner's projects, strategically, and only with addresses that are really theirs. |
| `capcut-music-video` | Direct a music video end-to-end in CapCut Desktop by writing the project's draft JSON — analyze the song's BPM/beat grid/structure, triage footage with vision + metrics, design a beat-locked edit with an energy curve,... |
| `connecting-channels` | Connect the owner's social posting channels (Instagram, Facebook Page, Bluesky, Zapier for TikTok/LinkedIn/YouTube) and the media hosting Instagram needs, so HQ's Studio can publish approved posts. |
| `event-flyers` | Turn the posters for any event, workshop, retreat, training or keynote into readable 3D animated flyers cut to the beat of licensed music, then hand them to HQ's Studio to post as videos, at most two a week per event. |
| `form-filler` | How HQ's Application Scribe reads and fills speaker applications, calls for speakers, podcast guest forms and contact forms in a visible Chrome window, answers from the owner's kit, asks every unanswerable question on... |
| `hq-troubleshooting` | Fix the things that go wrong when HQ is installed on a new Mac or stops doing something - the START HERE button doing nothing, "unidentified developer", Node missing, the page not opening, email not connecting, Claude... |
| `inbound-email-desk` | How HQ's Inbox Concierge reads the owner's mailbox, sorts every message by project and intent, drafts the reply in the owner's voice with the right offer, and makes sure no booking or speaking inquiry is ever lost. |
| `launch-a-project` | Add a new line of business to HQ (an instructor training, a retreat, a course, a membership, a brand partnership, a new product or venture) so every agent works it alongside the others - the interview questions, the o... |
| `local-service-identity` | Make a local service prove who it is before anything opens, reuses, writes to, tests against or reports on it. |
| `mac-ui-control` | Control any macOS app from the terminal - click, double-click, right-click, drag, scroll, type text, send key combos, and inspect what UI element is under a screen point. |
| `measured-not-inferred` | Keep measured facts, inferred estimates and assumptions apart, and refuse to quote a number that its sample size cannot support. |
| `outreach-letters` | Write and run the owner's outreach letters: one standard letter per audience, a personal first line from real research, the follow-up clock (three weeks, six weeks, then stop), daily caps that hold instead of refusing... |
| `post-in-my-voice` | Write and schedule social posts that sound like the owner, carry one real thought, end with an honest question, and turn attention into sales with Comment-to-get. |
| `prove-the-page-runs` | Prove a web page, dashboard or operator UI actually executes and renders, instead of proving that a string exists in its HTML. |
| `speaker-booking` | Run a speaking engagement from first inquiry to paid and referred, the way a professional speaker's office does - qualify, quote, hold, contract, deposit, advance, show day, invoice, thank-you, testimonial, referral. |

## Specialist agents (`.claude/agents/`, reviewers and testers)

| Agent | What it checks |
|---|---|
| `adoption-critic` | Judges a page, a flow or a whole site by whether a real, busy, non-technical person would actually use it - not whether it works. |
| `claim-warden` | Reads any text about to leave the owner's hands (a standard letter, a speaker one-pager, a website page, a bio, a caption, a podcast pitch, a partner deck) and blocks the claims that would cost trust or create legal r... |
| `filter-and-gate-reviewer` | Hunts the one class of bug nobody ever notices, a filter or a gate that is wrong in the DELETING direction and fails silently. |
| `hq-button-prover` | Proves every button and form in HQ's dashboard actually does something, by loading each page in headless Chrome against a sandbox HQ (port 8412, throwaway data, fake AI, nothing sent), pressing the controls, and check... |
| `hq-health` | Proves HQ actually works right now by running it - the test suite in a sandbox, the live server's identity, the setup steps, the last run of every agent, failed posts, stuck forms, unanswered inquiries, the mail check... |
| `outreach-readiness` | Answers the one question that decides whether an outreach wave helps or hurts - is this actually ready to put in front of these people today. |
| `post-voice-critic` | Reads a batch of captions (waiting in Studio, or pasted) the way the owner's audience would, and judges whether each sounds like the owner, carries a real thought, ends with a question worth answering, and moves someo... |
| `prospect-scout` | Researches one high-value target (a conference, a company's wellbeing program, a speaker bureau, a podcast, a pilot partner, a brand) from public sources and returns what actually decides the outcome - a fit thesis gr... |
| `warm-intro-mapper` | Finds the warm path from the owner to a target organisation or person, because for big stages, big partners and investors the introduction is the whole game and a found email is the weakest approach. |

## Workflows (`Playbooks/`)

| Playbook | What it is |
|---|---|
| `01 How the System Sells.md` | The weekly loop: who buys, find them, one letter, two follow-ups, answer everyone, post, read the week |
| `02 The Business Interview.md` | The ten questions BUILD MY DASHBOARD asks when there is no Project Brief |

## Automations that run by themselves (in HQ, each one off until you turn it on)

| Automation | When |
|---|---|
| Inbox read and sort | Every few minutes while HQ is open |
| Audience Scout round | Daily, one audience per run |
| Follow-ups | Daily, at 3 and 6 weeks |
| Posts | At their scheduled time, after your yes |
| Comment-to-get DMs | Off by default; when on, answers keyword comments with one private link |
| Morning brief | Each morning |
