#!/bin/bash
# Stops HQ. Only the HQ that runs from THIS folder, never anything else on the port.
ROOT="$(cd "$(dirname "$0")" && pwd)"
J=$(/usr/bin/curl -s --max-time 3 http://127.0.0.1:8410/api/whoami)
if echo "$J" | /usr/bin/grep -q '"app":"greenfire-hq"' && echo "$J" | /usr/bin/grep -qF "\"root\":\"$ROOT\""; then
  PID=$(echo "$J" | /usr/bin/sed -n 's/.*"pid":\([0-9]*\).*/\1/p')
  kill "$PID" && echo "HQ stopped. Double-click START HERE to start it again."
else
  echo "HQ is not running from this folder."
fi
sleep 2
