// HQ: the local server. One owner, one Mac, every project.
//
//   node server.mjs           serves http://127.0.0.1:8410
//   HQ_PORT=8412              tests use their own port
//   HQ_DATA=/some/folder      where the data lives (default ~/Documents/Greenfire HQ Data)
//   HQ_NO_OUTWARD=1           nothing leaves the Mac (no mail, posts, webhooks)
//   HQ_FAKE_AI=1              a fake brain, for tests
//
// The promise on every card holds here: nothing is emailed, posted or
// submitted unless the owner approved that exact card. The scheduler only
// publishes posts already approved, at the time they were approved for.

import { createServer } from 'node:http';
import { readFileSync, existsSync, createReadStream, statSync, copyFileSync, writeFileSync, mkdirSync, readdirSync, rmSync } from 'node:fs';
import { join, extname, normalize } from 'node:path';
import { spawn } from 'node:child_process';

import { APP, ROOT, DATA, DROP, SITE, PLAYBOOKS, PORT, APP_ID, LOGS, ensureDirs } from './lib/paths.mjs';
import { open, stamp, today, j } from './lib/db.mjs';
import { PROFILE, PROJECTS, PROJECT_TEMPLATES } from './lib/seed.mjs';
import { readSecrets, saveSecret, forgetSecret, secretShape } from './lib/secrets.mjs';
import { AGENTS, runAgent, approve, replyTo, markSubmitted, carryHeld, publishDue, guardInbox, prepareForm, profileOf, projectsOf, aiCfg, card, writeCaption } from './lib/agents.mjs';
import { PROVIDERS as AI_PROVIDERS, connectionTest, cliStatus, complete, parseJson, frame } from './lib/ai.mjs';
import { CHANNELS, testChannel } from './lib/connections.mjs';
import { PROVIDERS as MAIL_PROVIDERS, testMailbox } from './lib/mail/mailbox.mjs';
import { route, teamList } from './lib/router.mjs';
import { tick as keywordTick } from './lib/keywords.mjs';
import { hostReady, ffmpegPath } from './lib/media.mjs';
import { chromeInstalled } from './lib/browser.mjs';
import { untrusted, noDashes } from './lib/guards.mjs';

const DRY = process.env.HQ_NO_OUTWARD === '1';
const STARTED = new Date().toISOString();
ensureDirs();
const db = open(join(DATA, 'hq.db'));

// First run: the owner's profile and projects, read from their own pages.
if (!db.setting('profile')) {
  db.setSetting('profile', PROFILE);
  for (const p of PROJECTS) db.insert('projects', p);
  db.setSetting('autopilot', { inbox: true, inbox_minutes: 5, studio: true, brief: true, brief_hour: 8, writer: true, chaser: true, scout: true, scout_days: [1, 3, 5], keywords: false });
  db.log('setup', 'First run: profile and projects loaded from the owner\'s website.');
}

const notify = (title, msg) => {
  if (DRY) return;
  const esc = s => String(s || '').replace(/["\\]/g, '').slice(0, 180);
  spawn('/usr/bin/osascript', ['-e', `display notification "${esc(msg)}" with title "HQ" subtitle "${esc(title)}" sound name "Glass"`], { stdio: 'ignore', detached: true }).unref();
};
const ctx = { db, notify };
const httpErr = (status, message) => Object.assign(new Error(message), { status });
const autopilot = () => ({ inbox: true, inbox_minutes: 5, studio: true, brief: true, brief_hour: 8, writer: true, chaser: true, scout: true, scout_days: [1, 3, 5], keywords: false, ...db.setting('autopilot', {}) });

// ------------------------------------------------------------------ setup steps
// Each step CHECKS the real state rather than trusting a ticked box, so the
// checklist can never say "done" about something that is not.
function steps(cli) {
  const P = profileOf(db), sec = readSecrets();
  const channels = Object.keys(CHANNELS).filter(k => CHANNELS[k].posts && sec[k] && Object.keys(sec[k]).length);
  return [
    { id: 'profile', title: 'Check what HQ already knows about you', done: !!db.setting('profile:confirmed') },
    { id: 'ai', title: 'Connect your Claude account', done: aiCfg(db).provider !== 'none', detail: cli?.claude ? (cli.claude.signedIn ? 'Claude is installed and signed in.' : cli.claude.installed ? 'Claude is installed, not signed in yet.' : 'Claude is not installed yet.') : '' },
    { id: 'projects', title: 'Choose your projects', done: !!db.setting('projects:reviewed') },
    { id: 'mail', title: 'Connect your email', done: !!(sec.mail?.address && sec.mail?.pass) },
    { id: 'voice', title: 'Teach it how you sound', done: (P.samples || []).length >= 3 && !!db.setting('voice:confirmed') },
    { id: 'socials', title: 'Connect your social accounts', done: channels.length > 0, detail: channels.join(', ') },
    { id: 'links', title: 'Booking and payment links', done: !!db.setting('links:confirmed') },
    { id: 'autopilot', title: 'Decide what runs by itself', done: !!db.setting('autopilot:confirmed') },
    { id: 'website', title: 'See your new website', done: !!db.setting('website:seen') },
  ];
}

let cliCache = { at: 0, v: null };
async function cli() {
  if (Date.now() - cliCache.at < 60000 && cliCache.v) return cliCache.v;
  const [claude, chatgpt] = await Promise.all([cliStatus('claude'), cliStatus('chatgpt')]);
  cliCache = { at: Date.now(), v: { claude, chatgpt } };
  return cliCache.v;
}

async function state() {
  const c = await cli();
  const sec = readSecrets();
  return {
    today: today(), dry: DRY,
    profile: profileOf(db),
    projects: projectsOf(db, true),
    templates: PROJECT_TEMPLATES,
    cards: db.all('cards', "WHERE status IN ('waiting','held','working','failed') OR (done_at >= datetime('now','localtime','-2 days')) ORDER BY CASE kind WHEN 'alert' THEN 0 WHEN 'reply' THEN 1 ELSE 2 END, id DESC LIMIT 300"),
    contacts: db.all('contacts', 'WHERE duplicate_of IS NULL ORDER BY id DESC LIMIT 1500'),
    messages: db.all('messages', 'ORDER BY id DESC LIMIT 120'),
    posts: db.all('posts', "WHERE status != 'archived' ORDER BY COALESCE(scheduled_at, created) DESC LIMIT 120"),
    runs: db.all('runs', 'ORDER BY id DESC LIMIT 40'),
    log: db.all('log', 'ORDER BY id DESC LIMIT 60'),
    kept: db.all('kept_answers', 'ORDER BY at DESC'),
    agents: AGENTS,
    team: teamList(),
    steps: steps(c),
    cli: c,
    tools: { ffmpeg: !!ffmpegPath(), chrome: chromeInstalled(), hosting: hostReady(sec.r2) },
    settings: { ai_provider: db.setting('ai:provider', 'none'), ai_model: db.setting('ai:model', ''), autopilot: autopilot(), cap: db.setting('cap:outreach', 20), follow_first: db.setting('follow:first', 21), follow_second: db.setting('follow:second', 42), post_time: db.setting('post:time', '17:30'), post_channels: db.setting('post:channels', ['instagram', 'facebook', 'bluesky']), autosubmit: db.setting('forms:autosubmit', false), guard_hours: db.setting('guard:hours', 6), mail_checked: db.setting('mail:checked', null), scout_per_run: db.setting('scout:per_run', 8) },
    providers: { ai: AI_PROVIDERS, mail: MAIL_PROVIDERS, channels: Object.fromEntries(Object.entries(CHANNELS).map(([k, v]) => [k, { name: v.name, kind: v.kind, posts: v.posts, fields: v.fields.map(f => ({ id: f[0], label: f[1], hint: f[2], secret: !!f[3] })), steps: v.steps, help: v.help }])) },
    secrets: secretShape(),
    mail_address: sec.mail?.address || '',
    paths: { root: ROOT, data: DATA, drop: DROP, site: SITE },
  };
}

// ------------------------------------------------------------------ terminal + open
// Opening a .command file needs no macOS permission; telling Terminal to run a
// script would. So every "Install" and "Sign in" button writes one and opens it.
function openTerminal(title, cmd) {
  if (DRY) return;
  const dir = join(DATA, 'launchers');
  mkdirSync(dir, { recursive: true });
  const f = join(dir, `${title.replace(/[^\w ]+/g, '')}.command`);
  writeFileSync(f, `#!/bin/bash\nexport PATH="$HOME/.local/bin:/usr/local/bin:/opt/homebrew/bin:$PATH"\nclear\necho "HQ: ${title}"\necho\n${cmd}\n`, { mode: 0o755 });
  spawn('/usr/bin/open', ['-a', 'Terminal', f], { detached: true, stdio: 'ignore' }).unref();
}
const TERMINAL = {
  'claude-install': ['Install Claude', 'echo "Installing Claude Code. When it finishes a browser opens: sign in with your Claude account."\necho\ncurl -fsSL https://claude.ai/install.sh | bash && "$HOME/.local/bin/claude" auth login\necho\necho "Done. Go back to HQ and press Check again. You can close this window."'],
  'claude-login': ['Sign in to Claude', 'claude auth login\necho\necho "Done. Go back to HQ and press Check again. You can close this window."'],
  'chatgpt-install': ['Install ChatGPT connector', 'if ! command -v npm >/dev/null; then echo "This needs Node.js from nodejs.org first."; exit 1; fi\nnpm install -g @openai/codex && codex login'],
  'chatgpt-login': ['Sign in to ChatGPT', 'codex login'],
  // Claude Code itself, opened in the package folder, so every agent and
  // skill in .claude is loaded and the owner can ask for anything in words.
  'claude-here': ['Claude in HQ', `cd "${ROOT}"\necho "This is Claude Code, opened inside your HQ folder. Every HQ agent and skill is loaded."\necho "Ask for anything in plain words, for example:"\necho "  find 20 wellness conferences with an open speaker call"\necho "  use the claim-warden on my speaker one-pager"\necho "  change the website hero to say ..."\necho\nclaude`],
};
const openPath = p => { if (!DRY) spawn('/usr/bin/open', [p], { detached: true, stdio: 'ignore' }).unref(); };

// ------------------------------------------------------------------ scheduler
let busy = new Set();
async function once(name, fn) {
  if (busy.has(name)) return;
  busy.add(name);
  try { await fn(); } catch (e) { db.log('autopilot', `${name}: ${e.message}`); } finally { busy.delete(name); }
}
const last = {};
const every = (name, ms) => { if (Date.now() - (last[name] || 0) < ms) return false; last[name] = Date.now(); return true; };

async function tickOnce() {
  const ap = autopilot();
  const now = new Date();
  once('publish', () => publishDue(ctx));
  if (every('held', 5 * 60e3)) once('held', () => carryHeld(ctx));
  if (ap.inbox && readSecrets().mail?.pass && every('inbox', Math.max(2, Number(ap.inbox_minutes) || 5) * 60e3)) once('inbox', () => runAgent(ctx, 'concierge'));
  if (every('guard', 10 * 60e3)) once('guard', () => guardInbox(ctx));
  if (ap.studio && every('studio', 2 * 60e3)) once('studio', () => runAgent(ctx, 'studio'));
  if (ap.keywords && every('keywords', 15 * 60e3)) once('keywords', async () => {
    const offers = {};
    for (const p of projectsOf(db)) if (p.keyword && p.link) offers[p.keyword.toUpperCase()] = { text: `Here you go. ${p.name}:`, link: p.link };
    const seen = new Set(db.setting('keywords:seen', []));
    const r = await keywordTick(readSecrets().instagram, offers, seen);
    db.setSetting('keywords:seen', [...seen].slice(-4000));
    if (r.replied?.length) db.log('keywords', `Answered ${r.replied.length} comment${r.replied.length === 1 ? '' : 's'}.`);
  });
  // Once a day, after the brief hour.
  const day = today();
  if (now.getHours() >= Number(ap.brief_hour || 8) && db.setting('daily:last') !== day) {
    db.setSetting('daily:last', day);
    once('daily', async () => {
      // Back up first. One copy a day, the last 14 kept.
      try { copyFileSync(join(DATA, 'hq.db'), join(DATA, 'backups', `hq-${day}.db`)); for (const f of readdirSync(join(DATA, 'backups')).sort().slice(0, -14)) rmSync(join(DATA, 'backups', f)); } catch {}
      if (ap.scout && (ap.scout_days || []).includes(now.getDay()) && aiCfg(db).provider === 'claude') await runAgent(ctx, 'scout');
      if (ap.writer) await runAgent(ctx, 'writer');
      if (ap.chaser) await runAgent(ctx, 'chaser');
      if (ap.brief) await runAgent(ctx, 'chief');
    });
  }
}

// ------------------------------------------------------------------ http
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.mp4': 'video/mp4', '.mov': 'video/quicktime', '.json': 'application/json', '.ico': 'image/x-icon', '.woff2': 'font/woff2' };

function serveFile(res, file, req) {
  if (!existsSync(file) || !statSync(file).isFile()) { res.writeHead(404); return res.end('Not found'); }
  const size = statSync(file).size;
  const type = MIME[extname(file).toLowerCase()] || 'application/octet-stream';
  const range = req.headers.range && /bytes=(\d*)-(\d*)/.exec(req.headers.range);
  if (range) {
    const start = Number(range[1] || 0), end = range[2] ? Number(range[2]) : size - 1;
    res.writeHead(206, { 'content-type': type, 'content-range': `bytes ${start}-${end}/${size}`, 'accept-ranges': 'bytes', 'content-length': end - start + 1 });
    return createReadStream(file, { start, end }).pipe(res);
  }
  res.writeHead(200, { 'content-type': type, 'content-length': size, 'cache-control': 'no-store' });
  createReadStream(file).pipe(res);
}
const inside = (base, rel) => { const p = normalize(join(base, rel)); return p.startsWith(base) ? p : null; };

async function body(req) {
  let s = '';
  for await (const c of req) { s += c; if (s.length > 2e6) throw httpErr(413, 'Too much data.'); }
  if (!s) return {};
  try { return JSON.parse(s); } catch { return Object.fromEntries(new URLSearchParams(s)); }
}

const siteHits = new Map();
async function api(req, res, url) {
  const m = req.method, p = url.pathname;
  const send = (o, code = 200) => { res.writeHead(code, { 'content-type': 'application/json', 'cache-control': 'no-store' }); res.end(JSON.stringify(o)); };

  if (p === '/api/whoami') return send({ app: APP_ID, root: ROOT, data: DATA, pid: process.pid, started: STARTED });

  // The website's forms post here when HQ is reachable (see Website Preview/site-config.js).
  if (p === '/api/site/inquiry') {
    res.setHeader('access-control-allow-origin', '*'); res.setHeader('access-control-allow-headers', 'content-type');
    if (m === 'OPTIONS') { res.writeHead(204); return res.end(); }
    if (m !== 'POST') throw httpErr(405, 'POST only');
    const ip = req.socket.remoteAddress; const n = (siteHits.get(ip) || []).filter(t => Date.now() - t < 3600e3);
    if (n.length >= 10) throw httpErr(429, 'Too many messages. Please email instead.');
    siteHits.set(ip, [...n, Date.now()]);
    const b = await body(req);
    if (b.website_url) return send({ ok: true }); // the honeypot box only robots fill in
    const email = String(b.email || '').trim().slice(0, 200);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw httpErr(400, 'Please give an email address we can answer.');
    const lines = Object.entries(b).filter(([k]) => !['email', 'name', 'kind', 'website_url'].includes(k)).map(([k, v]) => `${k.replace(/_/g, ' ')}: ${String(v).slice(0, 2000)}`);
    const mid = db.insert('messages', { direction: 'in', message_id: `site-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, from_name: String(b.name || '').slice(0, 120), from_email: email, subject: `Website: ${b.kind || 'inquiry'}`, body: lines.join('\n'), at: stamp(), kind: 'human', intent: { speaking: 'speaking', session: 'session', press: 'press', partnership: 'partnership' }[b.kind] || 'other', summary: `${b.kind || 'Inquiry'} from the website` });
    const P = profileOf(db);
    card(db, { kind: 'reply', agent: 'concierge', message_id: mid, title: `Website ${b.kind || 'inquiry'}: ${b.name || email}`, why: lines.slice(0, 4).join(' · '), to_addr: email, subject: `Thank you, ${String(b.name || '').split(' ')[0] || 'and hello'}`, body: `Hi ${String(b.name || '').split(' ')[0] || 'there'},\n\nThank you for reaching out. I read every message myself. I'll come back to you shortly with next steps.\n\n${P.signoff || ''}`, key: `site:${mid}` });
    notify(`Website ${b.kind || 'inquiry'}`, `${b.name || email}`);
    return send({ ok: true });
  }

  // Everything else is the owner's own page only.
  if (m !== 'GET' && req.headers['x-hq'] !== '1') throw httpErr(403, 'Refused: not from the HQ page.');

  if (m === 'GET' && p === '/api/state') return send(await state());
  if (m === 'GET' && p === '/api/cli') { cliCache.at = 0; return send(await cli()); }

  if (m === 'POST' && p === '/api/profile') {
    const b = await body(req);
    const cur = db.setting('profile', {});
    const next = { ...cur, ...b.profile };
    for (const k of ['credentials', 'samples', 'names_ok']) if (typeof next[k] === 'string') next[k] = next[k].split('\n').map(s => s.trim()).filter(Boolean);
    delete next._voice;
    db.setSetting('profile', next);
    if (b.confirm) db.setSetting(`${b.confirm}:confirmed`, true);
    return send({ ok: true });
  }
  if (m === 'POST' && p === '/api/verify') {
    const b = await body(req);
    const P = db.setting('profile', {});
    P.verify = (P.verify || []).map(v => v.id === b.id ? { ...v, ok: !!b.ok, answer: String(b.answer ?? v.answer ?? '') } : v);
    if (b.id === 'fee-range' && b.answer) { const sp = db.one("SELECT id, facts FROM projects WHERE kind = 'speaking'"); if (sp) db.update('projects', sp.id, { facts: `${sp.facts.replace(/\nFee range:.*$/m, '')}\nFee range: ${b.answer}` }); }
    db.setSetting('profile', P);
    return send({ ok: true });
  }
  if (m === 'POST' && p === '/api/flag') { const b = await body(req); if (/^[\w:-]+$/.test(b.key || '')) db.setSetting(b.key, b.value ?? true); return send({ ok: true }); }

  if (m === 'POST' && p === '/api/projects') {
    const b = await body(req);
    const row = { name: noDashes(b.name || 'New project'), kind: b.kind, color: b.color, status: b.status, summary: b.summary, offer: b.offer, price: b.price, link: b.link, audience: b.audience, goal: b.goal, keyword: String(b.keyword || '').toUpperCase().replace(/[^A-Z]/g, ''), cta: b.cta, facts: b.facts, audiences: b.audiences, letters: b.letters, pillars: typeof b.pillars === 'string' ? b.pillars.split('\n').map(s => s.trim()).filter(Boolean) : b.pillars, sort: b.sort };
    for (const k of Object.keys(row)) if (row[k] === undefined) delete row[k];
    if (b.id) { db.update('projects', Number(b.id), row); return send({ ok: true, id: Number(b.id) }); }
    return send({ ok: true, id: db.insert('projects', { sort: 99, ...row }) });
  }
  if (m === 'DELETE' && p.startsWith('/api/projects/')) { db.update('projects', Number(p.split('/')[3]), { status: 'archived' }); return send({ ok: true }); }
  if (m === 'POST' && p === '/api/projects/interview') {
    const b = await body(req);
    const P = profileOf(db);
    if (aiCfg(db).provider === 'none') throw httpErr(400, 'Connect Claude on Setup first; the interview needs it to write the letters and audiences.');
    const r = parseJson(await complete(aiCfg(db), `${frame(P)}

NEW PROJECT INTERVIEW. The owner is adding a project to their HQ. Their answers:
${untrusted('ANSWERS', JSON.stringify(b), 3000)}
Write: a one sentence summary; who buys it (audience); 1 to 4 outreach audiences, each with an id (one word), a label and a precise web-search description of the people who decide; 3 to 5 posting themes; one first outreach letter (subject and body) using the blanks {{FIRST}}, {{ORG}}, {{HOOK}} (one line about them, its own paragraph) and {{SIGNATURE}}, under 130 words, no em dashes, only credentials from the profile, ending with one easy question; a one-word comment keyword in capitals for Instagram.
Reply ONLY with JSON: {"summary":"","audience":"","audiences":[{"id":"","label":"","search":""}],"pillars":[""],"letter":{"subject":"","body":""},"keyword":""}`));
    const row = { name: noDashes(b.name || 'New project'), kind: b.kind || 'other', summary: noDashes(r.summary || ''), offer: noDashes(b.offer || ''), price: b.price || '', link: b.link || '', goal: noDashes(b.goal || ''), audience: noDashes(r.audience || ''), audiences: r.audiences || [], pillars: r.pillars || [], letters: r.letter ? { first: { subject: noDashes(r.letter.subject), body: noDashes(r.letter.body) } } : {}, keyword: String(r.keyword || '').toUpperCase().replace(/[^A-Z]/g, '').slice(0, 12), facts: noDashes(b.facts || ''), sort: 50 };
    return send({ ok: true, id: db.insert('projects', row) });
  }

  if (m === 'POST' && p === '/api/contacts') {
    const b = await body(req);
    if (b.id) { const up = {}; for (const k of ['status', 'notes', 'email', 'name', 'org', 'role', 'form_url', 'project_id', 'fit']) if (b[k] !== undefined) up[k] = b[k]; db.update('contacts', Number(b.id), up); return send({ ok: true }); }
    // A pasted list: one person per line, "Name, Org, email, website".
    const lines = String(b.paste || '').split('\n').map(s => s.trim()).filter(Boolean);
    let n = 0;
    for (const line of lines.slice(0, 500)) {
      const parts = line.split(/\s*[,\t]\s*/);
      const email = parts.find(x => /@/.test(x)) || '';
      const web = parts.find(x => /^https?:|\.\w{2,}$/.test(x) && !/@/.test(x)) || '';
      const rest = parts.filter(x => x !== email && x !== web);
      const id = db.insertKeyed('contacts', { project_id: Number(b.project_id) || null, name: rest[0] || '', org: rest[1] || '', email, website: web, status: email ? 'ready' : 'needs-route', source: 'pasted', created: stamp(), key: `paste:${(email || line).toLowerCase()}` });
      if (id) n++;
    }
    return send({ ok: true, added: n });
  }

  let mm;
  if (m === 'POST' && (mm = p.match(/^\/api\/cards\/(\d+)\/(approve|reply|submitted|dismiss|caption)$/))) {
    const id = Number(mm[1]); const b = await body(req);
    if (mm[2] === 'approve') return send(await approve(ctx, id, b));
    if (mm[2] === 'reply') return send(await replyTo(ctx, id, b.text));
    if (mm[2] === 'submitted') { markSubmitted(db, id); return send({ ok: true }); }
    if (mm[2] === 'dismiss') { db.update('cards', id, { status: 'dismissed', done_at: stamp(), outcome: 'Closed. Nothing was sent.' }); return send({ ok: true }); }
    if (mm[2] === 'caption') {
      const c = db.get('cards', id); const post = db.get('posts', c.post_id);
      const project = projectsOf(db, true).find(x => x.id === post?.project_id);
      const r = await writeCaption(ctx, { project, pillar: post?.pillar, about: b.about || '', media: post?.media });
      if (r.caption) { db.update('cards', id, { body: r.caption, heard: 'Wrote a new caption.' }); db.update('posts', post.id, { caption: r.caption }); }
      else db.update('cards', id, { heard: r.why });
      return send({ ok: true });
    }
  }
  if (m === 'POST' && (mm = p.match(/^\/api\/agents\/(\w+)\/run$/))) { const b = await body(req); return send(await runAgent(ctx, mm[1], b)); }
  if (m === 'POST' && p === '/api/route') {
    const b = await body(req);
    const r = await route(aiCfg(db), String(b.text || ''), teamList());
    return send(r);
  }
  if (m === 'POST' && p === '/api/forms') {
    const b = await body(req);
    if (!/^https:\/\//.test(b.url || '')) throw httpErr(400, 'Paste the full https link to the form.');
    const id = card(db, { kind: 'form', agent: 'scribe', project_id: Number(b.project_id) || null, title: `Form: ${new URL(b.url).hostname}`, why: b.note || 'You asked for this form to be filled.', body: b.url, key: `form-url:${b.url}:${Date.now()}`, skill: 'form-filler' });
    prepareForm(ctx, db.get('cards', id)).catch(e => db.update('cards', id, { heard: `Could not read the form: ${e.message}`, status: 'failed' }));
    return send({ ok: true, id });
  }
  if (m === 'POST' && p === '/api/ask') {
    const b = await body(req);
    if (aiCfg(db).provider === 'none') throw httpErr(400, 'Connect an AI on Setup to ask questions.');
    const snap = { projects: projectsOf(db).map(x => ({ name: x.name, price: x.price, goal: x.goal })), waiting: db.one("SELECT COUNT(*) n FROM cards WHERE status='waiting'").n, contacts: db.many('SELECT status, COUNT(*) n FROM contacts WHERE duplicate_of IS NULL GROUP BY status'), recent_inquiries: db.many("SELECT from_name, intent, summary, answered FROM messages WHERE direction='in' AND kind='human' ORDER BY id DESC LIMIT 15"), posts: db.many('SELECT status, COUNT(*) n FROM posts GROUP BY status') };
    const a = await complete(aiCfg(db), `${frame(profileOf(db))}\n\nThe owner is asking their HQ a question. Answer in at most 8 short sentences from the data below. If the data cannot answer it, say what is missing and which HQ page or agent would get it.\nDATA: ${JSON.stringify(snap).slice(0, 8000)}\nQUESTION: """${String(b.question || '').slice(0, 1000)}"""`);
    return send({ answer: noDashes(a) });
  }
  if (m === 'POST' && p === '/api/settings') {
    const b = await body(req);
    const MAP = { cap: 'cap:outreach', follow_first: 'follow:first', follow_second: 'follow:second', post_time: 'post:time', post_channels: 'post:channels', autosubmit: 'forms:autosubmit', guard_hours: 'guard:hours', autopilot: 'autopilot', scout_per_run: 'scout:per_run' };
    for (const [k, v] of Object.entries(b)) if (MAP[k]) db.setSetting(MAP[k], k === 'autopilot' ? { ...autopilot(), ...v } : v);
    return send({ ok: true });
  }

  if (m === 'POST' && p === '/api/connect/ai') {
    const b = await body(req);
    if (!AI_PROVIDERS[b.provider]) throw httpErr(400, 'Unknown AI choice.');
    if (b.key) saveSecret('ai', { [b.provider]: b.key });
    db.setSetting('ai:provider', b.provider); db.setSetting('ai:model', b.model || '');
    if (b.provider === 'none') return send({ ok: true });
    try { await connectionTest(aiCfg(db)); return send({ ok: true, message: 'Connected. The agents can write and think now.' }); }
    catch (e) { return send({ ok: false, message: e.message }); }
  }
  if (m === 'POST' && p === '/api/connect/mail') {
    const b = await body(req);
    if (!MAIL_PROVIDERS[b.provider]) throw httpErr(400, 'Pick your email provider.');
    const cur = readSecrets().mail || {};
    const acct = { provider: b.provider, address: String(b.address || cur.address || '').trim(), pass: String(b.pass || cur.pass || '').replace(/\s+/g, ''), imap_host: b.imap_host || cur.imap_host || '', smtp_host: b.smtp_host || cur.smtp_host || '', smtp_port: b.smtp_port || cur.smtp_port || '' };
    try {
      const r = DRY ? { ok: true, recent: 0 } : await testMailbox(acct);
      saveSecret('mail', acct);
      // Start from now: an old inbox is not 300 new inquiries.
      if (!db.setting('mail:pos')) db.setSetting('mail:pos', {});
      return send({ ok: true, message: `Connected to ${acct.address}. ${r.recent} message${r.recent === 1 ? '' : 's'} in the last day. HQ reads your inbox and sends only what you approve.` });
    } catch (e) { return send({ ok: false, message: `Could not sign in: ${e.message}` }); }
  }
  if (m === 'POST' && (mm = p.match(/^\/api\/connect\/channel\/(\w+)$/))) {
    const b = await body(req);
    if (mm[1] === 'r2') { saveSecret('r2', b); return send({ ok: hostReady(readSecrets().r2), message: hostReady(readSecrets().r2) ? 'Media hosting saved.' : 'Saved. Some boxes are still empty.' }); }
    if (!CHANNELS[mm[1]]) throw httpErr(400, 'Unknown channel.');
    if (b.forget) { forgetSecret(mm[1]); return send({ ok: true, message: 'Disconnected.' }); }
    saveSecret(mm[1], b);
    try { const r = await testChannel(mm[1], readSecrets()[mm[1]]); return send({ ok: true, message: `Connected: ${r.label}` }); }
    catch (e) { return send({ ok: false, message: e.message }); }
  }
  if (m === 'POST' && (mm = p.match(/^\/api\/terminal\/([\w-]+)$/))) { const t = TERMINAL[mm[1]]; if (!t) throw httpErr(404, 'Unknown'); openTerminal(t[0], t[1]); cliCache.at = 0; return send({ ok: true }); }
  if (m === 'POST' && (mm = p.match(/^\/api\/open\/(\w+)$/))) {
    const where = { drop: DROP, site: join(SITE, 'index.html'), playbooks: PLAYBOOKS, data: DATA, root: ROOT }[mm[1]];
    if (!where) throw httpErr(404, 'Unknown');
    if (mm[1] === 'site') db.setSetting('website:seen', true);
    openPath(where); return send({ ok: true });
  }
  throw httpErr(404, 'No such thing.');
}

const server = createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://127.0.0.1:${PORT}`);
    // Refuse a foreign Host header (a web page trying to reach this server by DNS rebinding).
    const hostH = String(req.headers.host || '').split(':')[0];
    if (!['127.0.0.1', 'localhost'].includes(hostH) && !url.pathname.startsWith('/api/site/')) { res.writeHead(421); return res.end('Wrong host'); }
    if (url.pathname.startsWith('/api/')) return await api(req, res, url);
    if (url.pathname.startsWith('/site/')) { const f = inside(SITE, decodeURIComponent(url.pathname.slice(6)) || 'index.html'); return f ? serveFile(res, f.endsWith('/') ? join(f, 'index.html') : f, req) : (res.writeHead(404), res.end()); }
    if (url.pathname.startsWith('/media/')) { const post = db.get('posts', Number(url.pathname.split('/')[2])); return post ? serveFile(res, (post.built && existsSync(post.built)) ? post.built : post.media, req) : (res.writeHead(404), res.end()); }
    const f = inside(join(APP, 'public'), url.pathname === '/' ? 'index.html' : decodeURIComponent(url.pathname.slice(1)));
    return f ? serveFile(res, f, req) : (res.writeHead(404), res.end());
  } catch (e) {
    const code = e.status || 500;
    if (code === 500) db.log('error', e.stack || e.message);
    if (!res.headersSent) res.writeHead(code, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ error: e.message }));
  }
});

server.on('error', e => {
  if (e.code === 'EADDRINUSE') { console.error(`Port ${PORT} is already in use by another program. HQ did not start.`); process.exit(3); }
  throw e;
});
server.listen(PORT, '127.0.0.1', () => {
  console.log(`HQ running at http://127.0.0.1:${PORT}  (data: ${DATA})${DRY ? '  TEST MODE: nothing leaves this Mac' : ''}`);
  if (process.env.HQ_NO_SCHEDULER !== '1') { setInterval(() => tickOnce().catch(() => {}), 60e3); setTimeout(() => tickOnce().catch(() => {}), 8000); }
});
