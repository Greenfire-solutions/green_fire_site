// End-to-end checks on a throwaway HQ: its own port (8412), its own temp data
// folder, a fake AI, and HQ_NO_OUTWARD=1 so nothing can leave the Mac.
//   node test/smoke.mjs

import { spawn } from 'node:child_process';
import { mkdtempSync, mkdirSync, copyFileSync, utimesSync, rmSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { tmpdir } from 'node:os';
import { fileURLToPath } from 'node:url';

const APP = join(dirname(fileURLToPath(import.meta.url)), '..');
const T = mkdtempSync(join(tmpdir(), 'hq-test-'));
const DROP = join(T, 'drop'); mkdirSync(DROP);
copyFileSync(join(APP, 'test', 'fixture.jpg'), join(DROP, 'stage-clip.jpg'));   // a plain generated picture, nobody's photo
utimesSync(join(DROP, 'stage-clip.jpg'), new Date(Date.now() - 3600e3), new Date(Date.now() - 3600e3));
const PORT = 8412, B = `http://127.0.0.1:${PORT}`;
const srv = spawn(process.execPath, ['--no-warnings', 'server.mjs'], { cwd: APP, env: { ...process.env, HQ_DATA: T, HQ_DROP: DROP, HQ_PORT: String(PORT), HQ_NO_OUTWARD: '1', HQ_FAKE_AI: '1', HQ_NO_SCHEDULER: '1' }, stdio: ['ignore', 'pipe', 'pipe'] });
let errs = ''; srv.stderr.on('data', d => (errs += d));

let pass = 0, fail = 0;
const ok = (cond, name, extra = '') => { if (cond) { pass++; console.log(`  PASS  ${name}`); } else { fail++; console.log(`  FAIL  ${name} ${extra}`); } };
const get = async p => (await fetch(B + p)).json();
const post = async (p, b, h = { 'x-hq': '1' }) => { const r = await fetch(B + p, { method: 'POST', headers: { 'content-type': 'application/json', ...h }, body: JSON.stringify(b || {}) }); return { status: r.status, ...(await r.json().catch(() => ({}))) }; };
const state = () => get('/api/state');

try {
  for (let i = 0; i < 40; i++) { try { await fetch(B + '/api/whoami'); break; } catch { await new Promise(r => setTimeout(r, 250)); } }
  const who = await get('/api/whoami');
  ok(who.app === 'greenfire-hq', 'the server says who it is');
  let s = await state();
  ok(s.projects.length === 0 && !s.profile.name && !s.profile.credentials.length, 'a new kit starts blank: no owner, no projects, no claims');
  ok(s.steps.length === 9 && s.steps.every(x => !x.done), 'setup has nine steps, none falsely done');
  ok((await post('/api/profile', { profile: { name: 'Sam Example', first: 'Sam', business: 'Example Studio', credentials: ['ten years of teaching', 'worked with 40 local businesses', 'author of a field guide', 'speaker at regional events', 'certified coach'], signature: 'Sam Example\nExample Studio' } })).ok, 'the owner fills in a profile');
  const sp = await post('/api/projects', { name: 'Speaking & Workshops', kind: 'speaking', status: 'active', offer: 'Talks and workshops', audience: 'Conference programmers',
    audiences: [{ id: 'conference', label: 'Conference programmers', search: 'conference programmers with an open speaker call' }],
    letters: { first: { subject: 'Speaking at {{ORG}}', body: 'Hi {{FIRST}},\n\n{{HOOK}}\n\nI run talks and workshops built around your people.\n\nWould a short outline help? Thanks for your time.\n\n{{SIGNATURE}}' } } });
  ok(sp.ok && sp.id === 1, 'the owner adds a first project');

  // Safety: a page that is not HQ cannot change anything.
  const forged = await post('/api/agents/writer/run', {}, {});
  ok(forged.status === 403, 'a request without the HQ header is refused');

  ok((await post('/api/connect/ai', { provider: 'claude' })).ok, 'connect the AI');
  ok((await post('/api/connect/mail', { provider: 'workspace', address: 'info@example.com', pass: 'abcd efgh ijkl mnop' })).ok, 'connect the mailbox');
  s = await state();
  ok(s.steps.find(x => x.id === 'mail').done && s.steps.find(x => x.id === 'ai').done, 'the mail and AI steps tick themselves');
  ok(!JSON.stringify(s).includes('abcdefghijklmnop'), 'the app password never reaches the page');

  const sc = await post('/api/agents/scout/run', { projectId: 1, audienceId: 'conference' });
  ok(sc.ok, 'the Scout runs', sc.error);
  const again = await post('/api/agents/scout/run', { projectId: 1, audienceId: 'conference' });
  ok(/already known/.test(again.summary || ''), 'the Scout does not add the same organisation twice', again.summary);

  ok((await post('/api/contacts', { project_id: 1, paste: 'Jane Doe, Acme Corp, jane@acme.com, https://acme.com\nJohn Roe, Beta Summit, john@betasummit.org, betasummit.org' })).added === 2, 'a pasted list is added');
  const w = await post('/api/agents/writer/run', {});
  ok(w.ok && /2 letters/.test(w.summary), 'the Writer drafts a letter per ready prospect', w.summary || w.error);
  s = await state();
  const letter = s.cards.find(c => c.kind === 'email' && c.to_addr === 'jane@acme.com');
  ok(letter && /Hi Jane/.test(letter.body) && !/\{\{/.test(letter.body), 'the letter is filled in, no blanks left');
  ok(letter && !/[—–]/.test(letter.body + letter.subject), 'the letter has no long dashes');

  // The claim guard: an invented number holds the letter.
  const bad = await post(`/api/cards/${letter.id}/approve`, { body: letter.body + '\nI have helped 5,000,000 people.' });
  ok(/Not sent/.test(bad.outcome) && /5,000,000/.test(bad.outcome), 'a claim that is not the owner\'s is refused', bad.outcome);
  const dash = await post(`/api/cards/${letter.id}/approve`, { body: letter.body.replace('Thanks for your time', 'Thanks — truly') });
  ok(/Not sent/.test(dash.outcome) && /dash/.test(dash.outcome), 'a long dash is refused', dash.outcome);
  const sent = await post(`/api/cards/${letter.id}/approve`, { body: letter.body });
  ok(/Sent to jane@acme.com/.test(sent.outcome), 'a yes sends it (test mode)', sent.outcome);
  s = await state();
  ok(s.contacts.find(c => c.email === 'jane@acme.com').status === 'sent', 'the contact moves to sent');
  const twice = await post(`/api/cards/${letter.id}/approve`, {});
  ok(/Already/.test(twice.outcome), 'a second press does not send twice', twice.outcome);

  // Daily cap: over it, a yes is HELD, never an error.
  await post('/api/settings', { cap: 1 });
  const other = s.cards.find(c => c.kind === 'email' && c.to_addr === 'john@betasummit.org');
  const held = await post(`/api/cards/${other.id}/approve`, {});
  ok(held.status === 'held', 'over the daily cap a yes is held for tomorrow', held.outcome);
  await post('/api/settings', { cap: 20 });

  // Replies on a card: kept, acted on, answered.
  const no = await post(`/api/cards/${other.id}/reply`, { text: 'no, not a fit' });
  ok(/Closed/.test(no.heard), 'a "no" closes the card');
  s = await state();
  ok(s.cards.find(c => c.id === other.id).said.includes('not a fit'), 'what the owner typed stays on the card');

  // Website inquiry lands in the inbox with a reply drafted.
  const si = await post('/api/site/inquiry', { kind: 'speaking', name: 'Pat Planner', email: 'pat@corp.com', event_date: '2027-03-10', audience: '300 sales leaders' }, {});
  ok(si.ok, 'the website form posts into HQ');
  const spam = await post('/api/site/inquiry', { kind: 'speaking', name: 'Bot', email: 'bot@x.com', website_url: 'http://spam' }, {});
  s = await state();
  ok(spam.ok && !s.cards.some(c => /Bot/.test(c.title)), 'the honeypot drops robots quietly');
  ok(s.cards.some(c => c.kind === 'reply' && /Pat Planner/.test(c.title)), 'a website inquiry becomes a reply card');

  // Studio: a dropped photo becomes a built post with a caption that passes the voice check.
  const st = await post('/api/agents/studio/run', {});
  ok(st.ok && /1 new post/.test(st.summary), 'Studio builds a post from the drop folder', st.summary || st.error);
  s = await state();
  const pc = s.cards.find(c => c.kind === 'post');
  ok(pc && pc.body.trim().endsWith('?'), 'the caption ends with a question');
  const sched = await post(`/api/cards/${pc.id}/approve`, { channels: ['bluesky'] });
  ok(sched.status === 'scheduled', 'a yes schedules the post', sched.outcome);
  s = await state();
  ok(s.posts[0].status === 'scheduled' && s.posts[0].scheduled_at > s.today, 'it is scheduled on a future free day');

  // Router
  const r1 = await post('/api/route', { text: 'find 10 wellness conferences with an open speaker call' });
  ok(r1.agent === 'scout', 'the router sends "find conferences" to the Scout');
  const r2 = await post('/api/route', { text: 'check my inbox' });
  ok(r2.agent === 'concierge', 'the router sends "check my inbox" to the Concierge');
  const r3 = await post('/api/route', { text: 'fill out this speaker application form' });
  ok(r3.agent === 'scribe' && r3.needs === 'url', 'the router asks for a link for a form');

  // Brief
  ok((await post('/api/agents/chief/run', {})).ok, 'the Chief writes the brief');
  // Project interview
  const pi = await post('/api/projects/interview', { name: 'Instructor Training', offer: 'A certification', who: 'Yoga teachers' });
  ok(pi.ok && pi.id, 'the project interview builds a project');
  s = await state();
  const np = s.projects.find(p => p.id === pi.id);
  ok(np && np.audiences.length && np.letters.first, 'the new project has audiences and a letter');
  ok(s.team.skills.length >= 10 && s.team.agents.length >= 5, 'the skills and agents library is packaged', `${s.team.skills.length} skills, ${s.team.agents.length} agents`);
} catch (e) { fail++; console.log('  FAIL  crashed:', e.stack); }
finally {
  srv.kill();
  if (errs.trim()) console.log('server stderr:\n' + errs.slice(0, 2000));
  rmSync(T, { recursive: true, force: true });
  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
}
