// HQ, the page. Plain JavaScript, no build step. One state object from the
// server, one render per change. What the owner types lives in S.typed, keyed
// by box, so a refresh in the background never throws away half a sentence.

const S = { d: null, page: (location.hash.slice(1) || 'today'), step: null, typed: {}, tab: {}, answer: null, routed: null, busy: new Set() };
const $ = (s, el = document) => el.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const J = (s, f) => { try { return typeof s === 'string' ? JSON.parse(s) : (s ?? f); } catch { return f; } };
const typed = (k, fallback = '') => (k in S.typed ? S.typed[k] : fallback);
const STATE_COLORS = ['var(--grey)', 'var(--blue)', 'var(--red)', 'var(--green)'];

async function api(path, body, method) {
  const r = await fetch(path, { method: method || (body ? 'POST' : 'GET'), headers: { 'content-type': 'application/json', 'x-hq': '1' }, body: body ? JSON.stringify(body) : undefined });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || `HQ answered ${r.status}`);
  return j;
}
function toast(msg, bad) {
  document.querySelectorAll('.toast').forEach(t => t.remove());
  const t = document.createElement('div'); t.className = `toast${bad ? ' bad' : ''}`; t.textContent = msg; document.body.appendChild(t);
  setTimeout(() => t.remove(), bad ? 7000 : 3800);
}
async function load() { S.d = await api('/api/state'); render(); }
async function act(label, fn) {
  if (S.busy.has(label)) return;
  S.busy.add(label); render();
  try { const r = await fn(); await load(); return r; }
  catch (e) { toast(e.message, true); }
  finally { S.busy.delete(label); render(); }
}
const busy = l => S.busy.has(l);

// ------------------------------------------------------------------ nav
const PAGES = [
  ['today', 'Today', '◈'], ['inbox', 'Inbox', '✉'], ['outreach', 'Outreach', '◎'], ['studio', 'Studio', '◐'], ['forms', 'Forms', '▤'],
  ['projects', 'Projects', '▦'], ['team', 'Agents & Skills', '★'], ['website', 'Website', '◇'], ['setup', 'Setup', '⚙'],
];
function nav() {
  const d = S.d;
  const waiting = d.cards.filter(c => ['waiting', 'held', 'failed'].includes(c.status)).length;
  const inbox = d.cards.filter(c => c.kind === 'reply' && c.status === 'waiting').length;
  const left = d.steps.filter(s => !s.done).length;
  const n = { today: waiting, inbox, setup: left };
  $('#nav').innerHTML = `<div class="brand"><b>${esc(d.profile.name || 'Your')} HQ</b><span>${esc(d.profile.tagline || 'Command center')}</span></div>
    ${PAGES.map(([id, label, ic]) => `<a href="#${id}" class="${S.page === id ? 'on' : ''}"><span>${ic}</span>${label}${n[id] ? `<span class="n">${n[id]}</span>` : ''}</a>`).join('')}
    <div class="grow"></div>
    <div class="who">${d.dry ? '<b style="color:var(--warn)">TEST MODE</b>: nothing leaves this Mac<br>' : ''}${d.mail_address ? `Mail: ${esc(d.mail_address)}` : 'Mail not connected'}<br>AI: ${esc(d.providers.ai[d.settings.ai_provider]?.name || 'none')}</div>`;
}

function render() {
  if (!S.d) return;
  nav();
  const page = PAGE[S.page] || PAGE.today;
  const active = document.activeElement;
  const key = active?.dataset?.k; const pos = active && 'selectionStart' in active ? active.selectionStart : null;
  $('#main').innerHTML = page();
  if (key) { const el = document.querySelector(`[data-k="${CSS.escape(key)}"]`); if (el) { el.focus(); try { if (pos != null) el.setSelectionRange(pos, pos); } catch {} } }
}
window.addEventListener('hashchange', () => { S.page = location.hash.slice(1) || 'today'; render(); window.scrollTo(0, 0); });
document.addEventListener('input', e => { const k = e.target.dataset?.k; if (k) S.typed[k] = e.target.type === 'checkbox' ? e.target.checked : e.target.value; });
setInterval(() => { const a = document.activeElement; if (!a || !['INPUT', 'TEXTAREA', 'SELECT'].includes(a.tagName)) load().catch(() => {}); }, 30000);

const projectOf = id => S.d.projects.find(p => p.id === id);
const chip = p => p ? `<span class="chip"><i style="background:${esc(p.color)}"></i>${esc(p.name)}</span>` : '';
const banner = () => {
  const s = S.d.steps; const done = s.filter(x => x.done).length;
  if (done === s.length) return '';
  const next = s.find(x => !x.done);
  return `<div class="banner"><div><b>Setup: ${done} of ${s.length} done.</b> <span class="muted">Next: ${esc(next.title)}.</span></div><div class="bar"><i style="width:${Math.round(done / s.length * 100)}%"></i></div><a class="btn primary small" href="#setup" data-go-step="${next.id}">Continue setup</a></div>`;
};

// ------------------------------------------------------------------ cards
function cardHtml(c) {
  const d = S.d, p = projectOf(c.project_id), ag = d.agents[c.agent] || { name: c.agent, icon: '·' };
  const open = ['waiting', 'held', 'failed'].includes(c.status);
  const k = f => `card:${c.id}:${f}`;
  const post = c.post_id ? d.posts.find(x => x.id === c.post_id) : null;
  const kindLabel = { email: 'Letter', reply: 'Reply', post: 'Post', form: 'Form', alert: 'Needs you now', note: 'Note', question: 'Question' }[c.kind] || c.kind;
  let edit = '';
  if (open && (c.kind === 'email' || c.kind === 'reply')) edit = `<div class="edit grid"><div class="row"><input type="email" data-k="${k('to')}" value="${esc(typed(k('to'), c.to_addr))}" placeholder="To" style="flex:1"><input type="text" data-k="${k('subject')}" value="${esc(typed(k('subject'), c.subject))}" placeholder="Subject" style="flex:2"></div><textarea data-k="${k('body')}" rows="9">${esc(typed(k('body'), c.body))}</textarea></div>`;
  else if (open && c.kind === 'post') edit = `<div class="edit grid g2"><div>${post ? `<div class="media">${/\.(mp4|mov|m4v|webm)$/i.test(post.built || post.media) ? `<video src="/media/${post.id}" controls muted playsinline></video>` : `<img src="/media/${post.id}" alt="">`}</div>` : ''}</div><div class="stack"><textarea data-k="${k('body')}" rows="8" placeholder="Caption">${esc(typed(k('body'), c.body))}</textarea><div class="row"><input type="datetime-local" data-k="${k('when')}" value="${esc(typed(k('when'), (post?.scheduled_at || '').replace(' ', 'T')))}" style="max-width:230px"><button class="btn small ghost" data-act="caption" data-id="${c.id}" ${busy('cap' + c.id) ? 'disabled' : ''}>${busy('cap' + c.id) ? 'Writing...' : 'New caption'}</button></div><div class="row small">${['instagram', 'facebook', 'bluesky', 'discord', 'telegram', 'mastodon', 'webhook'].map(ch => `<label class="row" style="gap:4px"><input type="checkbox" data-k="${k('ch:' + ch)}" ${typed(k('ch:' + ch), J(post?.channels, []).includes(ch)) ? 'checked' : ''}>${ch === 'webhook' ? 'Zapier (TikTok, LinkedIn, YouTube)' : ch}</label>`).join('')}</div></div></div>`;
  else if (c.body && (c.kind === 'note' || !open)) edit = `<div class="edit pre small ${open ? '' : 'muted'}">${esc(c.body).slice(0, open ? 4000 : 600)}</div>`;
  else if (c.kind === 'form') edit = `<div class="edit small"><a href="${esc(c.body)}" target="_blank" rel="noopener">${esc(c.body)}</a></div>`;
  const receipt = [c.said && `<div class="said">You: ${esc(c.said)}</div>`, c.heard && `<div class="heard">${esc(ag.name)}: ${esc(c.heard)}</div>`, c.outcome && `<div class="${c.status === 'failed' ? 'err' : 'out'}">${esc(c.outcome)}</div>`].filter(Boolean).join('');
  const yes = { email: 'Yes, send it', reply: 'Yes, send it', post: 'Yes, schedule it', form: c.form_id ? 'Yes, fill it in' : 'Yes, read and fill it', alert: '', note: '' }[c.kind] ?? 'Yes';
  return `<div class="card ${c.kind === 'alert' && open ? 'alert' : ''} ${open ? '' : 'done'}" id="card-${c.id}">
    <div class="head"><div><div class="who">${ag.icon} ${esc(ag.name)} · ${kindLabel}${c.status === 'held' ? ' · HELD' : ''}</div><h3>${esc(c.title)}</h3></div><div>${chip(p)}</div></div>
    ${c.why ? `<div class="why">${esc(c.why).replace(/HOLD:/, '<b>HOLD:</b>')}</div>` : ''}
    ${c.ask && open ? `<div class="askbox">${esc(c.ask)}</div>` : ''}
    ${edit}
    ${receipt ? `<div class="receipt">${receipt}</div>` : ''}
    ${open ? `<div class="actions">
      ${yes ? `<button class="btn primary" data-act="yes" data-id="${c.id}" ${busy('yes' + c.id) ? 'disabled' : ''}>${busy('yes' + c.id) ? 'Working...' : yes}</button>` : ''}
      <input type="text" data-k="${k('reply')}" value="${esc(typed(k('reply')))}" placeholder="${c.ask ? 'Type your answers here, numbered' : 'Or tell the agent what to change...'}" data-enter="reply" data-id="${c.id}">
      <button class="btn small" data-act="reply" data-id="${c.id}" ${busy('reply' + c.id) ? 'disabled' : ''}>${busy('reply' + c.id) ? '...' : 'Send note'}</button>
      ${c.kind === 'form' && c.status !== 'waiting' ? '' : ''}
      <button class="btn small ghost" data-act="dismiss" data-id="${c.id}">${c.kind === 'note' || c.kind === 'alert' ? 'Done' : 'Not this'}</button>
    </div>` : c.kind === 'form' && c.status === 'filled' ? `<div class="actions"><button class="btn primary small" data-act="submitted" data-id="${c.id}">It's submitted</button></div>` : ''}
  </div>`;
}

// ------------------------------------------------------------------ pages
const PAGE = {};

PAGE.today = () => {
  const d = S.d, P = d.profile;
  const open = d.cards.filter(c => ['waiting', 'held', 'failed', 'working'].includes(c.status) || (c.kind === 'form' && c.status === 'filled'));
  const recent = d.cards.filter(c => !open.includes(c)).slice(0, 6);
  const hour = new Date().getHours();
  const hi = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
  const stats = d.projects.filter(p => p.status === 'active').map(p => {
    const cs = d.contacts.filter(c => c.project_id === p.id);
    const w = open.filter(c => c.project_id === p.id).length;
    return `<div class="panel proj" style="--c:${esc(p.color)}"><div class="eyebrow">${esc(p.kind)}</div><h3 style="margin-top:6px">${esc(p.name)}</h3><div class="row small muted" style="gap:14px"><span><b style="color:var(--text)">${w}</b> waiting</span><span><b style="color:var(--text)">${cs.filter(c => c.status === 'sent').length}</b> pitched</span><span><b style="color:var(--text)">${cs.filter(c => c.status === 'replied').length}</b> replied</span><span><b style="color:var(--text)">${cs.filter(c => c.status === 'booked').length}</b> booked</span></div></div>`;
  }).join('');
  const r = S.routed;
  return `${banner()}
  <div class="hero">
    <div class="states">${STATE_COLORS.map(c => `<i style="background:${c}"></i>`).join('')}</div>
    <div class="eyebrow">${hi}, ${esc(P.first || P.name || '')}</div>
    <h1 style="margin-top:10px">What do you want to do?</h1>
    <p class="muted" style="margin:0">Type it the way you'd say it. HQ picks the agent and the skill. Try: <i>find 10 wellness conferences with an open speaker call</i>, <i>check my inbox</i>, <i>make posts from my new clips</i>.</p>
    <div class="ask"><input type="text" data-k="route" value="${esc(typed('route'))}" placeholder="Find, write, post, fill, check..." data-enter="route"><button class="btn primary" data-act="route" ${busy('route') ? 'disabled' : ''}>${busy('route') ? 'Thinking...' : 'Go'}</button><button class="btn" data-act="ask" ${busy('ask') ? 'disabled' : ''}>${busy('ask') ? '...' : 'Ask'}</button></div>
    ${r ? `<div class="answer"><div>${esc(r.say)}</div>${r.skills?.length ? `<div class="small muted" style="margin-top:6px">Skills: ${r.skills.map(s => `<span class="kbd">${esc(s)}</span>`).join(' ')}</div>` : ''}<div class="row" style="margin-top:10px">${r.agent ? `<button class="btn primary small" data-act="run" data-agent="${r.agent}">Run the ${esc(d.agents[r.agent]?.name || r.agent)}</button>` : ''}${r.needs === 'url' ? `<input type="url" data-k="route:url" placeholder="https://... the form link" style="max-width:420px"><button class="btn small" data-act="form-from-route">Read this form</button>` : ''}${r.claude ? '<button class="btn small" data-act="terminal" data-what="claude-here">Open Claude here</button>' : ''}${r.page ? `<a class="btn small" href="#${r.page}">Go there</a>` : ''}</div></div>` : ''}
    ${S.answer ? `<div class="answer pre">${esc(S.answer)}</div>` : ''}
  </div>
  <div class="grid g3" style="margin:18px 0 26px">${stats}</div>
  <div class="row between" style="margin-bottom:12px"><h2 style="margin:0">Needs you <span class="muted" style="font-size:16px">(${open.length})</span></h2><div class="row"><button class="btn small" data-act="run" data-agent="concierge">Check inbox</button><button class="btn small" data-act="run" data-agent="writer">Write letters</button><button class="btn small" data-act="run" data-agent="chief">Brief me</button></div></div>
  ${open.length ? open.map(cardHtml).join('') : '<div class="panel empty">Nothing waiting on you. The agents are working.</div>'}
  ${recent.length ? `<h3 style="margin:26px 0 10px" class="muted">Just done</h3>${recent.map(cardHtml).join('')}` : ''}`;
};

PAGE.inbox = () => {
  const d = S.d;
  const replies = d.cards.filter(c => (c.kind === 'reply' || c.kind === 'alert') && ['waiting', 'held', 'failed'].includes(c.status));
  const intents = { speaking: 'var(--accent)', session: 'var(--green)', podcast: 'var(--blue)', partnership: 'var(--blue)', press: 'var(--blue)', product: 'var(--grey)', other: 'var(--dim)', sales: 'var(--dim)', personal: 'var(--dim)', student: 'var(--grey)' };
  return `<div class="top"><div><div class="eyebrow">Inbox Concierge</div><h1>Inbox</h1><p class="muted" style="margin:0">${d.mail_address ? `Reading ${esc(d.mail_address)}${d.settings.mail_checked ? `, last checked ${esc(d.settings.mail_checked.slice(11, 16))}` : ''}. Every reply is drafted in your voice and waits for your yes.` : 'Connect your email on Setup and every inquiry lands here with a reply already written.'}</p></div><div class="row"><button class="btn primary" data-act="run" data-agent="concierge" ${busy('run:concierge') ? 'disabled' : ''}>${busy('run:concierge') ? 'Checking...' : 'Check now'}</button></div></div>
  ${replies.length ? replies.map(cardHtml).join('') : '<div class="panel empty">No replies waiting.</div>'}
  <h2 style="margin:28px 0 10px">Recent mail</h2>
  <div class="scroll"><table><tr><th>When</th><th>From</th><th>What they want</th><th>Kind</th><th></th></tr>
  ${d.messages.filter(m => m.direction === 'in').map(m => `<tr><td class="small muted">${esc((m.at || '').slice(5, 16))}</td><td>${esc(m.from_name || m.from_email)}<div class="small dim">${esc(m.from_email)}</div></td><td>${esc(m.summary || m.subject)}</td><td>${m.kind === 'auto' ? '<span class="chip">auto-reply</span>' : m.intent ? `<span class="chip"><i style="background:${intents[m.intent] || 'var(--dim)'}"></i>${esc(m.intent)}</span>` : ''}</td><td>${m.answered ? '<span class="chip ok">answered</span>' : ''}</td></tr>`).join('') || '<tr><td colspan="5" class="empty">No mail read yet.</td></tr>'}</table></div>`;
};

PAGE.outreach = () => {
  const d = S.d;
  const ps = d.projects.filter(p => p.status === 'active');
  const pid = Number(S.tab.outreach || ps[0]?.id);
  const p = projectOf(pid) || ps[0];
  if (!p) return '<div class="panel empty">Add a project first.</div>';
  const st = S.tab.ostatus || 'all';
  const cs = d.contacts.filter(c => c.project_id === p.id && (st === 'all' || c.status === st));
  const counts = s => d.contacts.filter(c => c.project_id === p.id && c.status === s).length;
  const L = p.letters || {};
  return `<div class="top"><div><div class="eyebrow">Audience Scout · Pitch Writer · Follow-up Keeper</div><h1>Outreach</h1><p class="muted" style="margin:0">Who buys each project, found on the web, written to in your voice, followed up twice, then left alone.</p></div></div>
  <div class="tabs">${ps.map(x => `<button class="${x.id === p.id ? 'on' : ''}" data-tab="outreach" data-v="${x.id}">${esc(x.name)}</button>`).join('')}</div>
  <div class="grid g2">
    <div class="panel"><h3>Who to find</h3><p class="small muted">${esc(p.audience)}</p>
      ${(p.audiences || []).map(a => `<div class="switch"><div><b>${esc(a.label)}</b><small>${esc(a.search)}</small></div><button class="btn small" data-act="scout" data-pid="${p.id}" data-aid="${esc(a.id)}" ${busy(`scout${p.id}${a.id}`) ? 'disabled' : ''}>${busy(`scout${p.id}${a.id}`) ? 'Searching (a few minutes)...' : 'Find people'}</button></div>`).join('') || '<p class="small dim">No audiences yet. Edit the project to add one.</p>'}
      <details style="margin-top:14px"><summary>Paste a list you already have</summary><p class="small muted">One per line: Name, Organisation, email, website</p><textarea data-k="paste:${p.id}" rows="5">${esc(typed('paste:' + p.id))}</textarea><div class="row end" style="margin-top:8px"><button class="btn small" data-act="paste" data-pid="${p.id}">Add them</button></div></details>
    </div>
    <div class="panel"><h3>Your standard letters</h3><p class="small muted">Every first letter starts here. <span class="kbd">{{FIRST}}</span> <span class="kbd">{{ORG}}</span> <span class="kbd">{{HOOK}}</span> (one line the Scout wrote about them) <span class="kbd">{{SIGNATURE}}</span>. No long dashes: they get refused.</p>
      ${['first', 'follow_up'].map(t => `<div class="field"><label class="f">${t === 'first' ? 'First letter' : 'Follow-up'}</label><input type="text" data-k="L:${p.id}:${t}:s" value="${esc(typed(`L:${p.id}:${t}:s`, L[t]?.subject || ''))}" placeholder="Subject"><textarea data-k="L:${p.id}:${t}:b" rows="${t === 'first' ? 10 : 5}" style="margin-top:6px">${esc(typed(`L:${p.id}:${t}:b`, L[t]?.body || ''))}</textarea></div>`).join('')}
      <div class="row end"><button class="btn small primary" data-act="save-letters" data-pid="${p.id}">Save letters</button></div>
    </div>
  </div>
  <div class="row between" style="margin:24px 0 10px"><h2 style="margin:0">People (${d.contacts.filter(c => c.project_id === p.id).length})</h2>
    <div class="tabs" style="margin:0">${['all', 'ready', 'needs-route', 'drafted', 'sent', 'replied', 'booked', 'passed', 'bounced'].map(s => `<button class="${st === s ? 'on' : ''}" data-tab="ostatus" data-v="${s}">${s}${s !== 'all' ? ` ${counts(s)}` : ''}</button>`).join('')}</div></div>
  <div class="row" style="margin-bottom:10px"><button class="btn small" data-act="run" data-agent="writer">Write letters for everyone ready</button><button class="btn small" data-act="run" data-agent="chaser">Draft due follow-ups</button></div>
  <div class="scroll"><table><tr><th>Who</th><th>Why them</th><th>Reach</th><th>Fit</th><th>Status</th></tr>
  ${cs.map(c => `<tr><td><b>${esc(c.org || c.name)}</b><div class="small muted">${esc([c.name, c.role].filter(Boolean).join(', '))}</div></td><td class="small">${esc(c.why || '')}${c.found_on ? ` <a href="${esc(c.found_on)}" target="_blank" rel="noopener">source</a>` : ''}<div class="dim">${esc((c.notes || '').replace(/^HOOK: /, 'Hook: ')).slice(0, 220)}</div></td><td class="small">${c.email ? esc(c.email) : c.form_url ? `<a href="${esc(c.form_url)}" target="_blank" rel="noopener">their form</a>` : '<span class="dim">no address printed</span>'}${c.website ? `<div><a href="${esc(c.website)}" target="_blank" rel="noopener">${esc(c.website.replace(/^https?:\/\/(www\.)?/, '').slice(0, 30))}</a></div>` : ''}</td><td>${c.fit}</td><td><select data-contact="${c.id}" class="small" style="width:auto">${['new', 'ready', 'needs-route', 'drafted', 'sent', 'replied', 'booked', 'passed', 'bounced'].map(s => `<option ${s === c.status ? 'selected' : ''}>${s}</option>`).join('')}</select></td></tr>`).join('') || '<tr><td colspan="5" class="empty">Nobody here yet. Press "Find people" above.</td></tr>'}</table></div>`;
};

PAGE.studio = () => {
  const d = S.d;
  const waiting = d.cards.filter(c => c.kind === 'post' && ['waiting', 'failed'].includes(c.status));
  const sched = d.posts.filter(p => ['scheduled', 'published', 'failed', 'posting'].includes(p.status));
  return `<div class="top"><div><div class="eyebrow">Studio</div><h1>Studio</h1><p class="muted" style="margin:0">Drop photos and clips in the <b>Drop Media Here</b> folder. Studio builds each into a post, writes the caption in your voice, picks a free day and waits for your yes.</p></div><div class="row"><button class="btn" data-act="open" data-what="drop">Open Drop Media Here</button><button class="btn primary" data-act="run" data-agent="studio">Check the folder now</button></div></div>
  ${!d.tools.ffmpeg ? '<div class="banner"><div>ffmpeg is not installed, so photos post as photos (no slow push-in video). Optional.</div></div>' : ''}
  ${waiting.length ? waiting.map(cardHtml).join('') : '<div class="panel empty">No posts waiting for a yes.</div>'}
  <h2 style="margin:28px 0 10px">Calendar</h2>
  <div class="scroll"><table><tr><th>When</th><th>Project</th><th>Caption</th><th>Channels</th></tr>
  ${sched.map(p => { const res = J(p.results, {}); return `<tr><td class="small">${esc(p.scheduled_at || '')}<div>${p.status === 'published' ? '<span class="chip ok">posted</span>' : p.status === 'failed' ? '<span class="chip bad">failed</span>' : '<span class="chip warn">scheduled</span>'}</div></td><td>${chip(projectOf(p.project_id))}</td><td class="small" style="max-width:420px">${esc((p.caption || '').slice(0, 220))}</td><td class="small">${J(p.channels, []).map(ch => `<div>${esc(ch)} ${res[ch] ? (res[ch].ok ? '✓' : `<span style="color:var(--bad)">${esc(res[ch].error).slice(0, 90)}</span>`) : ''}</div>`).join('')}</td></tr>`; }).join('') || '<tr><td colspan="4" class="empty">Nothing scheduled yet.</td></tr>'}</table></div>
  <div class="grid g2" style="margin-top:22px">
    <div class="panel"><h3>Comment to get</h3><p class="small muted">Instagram captions end with "Comment STATE and I'll send you the link." HQ answers each comment with a private DM. Keywords per project:</p>${d.projects.filter(p => p.status === 'active').map(p => `<div class="row small" style="margin-bottom:6px">${chip(p)} <span class="kbd">${esc(p.keyword || 'none')}</span> <span class="dim">${esc(p.link || 'no link set')}</span></div>`).join('')}<div class="switch"><input type="checkbox" data-auto="keywords" ${d.settings.autopilot.keywords ? 'checked' : ''}><div><b>Answer comments automatically</b><small>Needs the Instagram messaging permissions (Setup, Socials).</small></div></div></div>
    <div class="panel"><h3>How posts sound</h3><p class="small muted">Every caption is one true thought, ends with a real question, no long dashes, no hype words, no health promises. It learns from your own words on Setup, step 5.</p><a class="btn small" href="#setup" data-go-step="voice">Teach it your voice</a></div>
  </div>`;
};

PAGE.forms = () => {
  const d = S.d;
  const cards = d.cards.filter(c => c.kind === 'form');
  return `<div class="top"><div><div class="eyebrow">Application Scribe</div><h1>Forms</h1><p class="muted" style="margin:0">Speaker applications, podcast guest forms, contact forms. Paste a link: the Scribe reads every box, answers from your profile, asks you everything else on one card, and fills it in a Chrome window you can watch.</p></div></div>
  ${!d.tools.chrome ? '<div class="banner"><div>Google Chrome is not installed. The Scribe needs it to fill forms.</div></div>' : ''}
  <div class="panel"><div class="row"><input type="url" data-k="formurl" value="${esc(typed('formurl'))}" placeholder="https://... paste the form or application page" style="flex:1"><select data-k="formproj" style="width:auto">${d.projects.filter(p => p.status === 'active').map(p => `<option value="${p.id}" ${String(typed('formproj')) === String(p.id) ? 'selected' : ''}>${esc(p.name)}</option>`).join('')}</select><button class="btn primary" data-act="form" ${busy('form') ? 'disabled' : ''}>Read it</button></div>
  <p class="small dim" style="margin:10px 0 0">It never pays and never presses a button that pays. It sends a form by itself only if you switch that on in Setup, Autopilot.</p></div>
  <div style="margin-top:18px">${cards.length ? cards.map(cardHtml).join('') : '<div class="panel empty">No forms yet.</div>'}</div>
  <h2 style="margin:28px 0 10px">Answers it remembers</h2>
  <div class="scroll"><table><tr><th>Question</th><th>Your answer</th></tr>${d.kept.map(k => `<tr><td class="small">${esc(k.label)}</td><td class="small">${esc(k.value)}</td></tr>`).join('') || '<tr><td colspan="2" class="empty">None yet. Every answer you give on a form card is kept for the next form.</td></tr>'}</table></div>`;
};

PAGE.projects = () => {
  const d = S.d;
  const editing = S.tab.editproj;
  const p = editing ? projectOf(Number(editing)) : null;
  if (p) return projectEditor(p);
  return `<div class="top"><div><div class="eyebrow">Run everything from one place</div><h1>Projects</h1><p class="muted" style="margin:0">Each project has its own offer, audiences, letters and post themes. The agents work all active projects at once and never mix them up.</p></div><button class="btn primary" data-tab="editproj" data-v="new">Add a project</button></div>
  ${S.tab.editproj === 'new' ? newProject() : ''}
  <div class="grid g2">${d.projects.filter(x => x.status !== 'archived').map(x => `<div class="panel proj" style="--c:${esc(x.color)}"><div class="row between"><div class="eyebrow">${esc(x.kind)} · ${esc(x.status)}</div><span class="chip">${esc(x.price || '')}</span></div><h2 style="margin-top:8px">${esc(x.name)}</h2><p class="muted small">${esc(x.summary)}</p><p class="small"><b>Goal:</b> ${esc(x.goal)}</p><div class="row"><button class="btn small" data-tab="editproj" data-v="${x.id}">Edit</button><button class="btn small ghost" data-act="toggle-proj" data-id="${x.id}">${x.status === 'active' ? 'Pause' : 'Resume'}</button>${x.link ? `<a class="btn small ghost" href="${esc(x.link)}" target="_blank" rel="noopener">Offer page</a>` : ''}</div></div>`).join('')}</div>`;
};
function newProject() {
  const t = S.d.templates;
  const k = f => `np:${f}`;
  return `<div class="panel" style="margin-bottom:18px"><h2>New project interview</h2><p class="muted small">Answer in plain words. Claude writes the audiences to search, the first letter and the post themes from your answers. You can edit everything after.</p>
  <div class="row" style="margin-bottom:12px">${t.map(x => `<button class="btn small ghost" data-act="np-template" data-name="${esc(x.name)}" data-kind="${esc(x.kind)}" data-summary="${esc(x.summary)}" data-aud="${esc(x.audience)}">${esc(x.name)}</button>`).join('')}</div>
  <div class="grid g2">
    <div class="field"><label class="f">What is it called?</label><input type="text" data-k="${k('name')}" value="${esc(typed(k('name')))}"></div>
    <div class="field"><label class="f">What kind of thing is it? (course, training, retreat, product...)</label><input type="text" data-k="${k('kind')}" value="${esc(typed(k('kind')))}"></div>
    <div class="field"><label class="f">What does someone get?</label><textarea data-k="${k('offer')}" rows="3">${esc(typed(k('offer')))}</textarea></div>
    <div class="field"><label class="f">Who buys it, and who decides?</label><textarea data-k="${k('who')}" rows="3">${esc(typed(k('who')))}</textarea></div>
    <div class="field"><label class="f">Price</label><input type="text" data-k="${k('price')}" value="${esc(typed(k('price')))}"></div>
    <div class="field"><label class="f">Link where people buy or book</label><input type="url" data-k="${k('link')}" value="${esc(typed(k('link')))}"></div>
    <div class="field"><label class="f">What would make this a win in 90 days?</label><input type="text" data-k="${k('goal')}" value="${esc(typed(k('goal')))}"></div>
    <div class="field"><label class="f">Facts the agents may state (dates, formats, results you can prove)</label><textarea data-k="${k('facts')}" rows="3">${esc(typed(k('facts')))}</textarea></div>
  </div><div class="row end"><button class="btn ghost" data-tab="editproj" data-v="">Cancel</button><button class="btn primary" data-act="np-save" ${busy('np') ? 'disabled' : ''}>${busy('np') ? 'Claude is building it...' : 'Build this project'}</button></div></div>`;
}
function projectEditor(p) {
  const k = f => `pe:${p.id}:${f}`;
  const f = (id, label, val, area) => `<div class="field"><label class="f">${label}</label>${area ? `<textarea data-k="${k(id)}" rows="${area}">${esc(typed(k(id), val))}</textarea>` : `<input type="text" data-k="${k(id)}" value="${esc(typed(k(id), val))}">`}</div>`;
  return `<div class="top"><div><div class="eyebrow">Project</div><h1>${esc(p.name)}</h1></div><button class="btn" data-tab="editproj" data-v="">Back to projects</button></div>
  <div class="grid g2"><div class="panel">${f('name', 'Name', p.name)}${f('summary', 'One line summary', p.summary, 2)}${f('offer', 'The offer, in your words', p.offer, 4)}${f('price', 'Price', p.price)}${f('link', 'Buy or book link', p.link)}${f('goal', 'Goal', p.goal)}${f('color', 'Colour', p.color)}</div>
  <div class="panel">${f('audience', 'Who buys it', p.audience, 3)}${f('facts', 'Facts agents may state (and nothing else)', p.facts, 5)}${f('pillars', 'Post themes, one per line', (p.pillars || []).join('\n'), 4)}${f('keyword', 'Instagram comment keyword', p.keyword)}${f('cta', 'What a commenter gets ("Comment KEYWORD and I will send you ...")', p.cta)}
  <label class="f">Audiences to search (one per line: label | who exactly to search for)</label><textarea data-k="${k('aud')}" rows="5">${esc(typed(k('aud'), (p.audiences || []).map(a => `${a.label} | ${a.search}`).join('\n')))}</textarea></div></div>
  <div class="row end" style="margin-top:14px"><button class="btn danger ghost" data-act="archive-proj" data-id="${p.id}">Archive project</button><button class="btn primary" data-act="save-proj" data-id="${p.id}">Save project</button></div>`;
}

PAGE.team = () => {
  const d = S.d;
  return `<div class="top"><div><div class="eyebrow">Your team</div><h1>Agents & Skills</h1><p class="muted" style="margin:0">Seven agents run inside HQ. Behind them is a library of Claude Code agents and skills: the playbooks they follow. Open Claude here to use any of them in plain words.</p></div><button class="btn primary" data-act="terminal" data-what="claude-here">Open Claude here</button></div>
  <div class="grid g2">${Object.entries(d.agents).map(([id, a]) => { const last = d.runs.find(r => r.agent === id); return `<div class="panel"><div class="row between"><h3 style="margin:0">${a.icon} ${esc(a.name)}</h3><button class="btn small" data-act="run" data-agent="${id}" ${busy('run:' + id) ? 'disabled' : ''}>${busy('run:' + id) ? 'Running...' : 'Run now'}</button></div><p class="small muted">${esc(a.does)}</p><div class="small">${a.uses.map(s => `<span class="kbd">${esc(s)}</span>`).join(' ')}</div>${last ? `<p class="small ${last.error ? '' : 'dim'}" style="margin:8px 0 0;${last.error ? 'color:var(--bad)' : ''}">Last run ${esc((last.started || '').slice(5, 16))}: ${esc(last.error || last.summary)}</p>` : ''}</div>`; }).join('')}</div>
  <h2 style="margin:30px 0 6px">Skills (${d.team.skills.length})</h2><p class="small muted">Step-by-step playbooks Claude follows. HQ picks the right one when you type what you want on Today.</p>
  <div class="lib">${d.team.skills.map(s => `<div class="item"><b>${esc(s.name)}</b><p>${esc(s.description.slice(0, 260))}</p></div>`).join('')}</div>
  <h2 style="margin:30px 0 6px">Reviewer agents (${d.team.agents.length})</h2><p class="small muted">Specialists Claude can call: they check, research or prove things and report back.</p>
  <div class="lib">${d.team.agents.map(s => `<div class="item"><b>${esc(s.name)}</b><p>${esc(s.description.slice(0, 260))}</p></div>`).join('')}</div>
  <h2 style="margin:30px 0 10px">Activity</h2><div class="scroll"><table>${d.log.map(l => `<tr><td class="small dim">${esc(l.at.slice(5, 16))}</td><td class="small">${esc(l.kind)}</td><td class="small">${esc(l.message.slice(0, 300))}</td></tr>`).join('')}</table></div>`;
};

PAGE.website = () => `<div class="top"><div><div class="eyebrow">Example build</div><h1>Website</h1><p class="muted" style="margin:0">A rebuilt site in your style, with booking for every offer and AI built in. The front end is finished; every form and button has one marked place to plug in (see <span class="kbd">site-config.js</span>).</p></div><div class="row"><button class="btn" data-act="open" data-what="site">Open in browser</button></div></div>
  <iframe class="site" src="/site/index.html" title="Website preview"></iframe>`;

// ------------------------------------------------------------------ setup
const STEP = {};
PAGE.setup = () => {
  const s = S.d.steps;
  const cur = S.step || (s.find(x => !x.done) || s[0]).id;
  return `<div class="top"><div><div class="eyebrow">Step by step</div><h1>Setup</h1><p class="muted" style="margin:0">Nine steps. Each one checks itself, so a green tick means it really works. Most are paste and press.</p></div></div>
  <div class="setup"><ol class="steps">${s.map(x => `<li class="${x.done ? 'done' : ''} ${x.id === cur ? 'on' : ''}" data-step="${x.id}">${esc(x.title)}</li>`).join('')}</ol>
  <div class="panel">${(STEP[cur] || (() => ''))()}</div></div>`;
};
const nextBtn = (id, label = 'This is right, next step') => `<div class="row end" style="margin-top:18px"><button class="btn primary" data-act="confirm" data-what="${id}">${label}</button></div>`;
const fld = (k, label, val, opts = {}) => `<div class="field"><label class="f">${label}</label>${opts.area ? `<textarea data-k="${k}" rows="${opts.area}">${esc(typed(k, val))}</textarea>` : `<input type="${opts.type || 'text'}" data-k="${k}" value="${esc(typed(k, val))}" placeholder="${esc(opts.ph || '')}">`}${opts.help ? `<div class="small dim" style="margin-top:4px">${opts.help}</div>` : ''}</div>`;

STEP.profile = () => {
  const P = S.d.profile;
  return `<h2>What HQ already knows about you</h2><p class="muted">Read from your website and Stan Store. Fix anything that is wrong. Agents only ever state the credentials listed here.</p>
  <div class="grid g2">${fld('pf:name', 'Name', P.name)}${fld('pf:tagline', 'Tagline', P.tagline)}${fld('pf:city', 'Based in', P.city)}${fld('pf:email', 'Public email', P.email)}${fld('pf:website', 'Website', P.website)}${fld('pf:signoff', 'How you sign emails', P.signoff)}</div>
  ${fld('pf:bio_short', 'Short bio (forms that want 50 words)', P.bio_short, { area: 3 })}${fld('pf:bio_long', 'Long bio', P.bio_long, { area: 8 })}
  ${fld('pf:credentials', 'Your credentials, one per line (the ONLY claims agents may make)', (P.credentials || []).join('\n'), { area: 6 })}
  ${fld('pf:topics', 'Speaking topics', P.topics)}${fld('pf:signature', 'Email signature', P.signature, { area: 3 })}
  <h3 style="margin-top:20px">A few things to confirm</h3><p class="small muted">These came from places other than your own site, or need a number only you know. Agents leave them out until you answer.</p>
  ${(P.verify || []).map(v => `<div class="switch"><input type="checkbox" data-verify="${v.id}" ${v.ok ? 'checked' : ''}><div><b>${esc(v.text)}</b>${v.id === 'speaking-fee' ? `<input type="text" data-k="vf:${v.id}" value="${esc(typed('vf:' + v.id, v.answer || ''))}" placeholder="e.g. $15,000 to $25,000 plus travel" style="margin-top:6px">` : ''}</div></div>`).join('')}
  ${nextBtn('profile')}`;
};
STEP.ai = () => {
  const c = S.d.cli?.claude || {}; const cur = S.d.settings.ai_provider;
  return `<h2>Connect your Claude account</h2><p class="muted">This is the brain. The agents use <b>your own Claude subscription</b> through Claude Code on this Mac. No key to copy, nothing extra to pay.</p>
  <div class="howto"><ol>
    <li>${c.installed ? '<span class="chip ok">done</span> Claude Code is installed.' : `Install Claude Code. <button class="btn small primary" data-act="terminal" data-what="claude-install">Install Claude</button> A Terminal window opens and does it. When a browser opens, sign in with your Claude account.`}</li>
    <li>${c.signedIn ? '<span class="chip ok">done</span> Signed in.' : `Sign in. <button class="btn small" data-act="terminal" data-what="claude-login">Sign in to Claude</button>`}</li>
    <li>${cur === 'claude' ? '<span class="chip ok">done</span> HQ is using your Claude account.' : `Tell HQ to use it. <button class="btn small primary" data-act="ai" data-provider="claude" ${busy('ai') ? 'disabled' : ''}>${busy('ai') ? 'Testing...' : 'Use my Claude account'}</button>`}</li>
  </ol><div class="row" style="margin-top:10px"><button class="btn small ghost" data-act="cli">Check again</button></div></div>
  <details style="margin-top:16px"><summary>Use something else instead</summary><div class="stack" style="margin-top:10px">
    <div class="row"><button class="btn small" data-act="ai" data-provider="chatgpt">My ChatGPT account</button><button class="btn small ghost" data-act="terminal" data-what="chatgpt-install">Install ChatGPT connector</button></div>
    <div class="row"><input type="password" data-k="aikey" placeholder="Claude API key (sk-ant-...)" style="flex:1"><button class="btn small" data-act="ai" data-provider="anthropic">Use this key</button></div>
    <p class="small dim">Only your Claude account can search the web, so the Audience Scout needs it. The other choices can write but not research.</p></div></details>`;
};
STEP.projects = () => `<h2>Your projects</h2><p class="muted">HQ runs every line of your business side by side. One per offer you sell. Pause what you are not pushing right now; add anything missing (a service, sessions, a course).</p>
  ${S.d.projects.filter(p => p.status !== 'archived').map(p => `<div class="switch"><input type="checkbox" data-proj-active="${p.id}" ${p.status === 'active' ? 'checked' : ''}><div><b>${esc(p.name)}</b> <span class="dim small">${esc(p.price)}</span><small>${esc(p.summary)}</small></div><a class="btn small ghost" href="#projects" data-edit-proj="${p.id}">Edit</a></div>`).join('')}
  <div class="row" style="margin-top:12px"><a class="btn small" href="#projects" data-new-proj="1">Add a project</a></div>${nextBtn('projects', 'These are my projects')}`;
STEP.mail = () => {
  const prov = typed('ml:provider', 'workspace'); const P = S.d.providers.mail[prov] || {};
  return `<h2>Connect your email</h2><p class="muted">So the Inbox Concierge can read inquiries and send the replies you approve. HQ reads with a special app password, never your real password, and you can revoke it any time.</p>
  ${S.d.mail_address ? `<p><span class="chip ok">connected</span> ${esc(S.d.mail_address)}</p>` : ''}
  <div class="field"><label class="f">Where is your email?</label><select data-k="ml:provider">${Object.entries(S.d.providers.mail).map(([id, x]) => `<option value="${id}" ${id === prov ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select></div>
  <div class="howto"><b>Get your app password</b><ol><li>${esc(P.steps || '')}</li>${P.help ? `<li><a href="${esc(P.help)}" target="_blank" rel="noopener">Open the page where you make it</a></li>` : ''}<li>Copy it, paste it below, press Connect.</li></ol></div>
  <div class="grid g2" style="margin-top:14px">${fld('ml:address', 'Email address', S.d.mail_address || S.d.profile.email, { type: 'email' })}${fld('ml:pass', 'App password', '', { type: 'password', ph: 'xxxx xxxx xxxx xxxx' })}</div>
  ${prov === 'custom' ? `<div class="grid g3">${fld('ml:imap_host', 'IMAP server', '')}${fld('ml:smtp_host', 'SMTP server', '')}${fld('ml:smtp_port', 'SMTP port', '465')}</div>` : ''}
  <div class="row end"><button class="btn primary" data-act="mail" ${busy('mail') ? 'disabled' : ''}>${busy('mail') ? 'Signing in...' : 'Connect'}</button></div>`;
};
STEP.voice = () => {
  const P = S.d.profile;
  return `<h2>Teach it how you sound</h2><p class="muted">Every caption and letter is written to sound like you, then checked: no long dashes, no hype words, no health promises, and every post ends with a real question.</p>
  ${fld('vc:note', 'How you sound, in your words', P.voice_note, { area: 4 })}
  ${fld('vc:samples', 'Paste 5 to 10 of your best captions or lines, one per line (the more, the better it hears you)', (P.samples || []).join('\n'), { area: 9 })}
  <p class="small dim">Each time you edit a letter before sending, HQ learns from the change too.</p>${nextBtn('voice', 'Save my voice')}`;
};
STEP.socials = () => {
  const d = S.d; const ch = d.providers.channels;
  const one = id => { const c = ch[id]; const on = d.secrets[id]; return `<details class="panel" style="margin-bottom:10px;padding:14px 16px" ${S.tab.opench === id ? 'open' : ''}><summary><b>${esc(c.name)}</b> ${on ? '<span class="chip ok">saved</span>' : ''}</summary><div class="howto" style="margin-top:10px">${esc(c.steps)} ${c.help ? `<a href="${esc(c.help)}" target="_blank" rel="noopener">Open it</a>` : ''}</div><div class="grid g2" style="margin-top:10px">${c.fields.map(f => fld(`sc:${id}:${f.id}`, f.label, '', { type: f.secret ? 'password' : 'text', ph: on?.[f.id] ? 'saved (leave empty to keep)' : f.hint })).join('')}</div><div class="row end"><button class="btn small primary" data-act="channel" data-ch="${id}">Save and test</button></div></details>`; };
  return `<h2>Connect your social accounts</h2><p class="muted">Connect what you use. Each test proves the connection without posting anything.</p>
  ${['instagram', 'facebook', 'bluesky'].map(one).join('')}
  <details class="panel" style="margin-bottom:10px;padding:14px 16px"><summary><b>Instagram needs a public link for each photo and video</b> ${d.tools.hosting ? '<span class="chip ok">saved</span>' : ''}</summary><div class="howto" style="margin-top:10px">Instagram fetches media from a web link. Make a free Cloudflare R2 bucket: <ol><li>Sign in at dash.cloudflare.com, open R2, Create bucket (name it <span class="kbd">hq-media</span>).</li><li>In the bucket, Settings, Public access, allow the r2.dev subdomain, copy that link.</li><li>R2, Manage API tokens, Create token with Object Read and Write on that bucket. Copy the Access Key ID and Secret.</li><li>Your Account ID is on the R2 overview page.</li></ol></div>
  <div class="grid g2" style="margin-top:10px">${fld('r2:account_id', 'Account ID', '')}${fld('r2:bucket', 'Bucket name', '', { ph: 'hq-media' })}${fld('r2:access_key_id', 'Access Key ID', '', { type: 'password' })}${fld('r2:secret_access_key', 'Secret Access Key', '', { type: 'password' })}${fld('r2:public_base', 'Public link', '', { ph: 'https://pub-xxxx.r2.dev' })}</div><div class="row end"><button class="btn small primary" data-act="r2">Save</button></div></details>
  ${one('webhook')}
  <details style="margin-top:6px"><summary>More channels</summary><div style="margin-top:10px">${['discord', 'telegram', 'mastodon'].map(one).join('')}</div></details>
  <p class="small dim" style="margin-top:12px">TikTok, LinkedIn and YouTube do not let a personal tool post directly without an app review. Connect Zapier above and HQ hands every approved post to it.</p>${nextBtn('socials', 'Done with socials')}`;
};
STEP.links = () => {
  const P = S.d.profile;
  return `<h2>Booking and payment links</h2><p class="muted">The links agents put in replies, letters and captions. Each project's own buy or book link is on Projects.</p>
  <div class="grid g2">${fld('lk:stan', 'Stan Store', P.links?.stan)}${fld('lk:instagram', 'Instagram', P.links?.instagram)}${fld('lk:tiktok', 'TikTok', P.links?.tiktok)}${fld('lk:youtube', 'YouTube', P.links?.youtube)}${fld('lk:speaker_reel', 'Speaker reel video link (forms ask for it)', P.links?.speaker_reel, { ph: 'https://youtu.be/...' })}${fld('lk:calendar', 'Calendar link for calls (Calendly, Cal.com)', P.links?.calendar)}</div>
  <h3>Project links</h3>${S.d.projects.filter(p => p.status === 'active').map(p => fld(`plk:${p.id}`, p.name, p.link)).join('')}${nextBtn('links', 'Save links')}`;
};
STEP.autopilot = () => {
  const s = S.d.settings, ap = s.autopilot;
  const sw = (id, title, help) => `<div class="switch"><input type="checkbox" data-auto="${id}" ${ap[id] ? 'checked' : ''}><div><b>${title}</b><small>${help}</small></div></div>`;
  return `<h2>Decide what runs by itself</h2><p class="muted">Agents work on their own while HQ is open. <b>Nothing is sent, posted or submitted without your yes</b>, except the two switches marked below, which are off until you turn them on.</p>
  ${sw('inbox', 'Check my inbox every few minutes', 'Reads new mail and drafts replies.')}${sw('studio', 'Watch the Drop Media Here folder', 'Builds posts from anything you drop in.')}${sw('scout', 'Find new prospects on Mon, Wed and Fri', 'One audience per run, round robin across projects. Needs your Claude account.')}${sw('writer', 'Write first letters every morning', 'For every new prospect with an address.')}${sw('chaser', 'Draft follow-ups when due', `After ${s.follow_first} days, then ${s.follow_second}, then stop.`)}${sw('brief', 'Morning brief', 'One card each morning across every project.')}${sw('keywords', 'Answer "Comment KEYWORD" on Instagram (sends DMs by itself)', 'Off until you have connected the Instagram messaging permissions.')}
  <div class="switch"><input type="checkbox" data-k="as:autosubmit" ${typed('as:autosubmit', s.autosubmit) ? 'checked' : ''}><div><b>Let the Scribe press Submit on forms (sends by itself)</b><small>Only when every required box is answered and nothing asks for payment.</small></div></div>
  <div class="grid g3" style="margin-top:16px">${fld('as:cap', 'Outreach letters per day', s.cap, { type: 'number' })}${fld('as:post_time', 'Default post time', s.post_time, { type: 'time' })}${fld('as:guard', 'Alert me if an inquiry waits this many hours', s.guard_hours, { type: 'number' })}</div>
  ${nextBtn('autopilot', 'Save autopilot')}`;
};
STEP.website = () => `<h2>See your new website</h2><p class="muted">An example of your site rebuilt: high-end, built around booking, with AI in the places it helps. It runs from the Website Preview folder, so it works offline.</p>
  <div class="row"><button class="btn primary" data-act="open" data-what="site">Open the website</button><a class="btn" href="#website">Preview it here</a></div>
  <div class="howto" style="margin-top:16px">Every booking form posts to one address set in <span class="kbd">Website Preview/site-config.js</span>. Point it at HQ (when HQ is online) and website inquiries land in your Inbox with a reply already written. Until then it falls back to email.</div>${nextBtn('website', 'Done')}`;

// ------------------------------------------------------------------ actions
const val = k => S.typed[k];
const ACT = {
  async yes(el) {
    const id = Number(el.dataset.id); const c = S.d.cards.find(x => x.id === id); const k = f => `card:${id}:${f}`;
    const b = {};
    if (k('body') in S.typed) b.body = S.typed[k('body')];
    if (k('subject') in S.typed) b.subject = S.typed[k('subject')];
    if (k('to') in S.typed) b.to_addr = S.typed[k('to')];
    if (c.kind === 'post') {
      if (k('when') in S.typed) b.scheduled_at = String(S.typed[k('when')]).replace('T', ' ');
      const post = S.d.posts.find(p => p.id === c.post_id);
      const chs = ['instagram', 'facebook', 'bluesky', 'discord', 'telegram', 'mastodon', 'webhook'].filter(ch => typed(k('ch:' + ch), J(post?.channels, []).includes(ch)));
      b.channels = chs;
    }
    const r = await act('yes' + id, () => api(`/api/cards/${id}/approve`, b));
    if (r) { toast(r.outcome); for (const key of Object.keys(S.typed)) if (key.startsWith(`card:${id}:`)) delete S.typed[key]; }
  },
  async reply(el) {
    const id = Number(el.dataset.id); const text = val(`card:${id}:reply`);
    if (!text?.trim()) return toast('Type a note first.', true);
    const r = await act('reply' + id, () => api(`/api/cards/${id}/reply`, { text }));
    if (r) { delete S.typed[`card:${id}:reply`]; delete S.typed[`card:${id}:body`]; toast(r.heard); }
  },
  async dismiss(el) { await act('d' + el.dataset.id, () => api(`/api/cards/${el.dataset.id}/dismiss`, {})); },
  async submitted(el) { await act('s' + el.dataset.id, () => api(`/api/cards/${el.dataset.id}/submitted`, {})); toast('Recorded. The follow-up clock is running.'); },
  async caption(el) { const id = el.dataset.id; delete S.typed[`card:${id}:body`]; await act('cap' + id, () => api(`/api/cards/${id}/caption`, {})); },
  async run(el) {
    const a = el.dataset.agent;
    const r = await act('run:' + a, () => api(`/api/agents/${a}/run`, {}));
    if (r) toast(r.ok ? `${S.d.agents[a]?.name}: ${r.summary}` : r.error, !r.ok);
  },
  async scout(el) {
    const r = await act(`scout${el.dataset.pid}${el.dataset.aid}`, () => api('/api/agents/scout/run', { projectId: Number(el.dataset.pid), audienceId: el.dataset.aid }));
    if (r) toast(r.ok ? r.summary : r.error, !r.ok);
  },
  async route() {
    const text = val('route'); if (!text?.trim()) return;
    S.answer = null;
    const r = await act('route', () => api('/api/route', { text }));
    if (r) { S.routed = r; render(); }
  },
  async ask() {
    const text = val('route'); if (!text?.trim()) return;
    S.routed = null;
    const r = await act('ask', () => api('/api/ask', { question: text }));
    if (r) { S.answer = r.answer; render(); }
  },
  async 'form-from-route'() { S.typed.formurl = val('route:url'); await ACT.form(); location.hash = 'forms'; },
  async form() {
    const url = val('formurl'); if (!url) return toast('Paste the form link first.', true);
    const r = await act('form', () => api('/api/forms', { url, project_id: Number(val('formproj') || S.d.projects[0]?.id) }));
    if (r) { delete S.typed.formurl; toast('Reading the form. Its card appears here in a moment.'); setTimeout(load, 15000); setTimeout(load, 40000); }
  },
  async paste(el) { const pid = el.dataset.pid; const r = await act('paste', () => api('/api/contacts', { project_id: pid, paste: val('paste:' + pid) })); if (r) { delete S.typed['paste:' + pid]; toast(`Added ${r.added}.`); } },
  async 'save-letters'(el) {
    const p = projectOf(Number(el.dataset.pid)); const L = { ...(p.letters || {}) };
    for (const t of ['first', 'follow_up']) { const s = typed(`L:${p.id}:${t}:s`, L[t]?.subject || ''), b = typed(`L:${p.id}:${t}:b`, L[t]?.body || ''); if (/[—–]/.test(s + b)) return toast('A letter has a long dash in it. Use a comma or a full stop.', true); if (s || b) L[t] = { subject: s, body: b }; }
    const r = await act('letters', () => api('/api/projects', { id: p.id, letters: L })); if (r) toast('Saved. Every new letter for this project starts from these.');
  },
  async 'toggle-proj'(el) { const p = projectOf(Number(el.dataset.id)); await act('tp', () => api('/api/projects', { id: p.id, status: p.status === 'active' ? 'paused' : 'active' })); },
  async 'archive-proj'(el) { await act('ap', () => api(`/api/projects/${el.dataset.id}`, null, 'DELETE')); S.tab.editproj = ''; render(); },
  async 'save-proj'(el) {
    const p = projectOf(Number(el.dataset.id)); const k = f => `pe:${p.id}:${f}`; const b = { id: p.id };
    for (const f of ['name', 'summary', 'offer', 'price', 'link', 'goal', 'color', 'audience', 'facts', 'pillars', 'keyword', 'cta']) if (k(f) in S.typed) b[f] = S.typed[k(f)];
    if (k('aud') in S.typed) b.audiences = String(S.typed[k('aud')]).split('\n').map(l => l.split('|').map(s => s.trim())).filter(a => a[0]).map(([label, search]) => ({ id: label.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 24), label, search: search || label }));
    const r = await act('sp', () => api('/api/projects', b)); if (r) { for (const key of Object.keys(S.typed)) if (key.startsWith(`pe:${p.id}:`)) delete S.typed[key]; toast('Project saved.'); }
  },
  'np-template'(el) { S.typed['np:name'] = el.dataset.name; S.typed['np:kind'] = el.dataset.kind; S.typed['np:offer'] = el.dataset.summary; S.typed['np:who'] = el.dataset.aud; render(); },
  async 'np-save'() {
    const b = { name: val('np:name'), kind: val('np:kind'), offer: val('np:offer'), who: val('np:who'), price: val('np:price'), link: val('np:link'), goal: val('np:goal'), facts: val('np:facts') };
    if (!b.name) return toast('Give it a name first.', true);
    const r = await act('np', () => api('/api/projects/interview', b));
    if (r) { for (const key of Object.keys(S.typed)) if (key.startsWith('np:')) delete S.typed[key]; S.tab.editproj = String(r.id); toast('Built. Check the audiences and letter, then save.'); render(); }
  },
  async terminal(el) { await api(`/api/terminal/${el.dataset.what}`, {}); toast('A Terminal window is opening.'); },
  async open(el) { await api(`/api/open/${el.dataset.what}`, {}); },
  async cli() { await act('cli', () => api('/api/cli')); },
  async ai(el) {
    const r = await act('ai', () => api('/api/connect/ai', { provider: el.dataset.provider, key: val('aikey') || '' }));
    if (r) toast(r.message || (r.ok ? 'Saved.' : 'Not connected.'), !r.ok);
  },
  async mail() {
    const b = { provider: typed('ml:provider', 'workspace'), address: typed('ml:address', S.d.mail_address || S.d.profile.email), pass: val('ml:pass') || '', imap_host: val('ml:imap_host'), smtp_host: val('ml:smtp_host'), smtp_port: val('ml:smtp_port') };
    const r = await act('mail', () => api('/api/connect/mail', b));
    if (r) { toast(r.message, !r.ok); if (r.ok) delete S.typed['ml:pass']; }
  },
  async channel(el) {
    const id = el.dataset.ch; const b = {};
    for (const f of S.d.providers.channels[id].fields) { const v = val(`sc:${id}:${f.id}`); if (v) b[f.id] = v; }
    S.tab.opench = id;
    const r = await act('ch' + id, () => api(`/api/connect/channel/${id}`, b));
    if (r) toast(r.message, !r.ok);
  },
  async r2() { const b = {}; for (const f of ['account_id', 'bucket', 'access_key_id', 'secret_access_key', 'public_base']) if (val('r2:' + f)) b[f] = val('r2:' + f); const r = await act('r2', () => api('/api/connect/channel/r2', b)); if (r) toast(r.message, !r.ok); },
  async confirm(el) {
    const w = el.dataset.what; const P = S.d.profile;
    if (w === 'profile') {
      const prof = {}; for (const f of ['name', 'tagline', 'city', 'email', 'website', 'signoff', 'bio_short', 'bio_long', 'credentials', 'topics', 'signature']) if (`pf:${f}` in S.typed) prof[f] = S.typed[`pf:${f}`];
      if (prof.name) prof.first = prof.name.split(' ')[0];
      await api('/api/profile', { profile: prof, confirm: 'profile' });
      for (const v of P.verify || []) if (`vf:${v.id}` in S.typed) await api('/api/verify', { id: v.id, ok: true, answer: S.typed[`vf:${v.id}`] });
    }
    if (w === 'voice') await api('/api/profile', { profile: { voice_note: typed('vc:note', P.voice_note), samples: typed('vc:samples', (P.samples || []).join('\n')) }, confirm: 'voice' });
    if (w === 'links') {
      const links = { ...(P.links || {}) }; for (const f of ['stan', 'instagram', 'tiktok', 'youtube', 'speaker_reel', 'calendar']) if (`lk:${f}` in S.typed) links[f] = S.typed[`lk:${f}`];
      await api('/api/profile', { profile: { links }, confirm: 'links' });
      for (const p of S.d.projects) if (`plk:${p.id}` in S.typed) await api('/api/projects', { id: p.id, link: S.typed[`plk:${p.id}`] });
    }
    if (w === 'autopilot') await api('/api/settings', { autosubmit: !!typed('as:autosubmit', S.d.settings.autosubmit), cap: Number(typed('as:cap', S.d.settings.cap)), post_time: typed('as:post_time', S.d.settings.post_time), guard_hours: Number(typed('as:guard', S.d.settings.guard_hours)) });
    if (['projects', 'socials', 'autopilot', 'website'].includes(w)) await api('/api/flag', { key: w === 'website' ? 'website:seen' : `${w === 'projects' ? 'projects:reviewed' : `${w}:confirmed`}` });
    for (const key of Object.keys(S.typed)) if (/^(pf|vc|lk|plk|as|vf):/.test(key)) delete S.typed[key];
    await load();
    const next = S.d.steps.find(s => !s.done); S.step = next ? next.id : w; render(); window.scrollTo(0, 0);
    toast(next ? 'Saved.' : 'Setup is complete. HQ is running.');
  },
};

document.addEventListener('click', async e => {
  const t = e.target.closest('[data-act],[data-tab],[data-step],[data-go-step],[data-edit-proj],[data-new-proj]');
  if (!t) return;
  if (t.dataset.goStep) { S.step = t.dataset.goStep; }
  if (t.dataset.editProj) { S.tab.editproj = t.dataset.editProj; }
  if (t.dataset.newProj) { S.tab.editproj = 'new'; }
  if (t.dataset.step) { S.step = t.dataset.step; render(); return; }
  if (t.dataset.tab) { e.preventDefault(); S.tab[t.dataset.tab] = t.dataset.v; render(); return; }
  if (t.dataset.act && ACT[t.dataset.act]) { e.preventDefault(); await ACT[t.dataset.act](t); }
});
document.addEventListener('keydown', e => {
  if (e.key !== 'Enter' || e.shiftKey) return;
  const t = e.target; if (!t.dataset?.enter) return;
  e.preventDefault(); ACT[t.dataset.enter]?.(t);
});
document.addEventListener('change', async e => {
  const t = e.target;
  if (t.dataset.contact) { await api('/api/contacts', { id: Number(t.dataset.contact), status: t.value }); await load(); }
  if (t.dataset.auto) { await api('/api/settings', { autopilot: { [t.dataset.auto]: t.checked } }); await load(); }
  if (t.dataset.verify) { await api('/api/verify', { id: t.dataset.verify, ok: t.checked, answer: S.typed[`vf:${t.dataset.verify}`] }); await load(); }
  if (t.dataset.projActive) { await api('/api/projects', { id: Number(t.dataset.projActive), status: t.checked ? 'active' : 'paused' }); await load(); }
  if (t.dataset.k === 'ml:provider') render();
});

load().catch(e => { $('#main').innerHTML = `<div class="panel"><h2>HQ could not load</h2><p class="muted">${esc(e.message)}</p></div>`; });
