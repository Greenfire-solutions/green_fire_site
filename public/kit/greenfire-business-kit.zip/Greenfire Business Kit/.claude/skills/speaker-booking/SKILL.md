---
name: speaker-booking
description: Run a speaking engagement from first inquiry to paid and referred, the way a professional speaker's office does - qualify, quote, hold, contract, deposit, advance, show day, invoice, thank-you, testimonial, referral. Use when a speaking inquiry arrives, when the owner asks what to charge or what to send next, when an event is confirmed, when preparing for a keynote, and after an event to collect the testimonial and the next booking.
---

# Speaker booking, end to end

## 1. Qualify (reply within hours, not days)

The Inbox Concierge drafts the first reply. It asks only what is missing of:
date and time zone; in person (city) or virtual; audience size and who they are;
theme or intention; keynote (45 to 60 min), workshop (90 min) or group activation;
budget range; decision date. Speed wins bookings: the guard alerts after 6 hours.

## 2. Quote

- Never quote until the fee range is set on Setup (it is asked there on purpose).
- Quote a fee for the format, plus travel and accommodation for in-person events
  (economy or business per the owner's rule, one or two nights), or a flat
  all-inclusive figure. Virtual is usually a lower tier.
- Non-profit and university rates are the owner's call, never an agent's.
- If a speaking agency represents him, say the agency will send the agreement, and
  copy them.

## 3. Hold and contract

- A date is HELD for a set number of days (for example 7) pending contract.
- The agreement covers: fee, deposit (commonly 50% to confirm), balance due date
  (on or before the event), travel and accommodation, AV (handheld or lavalier mic,
  space for the audience to stand and breathe), recording and usage rights,
  cancellation terms, force majeure, the client's point person.
- The date is booked when the deposit lands, not when someone says yes.

## 4. Advance (two to three weeks out)

A call or an email: the run of show, the room, the audience in their words, the
one change they want people to leave with, the AV check time, who introduces him
(send the intro text: short bio from the profile), and whether a book or product
table or a QR to the owner's offer is allowed.

## 5. Show day

Arrive for the AV check. Bring a backup of any slides or audio. Capture: a phone
on a tripod for clips (with permission), the organiser's name for the thank-you.

## 6. After (where the next booking comes from)

- Same day or next: thank-you email to the organiser.
- Within a week: ask for a two to three sentence testimonial and permission to use
  their logo; ask "who else should hear this?" for one referral.
- Invoice the balance if not paid; the follow-up clock reminds.
- Clips go to the Drop Media Here folder: a stage moment is the best proof post.
- Add the organisation to the credentials ONLY once the owner approves the wording.
