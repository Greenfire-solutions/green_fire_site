---
name: post-in-my-voice
description: Write and schedule social posts that sound like the owner, carry one real thought, end with an honest question, and turn attention into sales with Comment-to-get. Covers the voice rules and checks, the content pillars per project, the weekly rhythm, the drop folder, scheduling one post a day on free days, and what never to post. Use when making posts or captions, when a caption was refused, when posts feel random, when planning a week of content, or when the owner says posts "sound like AI".
---

# Posting in the owner's voice

## The voice (from the owner's own words, on Setup step 5)

Read the voice note and the samples on the owner's profile before writing. Match
their sentence length, their words and what they never say. A signature line or
contrast they use often is theirs to use; never invent one.

## Every caption passes this check (code, `voice.mjs`)

- ONE real thought worth reading even for someone who never buys.
- **Ends with a question** a real person would want to answer, on the same
  subject. Never "what do you think?", "thoughts?", "tag a friend", "drop a ...".
- Under 400 characters before the Comment line.
- No long dashes. Three hashtags at most (usually none). Two emoji at most. One
  exclamation mark at most.
- No brand or machine tells: "excited to share", "stay tuned", "game changer",
  "dive in", "unlock your potential", "link in bio".
- **No health promises.** Never "cures", "heals your anxiety", "clinically proven",
  "replace therapy". Describe what the practice feels like and what people report.
- Never a fact, number, client or result that is not in the facts.

## Comment-to-get (where posts become sales)

Instagram captions get, just above the closing question:
"Comment GUIDE and I'll send you the free guide." HQ answers each comment with
one private DM (link to the offer) and a public "Sent, check your DMs". One DM per
person per post, last 7 days only, 40 a run. Each project sets its own keyword
(Projects, Edit). Other channels get the caption without the Comment line.

## Pillars (the week has a shape, so posts never feel random)

| Day | Pillar | What it is |
|---|---|---|
| Mon | Method | One step of the owner's method or process, shown in 20 seconds |
| Wed | Proof | A real moment from the work: a client result they agreed to share, a behind the scenes |
| Fri | Story or idea | Something the owner lived or believes, in plain words |
| Sun | Offer | What the offer changes, with the Comment keyword |

If the owner has a signature method (profile, system), the Monday post rotates
through its steps. When the drop folder is empty, Studio files a "Film this week"
card with a 4-line shot list so filming takes five minutes.

## Mechanics

- Drop photos and clips in **Drop Media Here**. Studio builds each (a phone .mov
  becomes H.264 MP4; a photo becomes a 9 second slow push-in for Reels), writes the
  caption, and picks the next **free day** at the post time (default 17:30). One
  post a day: two posts the same morning was a real failure once.
- Nothing posts without the owner's yes. A channel that published is never posted
  to again; one that failed shows its own reason.
- One person, one picture: never post the same photo twice under different words.

## What never gets posted

Client faces or stories without written consent. Anything about a session's
content. Medical language. Prices that will be wrong on the day it posts.
