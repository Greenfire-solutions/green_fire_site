---
name: connecting-channels
description: Connect the owner's social posting channels (Instagram, Facebook Page, Bluesky, Zapier for TikTok/LinkedIn/YouTube) and the media hosting Instagram needs, so HQ's Studio can publish approved posts. Covers the Meta developer app end to end, the exact scopes, the token traps, Cloudflare R2 hosting and Bluesky app passwords. Use when the owner wants posting set up, when a channel test fails on Setup step 6, when a post shows "failed" in Studio, or when a token needs renewing.
---

# Connecting the posting channels

HQ posts only what the owner approved, at the time they approved it. Before it
can, each channel needs one credential, pasted on **Setup, step 6 (Socials)**,
where every channel has its own "Save and test" button. A test proves the
credential works and names the account it reaches. It never posts.

## Order of work (least effort first)

1. **Bluesky** (2 minutes). Settings, Privacy and security, App passwords, Add.
   Paste the handle and the app password. Never the real password.
2. **Facebook Page** (part of the Meta app, below). Posting works to a PAGE,
   never a personal profile: Facebook removed profile posting for apps in 2018.
3. **Instagram** (the Meta app, below, plus media hosting). Business or Creator
   account only, linked to the Facebook Page.
4. **Media hosting** (Cloudflare R2, free tier). Instagram never accepts a file,
   only a public https link that Meta fetches itself. HQ uploads each approved
   post to the owner's own bucket first. Steps are on Setup.
5. **Zapier** for everything without an open posting API (TikTok, LinkedIn,
   YouTube Shorts, Threads, Pinterest). Make a Zap starting with "Webhooks by
   Zapier, Catch Hook", paste its link, press Save and test, then build the rest
   from the test event. HQ sends `post.publish` with the caption and media link.

## The Meta app, end to end

Read `references/meta-app-walkthrough.md` before starting: it is the full click
path with every screen. The four things that cost real time before:

- The dashboard's setup text prints the scope as `instagram_content_publishing`.
  **That string does not exist.** The real scope is `instagram_content_publish`.
- **`pages_manage_posts` lives in the Pages use case, not the Instagram one.**
  Following only the Instagram walkthrough leaves Instagram working and Facebook
  failing with a bare permissions error.
- The OAuth popup can end on "An invalid Platform session was found" AFTER the
  grant saved. Check facebook.com, Settings, Business integrations: if the app is
  Active, just generate the token again. Do not redo the flow.
- **Leave the app in Development mode.** Development restricts the app to people
  with a role on it, and Standard Access already covers posting to your own
  accounts. "Publishing" the app starts an App Review nobody needs.

Use a long-lived **Page** token (Graph API Explorer, pick the app, choose the
Page). A Page token derived from a long-lived user token does not expire.

### Comment-to-get (optional)

Answering "Comment STATE" with a DM also needs `instagram_manage_comments` and
`instagram_manage_messages` (or the `instagram_business_*` versions), plus the
Instagram phone app switch: Settings, Messages and story replies, Connected
tools, Allow access to messages. Until Meta grants Advanced Access, DMs reach
only people with a role on the app; HQ then answers in public ("The link is in
my bio") instead of failing silently. Adding a scope to the app is not enough:
regenerate the token after a page reload, or Meta reuses the old grant.

## When a post fails

Studio's calendar shows each channel's own result. One channel failing never
re-posts to the channels that worked. Common causes, in order: an expired user
token used instead of a Page token; media hosting not set up (Instagram only);
a video Instagram could not process (re-export as H.264 MP4, under 90 seconds);
Bluesky image over 1 MB.

## Hard rules

- Never echo, screenshot or store a token anywhere but HQ's own secrets file.
- Never post to test a connection. The test buttons exist so nothing has to.
