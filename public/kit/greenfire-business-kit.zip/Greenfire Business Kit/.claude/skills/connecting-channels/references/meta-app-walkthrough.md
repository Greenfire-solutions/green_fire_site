# The Meta app, screen by screen

Read this when actually walking an artist through it. `SKILL.md` carries the
principles; this is the click path, in order, with what each screen looks like
when it is right.

Roughly an hour. Free. No App Review — posting to accounts you own is Standard
Access, which works while the app sits in Development mode.

---

## Before starting — two things must already be true

1. **The Instagram account is Business or Creator.** Instagram app → Settings →
   Account type and tools. A personal account cannot publish through the API at
   any tier.
2. **It is linked to a Facebook Page.** Create the Page first if there is none.

Neither is checkable from the terminal. They surface later as an empty account
list in the consent flow, with no explanation — so confirm them out loud before
starting rather than discovering it forty minutes in.

---

## 1 · Create the app

**developers.facebook.com/apps/ → Create App → type: Business**

Then add **both** use cases:

- *Manage messaging & content on Instagram*
- *Manage everything on your Page*

The second one is not optional. It is where `pages_manage_posts` lives, and
without it Facebook Reels cannot publish.

The app list will show `Mode: In development`. **Leave it there.** There is a
"Publish" item in the left nav marked *Unpublished* — ignore it permanently.

Note the **App ID** from this screen. It is not secret.

---

## 2 · Switch to the Facebook Login path

**Use cases → "Manage messaging & content on Instagram" → Customize**

The page opens on **API setup with Instagram login**. That is the wrong path —
it needs no Facebook Page but cannot post Facebook Reels.

In the left nav, click **API setup with Facebook login**.

> The Instagram app ID and Instagram app secret shown on the *Instagram login*
> page are different values from the app's own App ID and secret. You want the
> app's, from App settings → Basic. Taking the ones on this screen is a common
> and confusing dead end.

On the Facebook login page, click **Add required content permissions**. It
should confirm "Content management permissions added."

That adds: `instagram_basic`, `instagram_content_publish`, `pages_read_engagement`,
`business_management`, `pages_show_list`.

> The bullet list on this page says **`instagram_content_publishing`**. That
> string does not exist. The real scope, and what the permissions table lists,
> is `instagram_content_publish`. A Meta-side typo.

**Messaging permissions are only for Comment-to-get.** If you only post, skip them. A credential that
can also read DMs is a credential worth stealing.

---

## 3 · Add `pages_manage_posts`

**Use cases → "Manage everything on your Page" → Customize**

A long permissions table. Find `pages_manage_posts` → **Add**.

The Status column should change to **Ready for testing**. If it throws
"Something went wrong", dismiss and click Add again — it frequently succeeds on
the retry, and sometimes the first click worked anyway. Re-read the row before
assuming it failed.

### Confirm the full set

**Instagram use case → Permissions and features.** These six should read
*Ready for testing*:

| Scope | Serves |
|---|---|
| `instagram_basic` | Instagram |
| `instagram_content_publish` | Instagram |
| `pages_show_list` | both |
| `pages_read_engagement` | both |
| `pages_manage_posts` | Facebook Reels |
| `business_management` | listed by Meta; posting does not need it |

Everything named `instagram_business_*` should be **unadded** — those belong to
the Instagram Login path.

---

## 4 · Generate the token

**Tools → Graph API Explorer** (developers.facebook.com/tools/explorer/)

- **Meta App**: the app you just made
- **Permissions**: add all six above. Type each name, pick it from the dropdown.
- **User or Page**: leave on the default / **User Token**. HQ derives
  the Page token itself — a Page token from a long-lived user token is the
  durable one.

Click **Generate Access Token**. A popup opens. Work through *every* screen:

### Screen 1 — Pages

Radio: **Opt in to current Pages only** → tick the artist's Page → Continue.

### Screen 2 — Businesses

Radio: **current Businesses only** → tick one → Continue.

This screen appears because `business_management` was requested. **Continue is
disabled until something is ticked** — `0 Assets Selected` in the corner is the
tell. If the artist's Page is not in any portfolio, ticking whichever portfolio
exists is harmless; the Page grant from screen 1 is what matters.

### Screen 3 — Instagram accounts

Radio: **current Instagram accounts only** → tick the account → Continue.

**If the list is empty, stop.** The Instagram account is not linked to that Page
as Business or Creator. Fix it in the Instagram app and start the token over.

### Screen 4 — Review

Six plain-English lines, each reading "1 … selected":

| Review line | Scope |
|---|---|
| Manage your business | `business_management` |
| Access profile and posts from the selected Instagram account | `instagram_basic` |
| Upload media and create posts for the Instagram account | `instagram_content_publish` |
| Create and manage content on your Page | `pages_manage_posts` |
| Read content posted on the Page | `pages_read_engagement` |
| Show a list of the Pages you manage | `pages_show_list` |

**Save** → "… has been connected to …" → **Got it**.

### If it lands on "An invalid Platform session was found"

The URL will contain `/dialog/oauth/business/cancel/`. The grant has very likely
**already saved**; only the hand-off back to the Explorer failed.

Do not redo the flow. Check **facebook.com → Settings → Business integrations**.
If the app is listed under *Active*, click **Generate Access Token** again — it
will not re-walk the four screens, and the token appears immediately.

Quitting any leftover Facebook popup windows first makes this less likely.

---

## 5 · Hand the token to the tool

The Access Token box now holds a long string beginning `EAA`. Copy it with the
**copy icon** beside the box — a drag-select clips it, and a clipped token fails
with `Cannot parse access token`, which reads like an expiry and is not one.

Then, in a real terminal:

```
node meta.mjs setup
```

It asks for three values, none of which echo:

1. **App ID** — App settings → Basic
2. **App Secret** — same page, click *Show*
3. **The token** — from the Explorer

It validates the shape of each locally before contacting Meta, stores the app id
and secret *before* attempting the exchange (so a bad token paste costs one
prompt, not three), then exchanges for a long-lived token, reads `me/accounts`
to find the Page, reads the Instagram Business account hanging off it, stores
all five in the keychain, and verifies.

**The Explorer token lives about an hour and does not announce that it expired.**

---

## 6 · What a good result looks like

```
META
graph v26.0
✔ token is valid   type PAGE
✔ token itself does not expire
✔ data access expires in 90 days
✔ instagram_basic            instagram only
✔ instagram_content_publish  instagram only
✔ pages_show_list
✔ pages_read_engagement
✔ pages_manage_posts         facebook only
✔ Facebook Page: <the Page's name>
✔ Instagram: @<handle>   <n> posts

Nothing was posted.
```

Read the **Page name and handle** back to the artist. A valid token pointed at
the wrong Page is invisible until the first post lands somewhere unexpected.

`type PAGE` and `does not expire` are both expected and correct.

---

## Renewing, months later

Posting stops with no visible cause. Almost always `data_access_expires_at` —
the 90-day clock that runs down while `is_valid` stays `true`.

1. `node meta.mjs check` — look at the *data access* line, not the token line.
2. Re-authorise the app: repeat step 4 (Generate Access Token, work the screens).
3. `node meta.mjs setup` — it reuses the stored app id and secret, so this is
   one paste.

The app, its permissions and its use cases all persist. Only the token is
renewed.
