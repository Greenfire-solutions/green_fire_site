---
name: inbound-email-desk
description: How HQ's Inbox Concierge reads the owner's mailbox, sorts every message by project and intent, drafts the reply in the owner's voice with the right offer, and makes sure no booking or speaking inquiry is ever lost. Use when setting up or changing inbound email, when a reply draft is wrong, when an inquiry was missed, when replies "look like code", when an out-of-office stopped a follow-up, or when the owner asks how to answer a type of inquiry (speaking, session, podcast, partnership, press, product support).
---

# The inbound email desk

The job, in the owner's words: every person who writes gets the right answer,
fast, in his voice, and nobody who wants to pay him is ever left waiting.

## How it works in HQ

1. **Read, never touch.** HQ signs in with an **app password** (never the real
   password, never OAuth: a Gmail OAuth token for an unverified personal app
   expires every 7 days; an app password does not). It opens the inbox with
   EXAMINE and BODY.PEEK, so it structurally cannot delete, move or mark read.
2. **Oldest first, from a bookmark.** New mail is read from a saved UID position,
   40 at a time, oldest first. Taking the newest 40 and jumping the bookmark loses
   every older inquiry after a busy weekend, silently.
3. **Sort the machine mail out first:**
   - *Bounces* (mailer-daemon, multipart/report). An address is marked dead ONLY on
     proof of a permanent failure (a 5.x.x status). A delay, a full mailbox or
     anything unrecognised keeps the contact. Never remove a contact who has ever
     written back: that address demonstrably works.
   - *Auto-replies* ("out of office", "we'll reply in 24h"). An autoresponder is
     NOT an answer: the follow-up clock keeps running.
   - *Website forms* send from a robot address with the real person in Reply-To.
     Answer the person.
4. **Triage each human message:** which project, which intent (speaking, session,
   product, podcast, partnership, press, student, personal, sales, other), urgency
   0 to 3, one line summary, what is still unknown, and a drafted reply.
5. **One card per message.** The reply waits for the owner's yes. Editing it before
   sending teaches HQ his voice (the change is learned, the facts never are).
6. **Never lose an inquiry.** A speaking, session, podcast, partnership or press
   message unanswered after 6 hours (Setup, Autopilot) raises a red card and a Mac
   notification. No AI is on this path, so a signed-out AI cannot silence it.

## How each kind of inquiry is answered

| Intent | The reply does | Never |
|---|---|---|
| Speaking | Thanks them, shows interest in THEIR event, asks only what is missing: date, city or virtual, audience size and who they are, theme, budget range. Offers a short call. If a speaking agent handles contracts, says they will be copied. | Quote a fee before the owner fills the fee range on Setup. |
| Private session | Explains the two formats with exact prices and the booking link, asks what they want to change. | Promise outcomes or health results. |
| Product support | Solves it in two lines with the right link. Refunds or account changes: "I'm looking into it personally." | Argue. |
| Podcast | Yes in principle, asks date, format, audience, the angle they want, offers the signature idea as the topic. | Accept a paid "feature" without flagging it as paid. |
| Partnership | Warm, curious, asks what they have in mind, timeline and budget. | Agree to anything. |
| Press | Asks deadline, outlet, angle; offers the short bio. | Comment on anything not in the profile. |
| Sales spam | No reply, no card. | |

## Qualifying a speaking inquiry (what the owner needs before saying yes)

Date and time zone; in person (city) or virtual; audience size and who they are;
theme or intention of the event; keynote, workshop or activation; length; budget
or fee range; AV (handheld or lavalier mic, room to stand and breathe); travel and
accommodation; recording rights; decision date. The reply asks for the missing ones
only, never all eleven.

## Traps already paid for

- A multipart message decoded as one string turned replies into base64 garbage. A
  part's encoding is a property of the part: walk the MIME tree.
- Quoted history has four shapes (Gmail's wrapped "On ... wrote:", Outlook's
  underline then headers, a bare From/Sent/To block, ">" lines). The EARLIEST
  mark wins.
- An empty password saved by a non-interactive prompt looked "set" everywhere.
  A secret that cannot be read back is a failed write.
- A filter on info@ or support@ senders dropped real clients writing from their
  own company's shared box. Only true machine senders are filtered.
