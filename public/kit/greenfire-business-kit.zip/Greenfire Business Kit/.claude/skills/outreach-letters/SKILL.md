---
name: outreach-letters
description: Write and run the owner's outreach letters: one standard letter per audience, a personal first line from real research, the follow-up clock (three weeks, six weeks, then stop), daily caps that hold instead of refusing, and the guards that refuse long dashes, blanks and any claim that is not the owner's. Use when writing or changing a first letter or follow-up, when a letter was refused, when the owner rewrites a good letter and wants it to become the standard, and when planning how many letters go out.
---

# Outreach letters

## The shape of a letter that gets answered

1. **Their name and their thing first.** `{{HOOK}}`: one true sentence about them,
   from the Scout's research. If there is no hook, the paragraph is dropped, never
   left blank.
2. **Who you are in one line, with proof they can check.** Only credentials on the
   profile list, for example "I've worked with 40 local businesses this year." Never
   a number that is not on the list.
3. **What THEY get.** The change your offer makes for them, in their words, built
   around what the Scout learned about them.
4. **One easy question.** "Would it help if I sent a short outline built around your
   people?" Not "let me know your thoughts". Not a calendar link in a first letter.
5. Under 150 words. Plain text. No long dashes, ever: readers spot them and decide a
   machine wrote it. "Thanks for your time," then the signature.

## Different audiences, different letters

Each audience gets its own letter (Outreach, the project's tab, "Your standard
letters"). A corporate wellbeing lead, a conference programmer and a podcast host
want different first lines and different proof. A letter written for one and
mailed to all reads as a form letter, and the people who book speakers see a
hundred a week.

## The blanks

`{{FIRST}}` first name ("there" when unknown), `{{ORG}}`, `{{HOOK}}`,
`{{SIGNATURE}}`, `{{LINK}}` (the project's link). A letter with any blank left is
refused.

## Making a good letter the standard

When the owner rewrites one letter and it is better, copy it into the project's
standard letter, then put the blanks back where the person's details were. Read it
once as if it were going to a different organisation: if anything of the first
recipient survives (their name, event, city), it is a leak and the next 50 people
get told about someone else's event. A name that is ALSO one of the owner's
credentials (a famous client) stays: only mentions beyond the owner's own count.

## The clock

- First letter, then **one follow-up after 21 days, one more after 42, then stop.**
  Two chases is the whole budget. A reply stops the clock; an auto-reply does not.
- The clock reads the LAST contact, so a reply resets it.

## Caps that never say no

`Outreach letters per day` (default 20) protects the domain's reputation. Over
the cap, a yes is **held** and goes after midnight with no second press. A cap
refusal is never shown as an error: the system already knew, so it waits.

## The guards (in code, every send)

Long dash in subject or body (refused with the line number). Blank left in.
A number with a plus, a comma-thousands or a percent that is not in the owner's
credentials, bio, or the project's price and facts. A first letter to someone
already written to (never sent twice). An empty body.

## Delivery hygiene

Send from the owner's real address (Google Workspace app password). Keep daily
volume modest and steady; one person, one letter. Use the `claim-warden` agent on
any new standard letter before it goes to more than a handful of people.
