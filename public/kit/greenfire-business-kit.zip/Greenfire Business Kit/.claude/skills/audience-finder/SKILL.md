---
name: audience-finder
description: Find the exact people who buy each of the owner's projects, strategically, and only with addresses that are really theirs. Covers who to target per project (speaking, sessions, digital products, ventures), the search descriptions the Audience Scout uses, how addresses are verified from the organisation's own site, dedupe that never deletes, and ranking by fit. Use when the owner wants more leads, prospects, event planners, conference programmers, podcasts, partners or referral sources; when adding an audience to a project; when a lead list looks wrong or thin; and before any outreach wave.
---

# Finding the right audience

Outreach fails for one reason more than any other: writing to people who never
buy this thing, or to an address nobody reads. This skill is the opposite: few,
right people, reached at a real address, with one true sentence about them.

## Who buys what (fill one row per offer)

| Offer kind | Who decides | Where they are found | Best door |
|---|---|---|---|
| Services for businesses | The owner or the manager who feels the problem | The business's own site (about, team, contact pages), local directories, chamber of commerce lists | A short email naming something true about their business |
| Speaking & workshops | Heads of People, Learning, Wellbeing; event and offsite leads; conference programmers | Company people pages, "speak at" and "call for speakers" pages, past agendas | Their speaker form (Application Scribe) or the programming email |
| Sessions / consulting | Referral partners who serve the same people: coaches, therapists, accountants, agencies | Practice websites, directories | A referral conversation, never a cold sale |
| Digital products & courses | Podcast hosts, newsletter writers and creators in the same lane | Podcast sites, "be a guest" forms, newsletter about pages | A guest pitch with one useful idea as the hook |
| Local business | Neighbouring businesses, local groups, event organisers | Town directories, community calendars | An offer to collaborate or cross-promote |
| Partnerships | Partnerships or marketing leads at aligned brands | Brand sites, press pages | A specific idea for a collaboration |

Each line becomes an **audience** on the project (Projects, Edit, "Audiences to
search": `label | exact search description`). The Scout works one audience per
run, round robin, so a week covers them all.

## How the Scout searches (and why it is built this way)

- **Only Claude can search**, with WebSearch and WebFetch and NOTHING else, and it
  is never shown mail or contacts. An agent that reads strangers' words AND can
  reach the web AND can send is the dangerous combination. No agent holds all three.
- **An address counts only if printed on the organisation's own website** (same
  domain), and is never a role box (no-reply, privacy, billing, jobs, press for a
  sales pitch). Never guessed, never built from a pattern like first.last@. No
  address printed means the route is their form, and the Application Scribe takes it.
- **Every prospect carries a source page** and a `hook`: one true, specific sentence
  about THEM (their event's theme this year, a recent episode). Facts about the
  owner never go in a hook.
- **Dead listings are retired, not pitched.** "Cancelled", "on hiatus", "no longer"
  in the name; a latest event in a past year is flagged and sunk to the bottom.

## Dedupe and ranking: wrong in the DELETING direction is the silent failure

- Two finds of the same organisation fold into one. Match on exact email, or same
  website domain, or **subset** name match (every word of the shorter name appears
  in the longer). "Half the words match" silently ate real prospects that shared
  one word with something else. Parentheticals are stripped first.
- Fit **ranks, never deletes**. A low fit goes to the bottom with its reason.
- Run the `filter-and-gate-reviewer` agent after changing any filter.

## A good search description

Bad: "wellness conferences". Good: "Wellness, biohacking and human performance
conferences in the US with 300+ attendees and a published call for speakers for
2027, or a named programming director". The more it names the DECIDER and the
SIGNAL that they are buying now, the better the list.

## Before any outreach wave

Ask the `outreach-readiness` agent: are the letters true, the links live, the fee
range set, the claims all on the credentials list, the daily cap sensible?
