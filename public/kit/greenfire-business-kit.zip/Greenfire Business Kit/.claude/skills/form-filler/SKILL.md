---
name: form-filler
description: How HQ's Application Scribe reads and fills speaker applications, calls for speakers, podcast guest forms and contact forms in a visible Chrome window, answers from the owner's kit, asks every unanswerable question on ONE card, remembers the answers, and never pays. Use when the owner pastes a form link, when an application stopped halfway, when a box was filled wrong, when deciding whether the Scribe may press Submit by itself, or when a form needs a sign-in.
---

# The form filler

## The flow

1. **Read** (headless Chrome, a throwaway profile, signed in to nothing). Most
   event sites are an empty shell until their JavaScript runs, which is why a
   plain fetch reads nothing. The reader waits until the page stops changing, then
   lists every box with its LABEL. A page that only links to the real form (a
   Google Form behind a "Speak at our event" page) is followed, preferring a link
   whose words are about speaking, presenting, guests or applications over one
   about volunteers or vendors. Several forms and none clearly right: it says so
   instead of guessing.
2. **Answer from the kit**: name, email, website, socials, city, bios (short and
   long), talk title, talk description, topics, past clients, headshot file,
   speaker reel. Then from the owner's **kept answers** (every answer he ever gave
   on a form card). Long boxes like "why our event" are drafted from his own facts
   and flagged "drafted, check it".
3. **Ask once.** Every required box nothing answers goes on ONE card as a numbered
   list. His single reply is split back to the boxes and kept for every later form.
   A form that needs two answers must never take two round trips.
4. **Fill** on his yes, in a Chrome window he can watch, outlined in gold. Boxes are
   matched by label read again at fill time (forms change). A label found twice is
   left empty and reported: a wrong box is worse than an empty one. It presses Next
   between pages; it never presses a button that submits, sends, pays, applies,
   finishes or confirms.
5. **Submit.** By default the owner presses Submit in the window, then "It's
   submitted" on the card, which starts the follow-up clock. If he switches on
   "Let the Scribe press Submit" (Setup, Autopilot), it presses the single send
   button only when every required box is answered and nothing mentions a fee or a
   card, then waits for a thank-you page.

## Rules

- **Never pays.** A form with an application fee or a card box stops before payment.
- **Never invents a fact.** Fee, dates, phone, a yes/no only he knows: asked.
- **Sign-in forms** (Google Forms set to require sign-in): the visible window keeps
  its own profile, so he signs in there once and presses Yes again.
- **A captcha challenge** that actually appears after Send stops it. Google Forms
  carry an invisible reCAPTCHA on every form; that alone is not a reason to stop.

## Traps already paid for

- `/form/` matched the word "perform" and sent the reader to a profile page.
- Google Forms make each checkbox option its own list item; grouping by list item
  turned one question into five.
- A label that wraps its own select read as the question plus every option.
- A get-involved page's first form is usually the volunteer or street-team form.
