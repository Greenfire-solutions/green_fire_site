---
name: event-flyers
description: Turn the posters for any event, workshop, retreat, training or keynote into readable 3D animated flyers cut to the beat of licensed music, then hand them to HQ's Studio to post as videos, at most two a week per event. Use when the owner wants flyers, promo videos, animated posters or social posts for anything with a date; when posters are dropped for an event; or when a flyer is "hard to read". Every event gets a NEW look (colours, frame, props), never one already used.
---

# Event flyers

A style that works for dated things: the poster floats on a lit 3D card in a
frame, everything pulses on the beat, and near the end the card flips to show
the date, the price line and the page. Built and proven on a real workshop
campaign before it was packaged here.

## The rules (keep all of them)

1. **Always easy to read.** No glitch, slicing or colour split, nothing crossing
   the words. The card face is lit just under the bloom threshold so text never
   blurs; it never tilts more than about 10 degrees; props pass in front only at
   the corners.
2. **A fun 3D feel.** Metal edge, a frame (portal rings, a spinning disc, a halo,
   a square of light), crystals, orbs or cubes drifting. The card sways on the
   beat and flips on a downbeat near the end to reveal the end card.
3. **Licensed music only, cut to the beat.** Songs come ONLY from
   `Drop Media Here/Music (licensed)/` (or `HQ_MUSIC`): music the owner owns or
   has a licence to use on social video. `flyers.py` fails closed when that folder
   is empty. A muted video beats a takedown. The beat grid must pass QC in
   `beats.py`, which refuses a song rather than guess.
4. **A different design every event.** One look per event from
   `scripts/looks.json`; `scripts/used.json` records which event took which look
   and `flyers.py` refuses to reuse one. New look: copy an entry, change every
   colour, the frame and the props.
5. **Only true prices and dates.** The strip says what will still be true on the
   day it posts ("EARLY RATE ENDS NOV 28"), or carries no number. Never invent
   seats left.
6. **No em or en dashes** on screen or in a caption. `flyers.py` refuses them.
7. **Every post is a video**, at most two a week per event. The still pictures are
   proofs for checking words, never posted.

## Needs

Blender 3.6 or newer in Applications, ffmpeg, Python 3 with numpy and Pillow
(`python3 -m pip install --user numpy pillow`). Check before promising a render:
Intel Macs render each video in 15 to 20 minutes; Apple Silicon is faster.

## How to make them

1. **Posters**, one per piece, 9:16 (1080x1920), headline but no date (the strip
   adds it). ChatGPT or any image tool makes good ones; keep the brand colours.
2. **Event file** next to the posters:

```json
{
  "event": "Spring Workshop", "date": "2027-03-19",
  "out": "/abs/path/Animated flyers",
  "look": "temple-dawn",
  "site": "yoursite.com/workshop",
  "logo": "/abs/logo.png or null",
  "title": "SPRING WORKSHOP",
  "backdrop": "/abs/texture.png or null",
  "strips": {"early": ["YOUR CITY · MAR 19 TO 21", "EARLY RATE ENDS FEB 1"],
             "full":  ["YOUR CITY · MAR 19 TO 21", "LIMITED SPACES"]},
  "end":    {"early": ["MAR 19 TO 21 · YOUR CITY", "EARLY RATE TO FEB 1"],
             "full":  ["MAR 19 TO 21 · YOUR CITY", "APPLY NOW"]},
  "pieces": [
    {"name": "Learn The Method", "poster": "/abs/poster-1.png", "strip": "early", "make": ["picture", "video"], "song": "licensed-track.wav"}
  ]
}
```

   `strip_y` moves the strip off a low headline (default 1360 of 1920; about 400
   for a headline at the bottom). `song` is a file name in the licensed folder.
3. `python3 .claude/skills/event-flyers/scripts/flyers.py <event.json> check`
   lists every piece and refuses songs that fail the gate. Plain `python3`, never
   `python3 -I` (numpy lives in user site-packages).
4. **Pictures first:** `... all --pictures`, about 5 seconds each. Read every one.
5. **Videos:** `... "<piece name>"`, one at a time, in the background. Check a
   strip of frames including the flip, and that the file is under 48 MB.
6. **Post through Studio.** Copy chosen videos into `Drop Media Here/` named
   `<Event> flyer - <Name> (<Mon DD>).mp4`. Studio makes each one a post card with
   a caption in the owner's voice; the owner's yes schedules it. Never schedule a
   post yourself: scheduling is the owner's yes.

## Traps that already cost time

- The glitch effect made the first flyers unreadable. Never bring it back.
- With no backdrop, the poster is used blurred past reading. Unblurred, its
  headline sits behind the card like a ghost.
- Beat detectors report double tempo. `beats.py` searches 74 to 140 BPM and
  checks the grid against a half-beat shift.
- EEVEE under the Filmic view transform washes the poster out. The scene uses
  Standard; do not change it.
