"""Event flyers: posters -> readable 3D pictures and beat-locked 3D videos.

    python3 flyers.py <event.json> check            what would be made, songs gated, nothing rendered
    python3 flyers.py <event.json> <piece-name>|all  make them
    python3 flyers.py <event.json> all --pictures   pictures only (seconds each)

Run with plain python3, NOT `python3 -I` (numpy and Pillow live in the user
site-packages on many Macs). Needs Blender 3.6+ at /Applications/Blender.app
and ffmpeg on the PATH.

An event file (see SKILL.md for the whole shape):
{
  "event": "The Art of the Remix", "date": "2026-11-14",
  "out": "/abs/folder/for/outputs",
  "look": "spinning-vinyl",                 a name in looks.json, NEW for every event
  "site": "yoursite.com/event",
  "logo": "/abs/logo.png" or null,          gold logo for the end card; else "title" is set in type
  "title": "THE ART OF THE REMIX",
  "backdrop": "/abs/painting.png" or null,  far background; else the poster, blurred
  "strips": {"early": ["LIVE ONLINE · SAT NOV 14 · 4PM CT", "$49 EARLY BIRD · ENDS OCT 28"], ...},
  "end":    {"early": ["SAT NOV 14 · 4PM CT", "$49 EARLY BIRD TO OCT 28"], ...},
  "pieces": [{"name": "...", "poster": "/abs/poster.png", "strip": "early",
              "make": ["picture", "video"], "song": "file in the music folder", "strip_y": 1360}]
}
"""
import json, os, shutil, subprocess, sys
from PIL import Image, ImageDraw, ImageFilter, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import beats as B  # noqa: E402

# Music the owner OWNS or has LICENSED for social posts, one file per song.
# Default: the "Music (licensed)" folder inside the HQ package. Override with HQ_MUSIC.
ROOT = os.path.abspath(os.path.join(HERE, '..', '..', '..', '..'))
MUSIC = os.environ.get('HQ_MUSIC') or os.path.join(ROOT, 'Drop Media Here', 'Music (licensed)')
BLENDER = '/Applications/Blender.app/Contents/MacOS/Blender'
COND = '/System/Library/Fonts/Avenir Next Condensed.ttc'      # 8 = Heavy, 2 = Demi Bold
W, H = 1080, 1920


# --- the rules that are not up for a vote --------------------------------------
def no_dashes(text):
    """House rule: no em or en dashes on anything public."""
    if '—' in text or '–' in text:
        raise SystemExit(f'em/en dash in on-screen text: {text!r}')


def allowed_songs():
    """The rights gate: only songs in the licensed folder. Fails closed: an empty
    or missing folder means no song may be used (a muted social video is
    better than a takedown)."""
    if not os.path.isdir(MUSIC):
        raise SystemExit(f'no licensed music folder at {MUSIC}; put songs you own or licensed there')
    songs = {f for f in os.listdir(MUSIC) if f.lower().endswith(('.mp3', '.wav', '.m4a', '.aif', '.aiff'))}
    if not songs:
        raise SystemExit('the licensed music folder is empty, so no song may be used')
    return songs


def font(size, index):
    return ImageFont.truetype(COND, size, index=index)


def sprite(text, fnt, fill, glow, stroke=3):
    l, t, r, b = fnt.getbbox(text, stroke_width=stroke)
    pad = 28
    im = Image.new('RGBA', (r - l + 2 * pad, b - t + 2 * pad), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.text((pad - l, pad - t), text, font=fnt, fill=tuple(glow) + (255,), stroke_width=stroke + 5,
           stroke_fill=tuple(glow) + (255,))
    im = im.filter(ImageFilter.GaussianBlur(10))
    d = ImageDraw.Draw(im)
    d.text((pad - l, pad - t), text, font=fnt, fill=tuple(fill) + (255,), stroke_width=stroke,
           stroke_fill=(15, 8, 25, 255))
    return im


def put(canvas, sp, x, y, scale=1.0):
    if abs(scale - 1) > 0.005:
        sp = sp.resize((int(sp.width * scale), int(sp.height * scale)), Image.LANCZOS)
    canvas.alpha_composite(sp, (int(x - sp.width / 2), int(y - sp.height / 2)))


def band(img, y0, y1):
    """Soft dark band so the strip reads over any art."""
    import numpy as np
    f = np.asarray(img).astype('float32')
    ys = np.arange(H)[:, None]
    mid, half = (y0 + y1) / 2, (y1 - y0) / 2
    k = np.clip(1 - abs(ys - mid) / (half + 90), 0, 1) ** 0.7 * 0.72
    f[..., :3] *= (1 - k[..., None])
    return Image.fromarray(f.astype('uint8'))


def picture_flat(ev, look, piece, path):
    """The poster with the date strip: the face of the 3D card."""
    S = look['strip']
    img = Image.open(piece['poster']).convert('RGB').resize((W, H), Image.LANCZOS).convert('RGBA')
    y = piece.get('strip_y', 1360)
    img = band(img, y - 90, y + 90)
    lines = ev['strips'][piece['strip']]
    for i, line in enumerate(lines):
        no_dashes(line)
        fill, glow = (S['line1'], S['glow1']) if i == 0 else (S['line2'], S['glow2'])
        if any(ch.isdigit() for ch in line) and '$' in line:
            fill = S['accent']
        sp = sprite(line, font(64, 8), fill, glow)
        scale = min(1.0, (W - 90) / (sp.width - 56))
        put(img, sp, W / 2, y + (i - (len(lines) - 1) / 2) * 84, scale)
    img.convert('RGB').save(path)


def end_card(ev, look, piece, backdrop, path):
    S = look['strip']
    bg = Image.open(backdrop).convert('RGB').resize((W, H), Image.LANCZOS).filter(ImageFilter.GaussianBlur(16))
    bg = Image.eval(bg, lambda v: int(v * 0.4)).convert('RGBA')
    y = 760
    if ev.get('logo'):
        logo = Image.open(ev['logo']).convert('RGBA')
        logo = logo.resize((960, int(960 * logo.height / logo.width)), Image.LANCZOS)
        put(bg, logo, W / 2, y)
    else:
        title = ev['title']; no_dashes(title)
        sp = sprite(title, font(120, 8), S['line1'], S['glow1'], stroke=4)
        put(bg, sp, W / 2, y, min(1.0, (W - 100) / sp.width))
    for i, line in enumerate(ev['end'][piece['strip']]):
        no_dashes(line)
        sp = sprite(line, font(78, 8), S['line1'] if i == 0 else S['accent'], S['glow1'] if i == 0 else S['glow2'])
        put(bg, sp, W / 2, 1210 + i * 108, min(1.0, (W - 120) / sp.width))
    sp = sprite(ev['site'], font(46, 2), S['line2'], S['glow1'], stroke=2)
    put(bg, sp, W / 2, 1460, min(1.0, (W - 100) / sp.width))
    bg.convert('RGB').save(path)


def blender(spec, work, tag):
    p = os.path.join(work, tag + '.json')
    json.dump(spec, open(p, 'w'))
    r = subprocess.run([BLENDER, '-b', '--gpu-backend', 'metal', '--python-exit-code', '1',
                        '--python', os.path.join(HERE, 'scene3d.py'), '--', p], capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit(r.stdout[-1500:] + r.stderr[-1500:])


def make(ev, piece, look, songs, pictures_only=False):
    out, work = ev['out'], os.path.join(ev['out'], '_work')
    os.makedirs(work, exist_ok=True)
    name = piece['name']
    flat = os.path.join(work, name + ' flat.png')
    picture_flat(ev, look, piece, flat)
    backdrop = ev.get('backdrop')
    if not backdrop:                    # the poster itself, blurred past reading so no giant ghost text sits behind the card
        backdrop = os.path.join(work, name + ' backdrop.png')
        Image.open(piece['poster']).convert('RGB').resize((W // 4, H // 4)).filter(ImageFilter.GaussianBlur(14)) \
            .resize((W, H), Image.BICUBIC).save(backdrop)
    seed = abs(hash(name)) % 1000
    if 'picture' in piece['make']:
        pic = os.path.join(out, name + ' (3D picture).png')
        blender(dict(mode='still', front=flat, backdrop=backdrop, out=pic, samples=48, seed=seed, look=look), work, name + ' still')
        Image.open(pic).convert('RGB').save(pic)
        print(f'{name}: picture -> {pic}')
    if 'video' not in piece['make'] or pictures_only:
        return
    song = piece['song']
    if song not in songs:
        raise SystemExit(f'{song}: not through the song gate (on his Spotify AND postable). Pick another.')
    g = B.grid(os.path.join(MUSIC, song))
    if not g['trusted']:
        raise SystemExit(f'{song}: beat grid failed QC ({g["qc_ratio"]}); pick another song')
    bar = 4 * g['beat']
    bars = max(4, int(round(17.5 / bar / 2)) * 2)
    sb = piece.get('start_bar', B.window(g, bars))
    t0, dur = g['downbeat0'] + sb * bar, bars * bar
    nb = bars * 4
    back = os.path.join(work, name + ' back.png')
    end_card(ev, look, piece, backdrop, back)
    fdir = os.path.join(work, name + ' frames')
    shutil.rmtree(fdir, ignore_errors=True); os.makedirs(fdir)
    blender(dict(mode='anim', front=flat, back=back, backdrop=backdrop, out=fdir, frames=int(round(dur * 30)),
                 beats=[i * g['beat'] for i in range(nb)], beat=g['beat'],
                 flip_at=(nb - (8 if nb >= 32 else 6)) * g['beat'], samples=16, seed=seed, look=look), work, name + ' video')
    mp4 = os.path.join(out, name + ' (3D video).mp4')
    subprocess.run([B.FFMPEG, '-y', '-v', 'error', '-framerate', '30', '-i', os.path.join(fdir, 'f_%04d.png'),
                    '-ss', f'{t0:.4f}', '-t', f'{dur:.4f}', '-i', os.path.join(MUSIC, song),
                    '-af', f'afade=t=in:d=0.04,afade=t=out:st={dur - 0.9:.3f}:d=0.9',
                    '-map', '0:v', '-map', '1:a', '-c:v', 'libx264', '-preset', 'medium', '-crf', '19',
                    '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '256k', '-movflags', '+faststart', '-shortest', mp4],
                   check=True)
    shutil.rmtree(fdir, ignore_errors=True)
    mb = os.path.getsize(mp4) / 1e6
    print(f"{name}: video {dur:.1f}s, {bars} bars at {g['bpm']} BPM from {t0:.1f}s into {song}, {mb:.0f} MB -> {mp4}")
    if mb > 48:
        print('  over Bluesky\'s 50 MB cap: re-encode with a higher -crf before dropping it in')


def main():
    ev = json.load(open(sys.argv[1]))
    looks = json.load(open(os.path.join(HERE, 'looks.json')))['looks']
    used = json.load(open(os.path.join(HERE, 'used.json')))['used']
    look_name = ev['look']
    if look_name not in looks:
        raise SystemExit(f'no look called {look_name}; add one to looks.json')
    owner = used.get(look_name)
    if owner and owner != ev['event'] + ' (' + ev.get('date', '') + ')':
        raise SystemExit(f'look {look_name} already belongs to {owner}. Every event gets its own look: pick or make another.')
    look = looks[look_name]
    want = sys.argv[2]
    pieces = [p for p in ev['pieces'] if want in ('all', 'check', p['name'])]
    needs_song = any('video' in p['make'] for p in pieces) and '--pictures' not in sys.argv
    songs = allowed_songs() if needs_song else set()
    if want == 'check':
        for p in pieces:
            ok = 'video' not in p['make'] or p.get('song') in songs
            print(f"{p['name']}: {', '.join(p['make'])}  strip={p['strip']}  song={p.get('song', '-')}  {'OK' if ok else 'SONG REFUSED'}")
        return
    os.makedirs(ev['out'], exist_ok=True)
    for p in pieces:
        make(ev, p, look, songs, '--pictures' in sys.argv)
    if not owner:
        used[look_name] = ev['event'] + ' (' + ev.get('date', '') + ')'
        json.dump({'comment': 'Which event took which look. Never give a look to a second event.', 'used': used},
                  open(os.path.join(HERE, 'used.json'), 'w'), indent=1)


if __name__ == '__main__':
    main()
