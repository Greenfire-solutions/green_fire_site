"""Blender (3.6, EEVEE) scene for event flyers. Run by flyers.py, never by hand:

    Blender -b --gpu-backend metal --python-exit-code 1 --python scene3d.py -- <job.json>

The look (frame, props, colours) comes from looks.json, one per event.

The poster is a real card with thickness and a gold edge, floating in a glowing
portal ring with crystals around it. The rule (from the first campaign): "a fun
3-D feel but always be easy to read". So:
  - the poster face is pure emission at strength just under the bloom threshold,
    under the Standard view transform: its colours are the file's colours and
    the text never blooms or blurs;
  - the card never tilts more than about 8 degrees, and nothing ever passes in
    front of the middle of it;
  - there is no slicing or colour splitting at all.
In the video the card FLIPS on a downbeat near the end to show its back, which
is the end card (logo, date, page), so both faces are always flat and legible.
"""
import bpy, json, math, sys, random
from mathutils import Vector

job = json.load(open(sys.argv[sys.argv.index('--') + 1]))
LOOK = job['look']                      # one entry of looks.json, chosen per event
random.seed(job.get('seed', 7))
FPS = 30
anim = job['mode'] == 'anim'
frames = job.get('frames', 1)
beats = job.get('beats', [])            # seconds, relative to the clip start
P = job.get('beat', 0.6)

bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
sc.render.engine = 'BLENDER_EEVEE'
sc.render.resolution_x, sc.render.resolution_y = 1080, 1920
sc.render.fps = FPS
sc.frame_start, sc.frame_end = 1, frames
sc.view_settings.view_transform = 'Standard'
sc.view_settings.look = 'None'
ee = sc.eevee
ee.taa_render_samples = job.get('samples', 24)
ee.use_bloom = True
ee.bloom_threshold = 1.0
ee.bloom_intensity = 0.035
ee.bloom_radius = 6.0
ee.use_gtao = True
ee.use_soft_shadows = True
w = bpy.data.worlds.new('w'); sc.world = w
w.use_nodes = True
w.node_tree.nodes['Background'].inputs[0].default_value = (*LOOK['world'], 1)


def env(t, decay=0.14):
    """1 on a beat, falling away; downbeats (every 4th) strongest."""
    best = 0.0
    for i, b in enumerate(beats):
        if b <= t + 1e-6:
            s = 1.0 if i % 4 == 0 else 0.55
            best = s * math.exp(-(t - b) / decay)
        else:
            break
    return best


def emis_mat(name, color, strength):
    m = bpy.data.materials.new(name); m.use_nodes = True
    nt = m.node_tree; nt.nodes.clear()
    o = nt.nodes.new('ShaderNodeOutputMaterial')
    e = nt.nodes.new('ShaderNodeEmission')
    e.inputs[0].default_value = (*color, 1); e.inputs[1].default_value = strength
    nt.links.new(e.outputs[0], o.inputs[0])
    return m, e


def image_mat(name, path, strength=0.97, alpha=False):
    m = bpy.data.materials.new(name); m.use_nodes = True
    nt = m.node_tree; nt.nodes.clear()
    o = nt.nodes.new('ShaderNodeOutputMaterial')
    tex = nt.nodes.new('ShaderNodeTexImage')
    tex.image = bpy.data.images.load(path)
    tex.interpolation = 'Cubic'
    e = nt.nodes.new('ShaderNodeEmission'); e.inputs[1].default_value = strength
    nt.links.new(tex.outputs[0], e.inputs[0])
    if alpha:
        tr = nt.nodes.new('ShaderNodeBsdfTransparent')
        mix = nt.nodes.new('ShaderNodeMixShader')
        nt.links.new(tex.outputs[1], mix.inputs[0])
        nt.links.new(tr.outputs[0], mix.inputs[1])
        nt.links.new(e.outputs[0], mix.inputs[2])
        nt.links.new(mix.outputs[0], o.inputs[0])
        m.blend_method = 'BLEND'; m.shadow_method = 'NONE'
    else:
        nt.links.new(e.outputs[0], o.inputs[0])
    return m, e


def gold_mat():
    m = bpy.data.materials.new('edge'); m.use_nodes = True
    b = m.node_tree.nodes['Principled BSDF']
    b.inputs['Base Color'].default_value = (*LOOK['edge'], 1)
    b.inputs['Metallic'].default_value = 1.0
    b.inputs['Roughness'].default_value = 0.25
    b.inputs['Emission'].default_value = (*LOOK['edge'], 1)
    b.inputs['Emission Strength'].default_value = 0.35
    return m


# --- the card: a thin box, poster on the front, end card on the back ----------
H = 2.0
Wd = H * 1080 / 1920
T = 0.045
card = bpy.data.objects.new('card', None); sc.collection.objects.link(card)


def face(name, path, y, flip):
    bpy.ops.mesh.primitive_plane_add(size=1)
    f = bpy.context.object; f.name = name
    f.scale = (Wd, H, 1)
    f.rotation_euler = (math.radians(90), 0, math.radians(180) if flip else 0)
    f.location = (0, y, 0)
    m, _ = image_mat(name, path)
    f.data.materials.append(m)
    f.parent = card
    return f


face('front', job['front'], -T / 2 - 0.001, False)
if job.get('back'):
    face('back', job['back'], T / 2 + 0.001, True)
bpy.ops.mesh.primitive_cube_add(size=1)
edge = bpy.context.object; edge.name = 'edge'
edge.scale = (Wd + 0.03, T, H + 0.03)
edge.data.materials.append(gold_mat())
edge.parent = card

# --- the frame behind the card: portal rings, a spinning record, a halo or a square
ring = bpy.data.objects.new('ring', None); sc.collection.objects.link(ring)
ring.location = (0, 0.55, 0.05)
ring_e = []
FC = [tuple(c) for c in LOOK['frame_colors']]
kind = LOOK['frame']
spin_axis = 'y'                         # rotate in the picture plane
if kind in ('portal', 'halo'):
    rings = [(1.12, 0.035, FC[0], 1.6), (1.2, 0.018, FC[1], 2.2), (1.04, 0.012, FC[2], 1.4)]
    if kind == 'halo':
        rings = [(1.15, 0.05, FC[0], 1.8), (1.28, 0.012, FC[1], 1.6)]
    for r, minor, col, st in rings:
        bpy.ops.mesh.primitive_torus_add(major_radius=r, minor_radius=minor, major_segments=128, minor_segments=16)
        tor = bpy.context.object
        tor.rotation_euler = (math.radians(90), 0, 0)
        m, e = emis_mat('ring%.2f' % r, col, st)
        tor.data.materials.append(m); tor.parent = ring
        ring_e.append((e, st))
    n = 12 if kind == 'portal' else 24
    for i in range(n):
        a_ = i / n * math.tau
        rr = 1.12 if kind == 'portal' else 1.15
        bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=2, radius=0.045 if kind == 'portal' else 0.025,
                                              location=(rr * math.cos(a_), 0, rr * math.sin(a_)))
        stud = bpy.context.object; stud.data.materials.append(gold_mat()); stud.parent = ring
    if kind == 'halo':                   # rays fanning out behind the halo
        for i in range(18):
            a_ = i / 18 * math.tau
            bpy.ops.mesh.primitive_cube_add(size=1, location=(1.75 * math.cos(a_), 0.3, 1.75 * math.sin(a_)))
            ray = bpy.context.object
            ray.scale = (0.012, 0.012, 0.55); ray.rotation_euler = (0, -a_ + math.pi / 2, 0)
            m, e = emis_mat('ray%d' % i, FC[2], 0.8)
            ray.data.materials.append(m); ray.parent = ring
            ring_e.append((e, 0.8))
elif kind == 'vinyl':
    ring.location = (0, 0.7, 0.05)
    bpy.ops.mesh.primitive_cylinder_add(vertices=128, radius=1.35, depth=0.03)
    disc = bpy.context.object; disc.rotation_euler = (math.radians(90), 0, 0)
    dm = bpy.data.materials.new('disc'); dm.use_nodes = True
    db = dm.node_tree.nodes['Principled BSDF']
    db.inputs['Base Color'].default_value = (0.01, 0.01, 0.012, 1)
    db.inputs['Roughness'].default_value = 0.18; db.inputs['Metallic'].default_value = 0.4
    disc.data.materials.append(dm); disc.parent = ring
    for i, r in enumerate([0.55, 0.75, 0.95, 1.15, 1.3]):       # glowing grooves
        bpy.ops.mesh.primitive_torus_add(major_radius=r, minor_radius=0.004, major_segments=128, minor_segments=6)
        g = bpy.context.object; g.rotation_euler = (math.radians(90), 0, 0); g.location = (0, -0.02, 0)
        m, e = emis_mat('groove%d' % i, FC[i % 2], 1.2); g.data.materials.append(m); g.parent = ring
        ring_e.append((e, 1.2))
    bpy.ops.mesh.primitive_cylinder_add(vertices=64, radius=0.4, depth=0.035)
    lab = bpy.context.object; lab.rotation_euler = (math.radians(90), 0, 0)
    m, e = emis_mat('label', FC[0], 1.0); lab.data.materials.append(m); lab.parent = ring
    ring_e.append((e, 1.0))
    # a notch so the spin is visible
    bpy.ops.mesh.primitive_cube_add(size=1, location=(0, -0.025, 1.05))
    nt_ = bpy.context.object; nt_.scale = (0.03, 0.01, 0.25)
    m, e = emis_mat('notch', FC[2], 2.0); nt_.data.materials.append(m); nt_.parent = ring
    ring_e.append((e, 2.0))
elif kind == 'square':
    for r, col, st, th in [(1.0, FC[0], 1.0, 0.02), (1.1, FC[1], 1.2, 0.012), (0.93, FC[2], 0.9, 0.008)]:
        hw, hh = r * 0.72, r * 1.18
        for (x, z, sx, sz) in [(0, hh, hw, th), (0, -hh, hw, th), (hw, 0, th, hh), (-hw, 0, th, hh)]:
            bpy.ops.mesh.primitive_cube_add(size=2, location=(x, 0, z))
            bar = bpy.context.object; bar.scale = (sx + th, th, sz + th)
            m, e = emis_mat('sq', col, st); bar.data.materials.append(m); bar.parent = ring
            ring_e.append((e, st))

# --- backdrop: his purple portal painting, far back and dimmed -------------------
bpy.ops.mesh.primitive_plane_add(size=1)
bg = bpy.context.object
bg.scale = (7.0 * 1080 / 1920, 7.0, 1)
bg.rotation_euler = (math.radians(90), 0, 0)
bg.location = (0, 4.0, 0)
m, _ = image_mat('bg', job['backdrop'], strength=0.38)
bg.data.materials.append(m)

# --- props: crystals, orbs or cubes, kept to the sides and corners ------------------
palette = [tuple(c) for c in LOOK['prop_colors']]
crystals = []
spots = [(-0.6, -0.3, 0.93), (0.62, -0.28, -0.95), (-0.72, 0.3, 0.15), (0.74, 0.35, 0.45),
         (-0.66, 0.45, -0.75), (0.62, 0.5, 1.12), (0.05, 0.7, -1.3)]
for i, (x, y, z) in enumerate(spots):
    pk = LOOK['props']
    if pk == 'orb':
        bpy.ops.mesh.primitive_uv_sphere_add(segments=48, ring_count=24, radius=random.uniform(0.07, 0.11))
    elif pk == 'cube':
        bpy.ops.mesh.primitive_cube_add(size=random.uniform(0.11, 0.16))
        bev = bpy.context.object.modifiers.new('b', 'BEVEL'); bev.width = 0.012; bev.segments = 3
    else:
        bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=1, radius=0.085)
    c = bpy.context.object
    if pk == 'crystal':
        for v in c.data.vertices:
            v.co *= 1 + random.uniform(-0.18, 0.18)
        c.scale = (1, 1, random.uniform(1.8, 2.6))
    c.location = (x, y, z)
    c.rotation_euler = (random.uniform(0, 3), random.uniform(0, 3), random.uniform(0, 3))
    col = palette[i % len(palette)]
    mm = bpy.data.materials.new('pr%d' % i); mm.use_nodes = True
    b = mm.node_tree.nodes['Principled BSDF']
    b.inputs['Base Color'].default_value = (*col, 1)
    b.inputs['Metallic'].default_value = 0.85 if pk == 'cube' else 0.3
    b.inputs['Roughness'].default_value = 0.08
    b.inputs['Emission'].default_value = (*col, 1)
    b.inputs['Emission Strength'].default_value = 0.5
    c.data.materials.append(mm)
    for p in c.data.polygons:
        p.use_smooth = pk == 'orb'
    crystals.append((c, b, Vector((x, y, z)), random.uniform(0, 6.28), random.uniform(0.6, 1.4)))

# sparks, all behind the card
sparks = []
sm, se = emis_mat('spark', tuple(LOOK['sparks']), 6.0)
for i in range(40):
    x = random.uniform(-1.8, 1.8); z = random.uniform(-2.2, 2.2); y = random.uniform(0.4, 2.5)
    bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=1, radius=random.uniform(0.008, 0.02), location=(x, y, z))
    s = bpy.context.object; s.data.materials.append(sm)
    sparks.append((s, Vector((x, y, z)), random.uniform(0.15, 0.4)))

# lights, so the crystals and the gold edge catch something
for loc, col, en in [((-2.2, -2.5, 2.0), tuple(LOOK['prop_colors'][0]), 900), ((2.4, -2.0, -1.0), tuple(LOOK['prop_colors'][1]), 700),
                     ((0, -3, 3.5), (1.0, 0.95, 0.85), 500)]:
    ld = bpy.data.lights.new('l', 'POINT'); ld.color = col; ld.energy = en; ld.shadow_soft_size = 1.0
    lo = bpy.data.objects.new('l', ld); lo.location = loc; sc.collection.objects.link(lo)

# --- camera ------------------------------------------------------------------------
cd = bpy.data.cameras.new('cam'); cd.lens = 50; cd.sensor_fit = 'VERTICAL'; cd.sensor_height = 24
cam = bpy.data.objects.new('cam', cd); sc.collection.objects.link(cam); sc.camera = cam
cam.rotation_euler = (math.radians(90), 0, 0)
# distance so the card fills ~80% of the frame height: h_vis = 2 d tan(fov/2)
fov = 2 * math.atan(12 / 50)
D_FILL = H / 0.74 / (2 * math.tan(fov / 2))


def ease(x):
    x = min(max(x, 0.0), 1.0)
    return x * x * (3 - 2 * x)


def pose(fr):
    t = (fr - 1) / FPS
    dur = frames / FPS
    e = env(t) if anim else 0.0
    prog = t / dur if anim else 0.4
    # the card sways gently; tilt stays under ~8 degrees so the words stay square
    sway = math.sin(t * math.tau / (8 * P)) if anim else 1.0
    nod = math.sin(t * math.tau / (16 * P) + 1.0) if anim else 1.0
    flip = 0.0
    if anim and job.get('flip_at') is not None:
        flip = ease((t - job['flip_at']) / (P * 1.25))
    card.rotation_euler = (math.radians(3.5 * nod), 0, math.radians(-10 * sway + 180 * flip))
    s = 1 + 0.014 * e
    card.scale = (s, s, s)
    card.location = (0, 0, 0.03 * math.sin(t * 1.3) if anim else 0.0)
    # the camera drifts in, and pulls back as the card turns over
    d = D_FILL * (1.08 - 0.08 * ease(prog) + 0.05 * flip)
    cam.location = (0.05 * math.sin(t * 0.4) if anim else 0.0, -d, 0.0)
    spin = {'vinyl': -120, 'square': 0, 'halo': -12}.get(LOOK['frame'], -25)
    sq = 4 * math.sin(t * 0.6) if LOOK['frame'] == 'square' and anim else 0
    ring.rotation_euler = (0, math.radians(spin * t + sq if anim else (0 if LOOK['frame'] == 'square' else 12)), 0)
    for (em, base) in ring_e:
        em.inputs[1].default_value = base * (0.75 + 1.1 * e)
    for c, b, home, ph, sp in crystals:
        c.location = home + Vector((0, 0, 0.06 * math.sin(t * sp + ph)))
        c.rotation_euler = (ph + t * 0.4 * sp, ph * 0.5, ph + t * 0.9 * sp)
        k = 1 + 0.16 * e
        c.scale = (k, k, k * c.scale[2] / c.scale[0]) if fr == 1 else (k * 1, k * 1, c.scale[2] / c.scale[0] * k)
        b.inputs['Emission Strength'].default_value = 0.45 + 1.6 * e
    for s_, home, v in sparks:
        z = (home.z + v * t + 2.2) % 4.4 - 2.2
        s_.location = (home.x + 0.05 * math.sin(t + home.y), home.y, z)
    se.inputs[1].default_value = 4 + 8 * e


# fixed crystal proportions (scale above multiplies the stored z-stretch)
for c, *_ in crystals:
    c['zs'] = c.scale[2]


def pose_fixed(fr):
    pose(fr)
    t = (fr - 1) / FPS
    e = env(t) if anim else 0.0
    for c, *_ in crystals:
        k = 1 + 0.16 * e
        c.scale = (k, k, c['zs'] * k)


if not anim:
    pose_fixed(1)
    sc.render.image_settings.file_format = 'PNG'
    sc.render.filepath = job['out']
    bpy.ops.render.render(write_still=True)
else:
    def handler(scene, *_):
        pose_fixed(scene.frame_current)
    bpy.app.handlers.frame_change_pre.append(handler)
    sc.render.image_settings.file_format = 'PNG'
    sc.render.filepath = job['out'] + '/f_'
    bpy.ops.render.render(animation=True)
