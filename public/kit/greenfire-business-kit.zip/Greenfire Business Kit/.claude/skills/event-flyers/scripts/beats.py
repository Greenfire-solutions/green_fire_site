"""Beat grid for one song, numpy only (no librosa or scipy on this Mac).

    python3 beats.py "<song file>"   -> prints JSON: bpm, beat phase, QC, best window

Tempo is searched in 74-140 BPM, where most songs live: an unconstrained
search often reports double the real tempo.
QC compares onset strength ON the grid with the same grid shifted half a beat;
a grid that is no better than its own shift is not trusted and the song is
not used for an animated flyer.
"""
import json, os, shutil, subprocess, sys
import numpy as np

SR, HOP, N = 22050, 256, 1024
FFMPEG = shutil.which('ffmpeg') or os.path.expanduser('~/.local/bin/ffmpeg')


def load(path):
    raw = subprocess.run([FFMPEG, '-v', 'quiet', '-i', path, '-ac', '1', '-ar', str(SR),
                          '-f', 'f32le', '-'], capture_output=True, check=True).stdout
    return np.frombuffer(raw, dtype=np.float32)


def onset_env(y):
    frames = 1 + (len(y) - N) // HOP
    idx = np.arange(N)[None, :] + HOP * np.arange(frames)[:, None]
    spec = np.abs(np.fft.rfft(y[idx] * np.hanning(N), axis=1))
    logs = np.log1p(100 * spec)
    flux = np.maximum(0, np.diff(logs, axis=0)).sum(axis=1)
    flux = np.concatenate([[0], flux])
    flux -= np.convolve(flux, np.ones(32) / 32, mode='same')   # remove the slow trend
    flux = np.maximum(flux, 0)
    # low band (kick) for the downbeat guess
    lo = np.maximum(0, np.diff(logs[:, 1:12], axis=0)).sum(axis=1)
    lo = np.concatenate([[0], lo])
    rms = np.sqrt((y[idx] ** 2).mean(axis=1))
    return flux / (flux.max() + 1e-9), lo, rms


def comb_score(env, fps, period, phase):
    t = np.arange(phase, len(env) / fps, period)
    i = np.round(t * fps).astype(int)
    i = i[i < len(env)]
    # take the max in +-1 frame so a few ms of drift is forgiven
    w = np.maximum(np.maximum(env[i], env[np.clip(i - 1, 0, None)]), env[np.clip(i + 1, None, len(env) - 1)])
    return w.mean()


def grid(path):
    y = load(path)
    fps = SR / HOP
    env, lo, rms = onset_env(y)
    dur = len(y) / SR
    # analyse the middle of the song, where the groove is
    a, b = int(len(env) * 0.15), int(len(env) * 0.85)
    seg = env[a:b]
    ac = np.correlate(seg - seg.mean(), seg - seg.mean(), mode='full')[len(seg) - 1:]
    best = None
    for bpm in np.arange(74, 140.01, 0.05):
        lag = 60 / bpm * fps
        l0 = int(lag)
        v = ac[l0] + (lag - l0) * (ac[l0 + 1] - ac[l0])
        # reward the multiples too (2 and 4 beats) so the bar agrees
        for m in (2, 4):
            L = lag * m
            L0 = int(L)
            if L0 + 1 < len(ac):
                v += 0.5 * (ac[L0] + (L - L0) * (ac[L0 + 1] - ac[L0]))
        if best is None or v > best[0]:
            best = (v, bpm)
    bpm = best[1]
    # refine bpm + phase on the whole song by comb score
    top = None
    for b2 in np.arange(bpm - 0.4, bpm + 0.401, 0.01):
        P = 60 / b2
        for ph in np.arange(0, P, 0.005):
            s = comb_score(env, fps, P, ph)
            if top is None or s > top[0]:
                top = (s, b2, ph)
        # keep this loop cheap: coarse phases first, then fine below
    s, bpm, phase = top
    P = 60 / bpm
    on = comb_score(env, fps, P, phase)
    off = comb_score(env, fps, P, (phase + P / 2) % P)
    ratio = on / (off + 1e-9)
    # downbeat: which of the four beats carries the most kick
    beats = np.arange(phase, dur, P)
    bi = np.clip(np.round(beats * fps).astype(int), 0, len(lo) - 1)
    k = [lo[bi[j::4]].mean() for j in range(4)]
    db = int(np.argmax(k))
    downbeats = beats[db::4]
    # per-bar loudness, then the strongest run of bars that starts on a lift
    bar_rms = []
    for t in downbeats:
        i0, i1 = int(t * fps), int((t + 4 * P) * fps)
        bar_rms.append(float(rms[i0:i1].mean()) if i1 <= len(rms) else 0.0)
    return dict(file=path, dur=dur, bpm=round(float(bpm), 3), beat=P, phase=float(phase),
                downbeat0=float(downbeats[0]), qc_ratio=round(float(ratio), 3),
                trusted=bool(ratio > 1.25), bar_rms=bar_rms)


def window(g, bars):
    """Start bar of the loudest `bars`-long run that begins on a jump in energy."""
    r = np.array(g['bar_rms'])
    best, start = -1, 0
    for i in range(1, len(r) - bars):
        lift = r[i] - r[i - 1]
        body = r[i:i + bars].mean()
        score = body + 0.6 * max(lift, 0)
        if score > best:
            best, start = score, i
    return start


if __name__ == '__main__':
    g = grid(sys.argv[1])
    out = {k: v for k, v in g.items() if k != 'bar_rms'}
    out['bars'] = len(g['bar_rms'])
    print(json.dumps(out))
