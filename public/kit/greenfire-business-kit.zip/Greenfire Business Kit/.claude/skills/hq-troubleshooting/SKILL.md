---
name: hq-troubleshooting
description: Fix the things that go wrong when HQ is installed on a new Mac or stops doing something - the START HERE button doing nothing, "unidentified developer", Node missing, the page not opening, email not connecting, Claude not signed in, a post or form that failed, the Mac asleep at post time. Use whenever the owner says HQ "isn't working", "doesn't open" or "didn't do anything".
---

# HQ troubleshooting

Check in this order. Each step is one look.

1. **Is HQ running?** Open http://127.0.0.1:8410 . If it does not load, double-click
   **START HERE** again. Logs: `~/Library/Logs/GreenfireHQ/`.
2. **START HERE does nothing, or opens in TextEdit.** The file lost its "can run"
   mark when the folder was copied. Open Terminal, type `chmod +x ` (with a space),
   drag START HERE.command into the window, press Return. Then double-click again.
3. **"Cannot be opened because it is from an unidentified developer".** Right-click
   START HERE, choose Open, then Open again. Only needed once.
4. **"HQ needs Node.js".** START HERE offers to install it. Or download the LTS
   installer from nodejs.org, run it, then START HERE again.
5. **Email will not connect.** It needs an APP password, not the normal password.
   Google Workspace: the admin must allow app passwords. Paste without spaces is
   fine; HQ removes them.
6. **Claude not signed in.** Setup, step 2, "Sign in to Claude". A Terminal opens;
   finish the browser sign-in; press "Check again".
7. **A post failed.** Studio, Calendar: each channel shows its own reason. Most
   often a token expired (Setup, Socials, Save and test) or media hosting is not set
   (Instagram only).
8. **A form stopped.** The card says on which page and why. Answer its questions on
   the card and press Yes again.
9. **Things happen only while HQ is open.** HQ runs while the Mac is awake and the
   server is running. A sleeping Mac posts when it wakes. Keep it plugged in on post
   days, or set Energy Saver to prevent sleep while plugged in.
10. **Still stuck.** Open Claude here (Agents & Skills) and ask the `hq-health`
    agent to check everything. It runs read-only.
