---
name: prove-the-page-runs
description: Prove a web page, dashboard or operator UI actually executes and renders, instead of proving that a string exists in its HTML. Runs the page in headless Chrome over a DevTools pipe (no debugging port), asserts on rendered DOM nodes, catches uncaught exceptions and console errors, and separately runs node --check on every inline script. Use BEFORE ever saying a page works, AFTER any change to a server-rendered page or inline script, when a page "looks fine in the tests" but someone says it does not work at all, when a dashboard is blank or a button appears to do nothing, and whenever a test suite passes for a page nobody has loaded. Includes the working macOS Chrome invocation and the SwiftShader flags for WebGL scenes.
---

# Prove the page runs

## The incidents this exists for

On 2026-09-17 a working operator dashboard shipped **blank, twice, in one day**,
and every API test passed both times.

1. A single quote nested inside a single quoted string in the inline script. The
   whole script failed to parse, so the page rendered nothing. The server was
   fine, the JSON endpoints were fine, and the suite was green.
2. `today` was used one line above its own `const`. That is a temporal dead
   zone. It **parses perfectly** and throws at run time, so a `node --check` pass
   proved nothing and the page was still blank.

Then the runtime check written to catch this **falsely passed on a blank page**,
because it grepped the dumped HTML for the button labels, and those labels are
present in the script source whether or not the script ever executes.

Three rules come out of that, and they are the whole skill:

- **Parsing is not running.** Check both.
- **Assert on rendered nodes, never on the presence of a string.** Count elements
  in the live DOM after scripts have run.
- **A green API suite says nothing about the page.** A server test that never
  parses or runs the page it serves is not testing the app.

## Run it

```bash
node ~/.claude/skills/prove-the-page-runs/scripts/prove-page.mjs <url> [options]
```

| option | what it does |
|---|---|
| `--expect "sel=n"` | assert `document.querySelectorAll(sel).length >= n` in the live DOM. Repeatable. This is the assertion that matters. |
| `--min-nodes n` | minimum real elements rendered into `<body>`, default 5. A blank page fails here. |
| `--click sel` | click a real element and re-measure, to prove a control does something |
| `--wait ms` | how long to wait after the click, default 1500 |
| `--advancing expr` | poll a JS expression until it INCREASES, for canvas and WebGL |
| `--gpu` | SwiftShader through ANGLE, needed for any WebGL scene |
| `--shot out.png` | screenshot after the assertions, not before |
| `--settle ms` | wait before the screenshot, then FAIL on any image that loaded with no pixels and note any still loading. Use it on image-heavy pages, or the shot shows holes that are only late art |
| `--width n --height n` | window size, default 1440x900; 390x844 for a phone |
| `--allow-console` | downgrade console errors to a note (uncaught exceptions still fail) |
| `--timeout ms` | how long to wait for the assertions to come true, default 20000 |
| `--cookie name=value` | set a cookie on the page's origin before it loads, for pages behind a login (repeatable). Get the value by logging in with curl against a sandbox server, never a live one |

Examples:

```bash
# a dashboard: it must render cards and buttons, not merely mention them
node scripts/prove-page.mjs http://127.0.0.1:7341/ --expect "main .card=1" --expect "button=3"

# a static file, no server needed
node scripts/prove-page.mjs file:///tmp/page.html --min-nodes 20 --shot /tmp/page.png

# a 3D viewer: prove the renderer is drawing frames, not just present
node scripts/prove-page.mjs http://127.0.0.1:3210/ --gpu \
  --advancing "window.__three.gl.info.render.frame"
```

Exit code is 0 only if everything asserted was observed. Wire it into
`npm run check` so a page whose JavaScript does not run fails the suite.

## What it checks, and why each check is there

**Pass 1, the source.**
- `node --check` on every inline `<script>` that has no `src`. Catches incident 1.
- No escaped quote inside an `onclick` or other handler attribute, and no
  `JSON.stringify` inside an attribute. That exact shape broke the page twice in
  one session. Every handler should be a plain named function call with a simple
  argument.
- No `alert`, `confirm` or `prompt`. They freeze the renderer. One project
  removed every one of them for that reason and a later project reintroduced
  three.

**Pass 2, the run.**
- Rendered node count inside `<body>`, excluding script, style, link and meta.
- Each `--expect` selector counted in the live DOM. Catches incident 2 and the
  false pass.
- Uncaught exceptions, via `Runtime.exceptionThrown`, which is how the temporal
  dead zone announces itself.
- Console errors, via `Runtime.consoleAPICalled` and `Log.entryAdded`, which is
  how a failed fetch or a 404 asset announces itself.

## The machine specific technique, which is the hard-won part

- **Chrome is driven over a PIPE, not a port.** `--remote-debugging-pipe`, with
  CDP messages null delimited on fd 3 and fd 4. The port could not be bound from
  the shell this was written in, and it also means the check never collides with
  a parallel session or takes a port that belongs to another project.
- **The flags for WebGL are `--use-gl=angle --use-angle=swiftshader
  --enable-unsafe-swiftshader`.** Plain `--use-gl=swiftshader` **hangs** on this
  machine (2019 Intel Mac, macOS 12). Without `--gpu` the script passes
  `--disable-gpu`, which is right for an ordinary DOM page and wrong for a scene.
- **`chrome --screenshot` fires on the load event**, long before the first frame,
  and hands back a picture of an empty canvas. That is how a broken 3D scene got
  reported as fine. Use `--advancing` and wait for a frame counter to move before
  capturing anything.
- The target is created at `about:blank`, the domains are enabled, and only then
  does it navigate. An exception thrown in the first tick is otherwise missed.
- Chrome's stderr is full of harmless macOS noise (`CVDisplayLink`, crashpad,
  XNNPACK). It is captured and printed only when something failed.

## Rules to apply even without this script

1. **Never ship a page you have not loaded.** Load it, press the buttons, read
   the console. Both blank pages were found by a person opening the page and by
   nothing else.
2. **Never re-render over somebody who is typing.** An auto refresh wiped a half
   typed value out of an input between typing it and pressing the button, which
   made a working button look broken.
3. **Inside an HTML template literal a `\/` is consumed by the template**, so a
   regex literal written in the server file arrives at the browser broken. Use a
   helper function instead of a regex in page code.
4. **A disabled button in a browser is not a gate.** Whatever the page refuses,
   the server must refuse again on the write path.
5. If a page asserts a guarantee in its own text (signed link, expires in 14
   days), check the code implements it. A screen that asserts an absent guardrail
   is worse than a silent one, because it stops anyone looking for it.
