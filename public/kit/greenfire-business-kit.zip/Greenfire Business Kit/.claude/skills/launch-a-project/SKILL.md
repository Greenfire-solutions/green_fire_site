---
name: launch-a-project
description: Add a new line of business to HQ (an instructor training, a retreat, a course, a membership, a brand partnership, a new product or venture) so every agent works it alongside the others - the interview questions, the offer, the audiences to search, the letters, the post themes, the Comment-to-get keyword, and a 30 day launch plan. Use when the owner starts something new, wants to test an idea, or says "I want to sell X".
---

# Launching a project in HQ

## The interview (Projects, "Add a project")

Ask about what HAPPENS, not features, because "do you need a CRM?" is unanswerable
by the person who needs one:

1. What is it called, and what kind of thing is it?
2. What does someone get, in your words?
3. Who buys it, and who decides? (A company buys a keynote; an HR lead decides.)
4. Price, and the link where people buy or book.
5. What would make this a win in 90 days?
6. Facts the agents may state: dates, formats, results you can prove.

Claude then writes: a one line summary, 1 to 4 outreach audiences each with a
precise search description, 3 to 5 posting themes, a first letter with blanks, and
a Comment keyword. Everything is editable after.

## Smallest first

A project that books one call is worth more than one that is perfectly set up and
silent. Launch with one audience and one letter, see who answers, then add more.

## The 30 day launch

| Week | Do |
|---|---|
| 1 | Offer page live (or a Stan product), keyword set, three posts announcing it from a true story, Scout runs the first audience |
| 2 | First letters to the 20 best fits; one podcast or partner pitch; a "Film this week" clip |
| 3 | Follow-ups start; share one result or quote (with consent); Comment-to-get post |
| 4 | Review: who answered, which audience, which post. Keep what worked, pause the rest |

## For an instructor training specifically

Facts to collect first: dates, format (in person, online, hybrid), hours, what the
certification lets graduates do, cohort size, price and early rate, prerequisites,
how many instructors have already been certified (only the owner's own number).
Audiences: yoga and fitness teachers, coaches, therapists, past students. Never
promise income or clinical scope to graduates.
