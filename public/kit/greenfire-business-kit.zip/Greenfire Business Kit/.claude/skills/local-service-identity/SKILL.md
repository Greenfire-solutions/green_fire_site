---
name: local-service-identity
description: Make a local service prove who it is before anything opens, reuses, writes to, tests against or reports on it. Several local tools on one Mac can collide; a launcher that asked "is something listening on this port" opened a different business entirely, and a stray instance of the same app later answered a probe and was driven against live production data. Use BEFORE writing any launcher, health check, test or agent that talks to localhost, WHEN picking a port for a new tool, WHEN a dashboard shows the wrong project's data, when "already running" is reported and the wrong window appears, and whenever a test needs to be sure it is hitting its own server. Ships a probe script, the server side endpoint, and the fake-stranger test that proves the probe refuses an impostor.
---

# Local service identity

**Liveness is not identity.** A port that answers is not your app, and your app
answering is not necessarily the instance you meant.

The port allocation table for this machine lives in the memory file
`local-port-registry.md`. Read that for WHO owns WHAT. This skill is the HOW:
the probe, the endpoint, the test, and the procedure for claiming a new port.

## The two incidents, both on 2026-09-17

1. **A launcher opened the wrong business.** One tool's icon opened a
   different project. Its launcher used a port another local tool already
   owned, and it asked "is something listening there"
   rather than "is that us". The stranger answered 200, the launcher said
   "already running", and it opened a different company's dashboard.

2. **App level identity was not enough.** After `/api/whoami` was added, a stray
   operator left over from an earlier run answered the app level probe on the
   test's port. The test attached to it, drove it against the **live ledger**,
   and reported a false failure. Identity has to be specific enough to tell one
   instance of the same app from another.

Same family as the silent filter bugs in `filter-and-gate-reviewer`: a check
that is too permissive fails silently and confidently.

## The rule

Nothing opens, reuses, writes to, tests against or reports on a local service
until that service has identified itself, at three levels of specificity:

| level | question | field |
|---|---|---|
| app | is this my kind of app | `app`, an exact string match, never a substring |
| checkout | is this the folder I am working in | `project`, the absolute project path |
| instance | is this the process I started | `pid`, plus `started` |

Use the level the caller actually needs. A launcher needs app and project. A test
that spawns its own server needs pid, because the whole point is to be sure it is
not driving somebody's live data.

## Serve it

Twelve lines, and it goes in before anything else on the server:

```js
if (url.pathname === '/api/whoami') {
  res.writeHead(200, { 'content-type': 'application/json' })
  return res.end(JSON.stringify({
    app: '3d-operator',              // exact, unique, never a display name
    project: ROOT,                   // absolute path, so two checkouts differ
    pid: process.pid,
    started: STARTED_AT,             // ISO string, set once at boot
  }))
}
```

And the other half, which matters just as much:

```js
server.on('error', (e) => {
  if (e.code === 'EADDRINUSE') {
    console.error(`port ${PORT} is taken by somebody else. Not starting.`)
    process.exit(3)               // loud, specific, not a quiet continue
  }
  throw e
})
```

A busy port that is not yours belongs to somebody else. **Skip it, never share
it, never take it over, and never kill it.** Killing what is on a port is how you
end another project's unsaved work.

## Probe it

```bash
node ~/.claude/skills/local-service-identity/scripts/whoami-probe.mjs 7341 --app 3d-operator
node ~/.claude/skills/local-service-identity/scripts/whoami-probe.mjs 7341 --app 3d-operator --pid $PID
node ~/.claude/skills/local-service-identity/scripts/whoami-probe.mjs survey 3210 4180 7341 7788 7799
node ~/.claude/skills/local-service-identity/scripts/whoami-probe.mjs free 7341-7345
```

Exit codes, so a launcher or a Makefile can branch without parsing text:

- `0` ours, and it said so
- `3` something is listening and it is not ours. Skip it.
- `4` nothing is listening. Safe to start.

The probe connects, it never binds, so running it cannot itself take a port.

## Test it with a fake stranger

This is the part people skip, and it is the part that proves the fix. Stand up a
server that answers 200 on **every** path, exactly like another project's
operator does, and assert your probe refuses it:

```js
const stranger = createServer((q, r) => {
  r.writeHead(200, { 'content-type': 'text/html' })
  r.end('<title>Some other operator</title>')
})
await new Promise((res) => stranger.listen(7398, '127.0.0.1', res))

t('a stranger DOES answer a naive liveness probe, which is why v1 broke',
  (await fetch('http://127.0.0.1:7398/api/whoami').then((r) => r.ok).catch(() => false)) === true)
t('but it does not pass the identity probe', (await isOurs(7398)) === false)
```

Then the three instance level assertions:

```js
t('our own server passes the identity probe',            (await isOurs(PORT)) === true)
t('the probe tells OUR instance from another copy',      (await isOurs(PORT, server.pid)) === true)
t('a different pid is correctly rejected',               (await isOurs(PORT, 999999)) === false)
```

And one more, which came from incident 2: **the test must refuse to start if
something is already on its port.** Do not assume the thing that answers is the
thing you spawned.

## Picking a port for a new tool

1. Read `local-port-registry.md` for what is already claimed.
2. `whoami-probe.mjs free <a>-<b>` over a candidate range to confirm nothing is
   actually there right now.
3. Claim a small contiguous block, not a single port, and put the block and the
   reason in a comment at the top of the server file.
4. Append the claim to the memory file. An unrecorded port becomes the next
   collision.
5. Never use a port from somebody else's row, and never reuse a well-known
   default (3000, 5000, 8080) for a long-lived personal operator. Those are the
   ports every scaffold picks.

## Beyond ports

The same rule holds anywhere a resource is shared across projects on this
machine, and each of these has a real incident behind it somewhere in these
notes:

- **A database file.** Prove you opened the throwaway one, by path, before any
  write. A test that writes to the live ledger is not a test, and one did:
  it POSTed a send into production data while appearing to pass.
- **A launchd job.** Two projects with the same label silently replace each
  other. Namespace the label with the project.
- **A browser profile.** Headless runs get their own `--user-data-dir`, made
  fresh each run, or they inherit another session's state.
- **A ledger, an export directory, a lock file.** If two projects can reach it,
  say which project you are before you touch it.
