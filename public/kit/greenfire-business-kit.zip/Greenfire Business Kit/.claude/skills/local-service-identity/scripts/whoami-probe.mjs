#!/usr/bin/env node
/**
 * Identity, not liveness.
 *
 * On 2026-09-17 a project's operator icon opened a DIFFERENT BUSINESS. The
 * launcher used port 7799, which another project's operator already owned, and
 * it asked "is something listening there" instead of "is that us". The stranger
 * answered 200, the launcher said "already running", and it opened the wrong
 * app. Later the same day a stray instance of the SAME app, left over from an
 * earlier run, answered the app level probe and a test unknowingly drove it
 * against live production data.
 *
 * So: nothing opens, reuses, writes to or reports on a local service until that
 * service has identified itself, and the identity must be specific enough to
 * tell one instance of the same app from another.
 *
 *   node whoami-probe.mjs 7341 --app 3d-operator            is it ours
 *   node whoami-probe.mjs 7341 --app 3d-operator --pid 481  is it THIS instance
 *   node whoami-probe.mjs 7341 --app greenfire-hq --project /HQ  is it this checkout
 *   node whoami-probe.mjs survey 3210 4180 7341 7788 7799   who is on each
 *   node whoami-probe.mjs free 7341-7345                    which are unused
 *
 * Exit codes, so a launcher or a Makefile can branch on them:
 *   0  ours, and it identified itself
 *   3  something is listening and it is NOT ours. Skip it. Never take it over.
 *   4  nothing is listening
 *   1  bad usage
 */
import { connect } from 'node:net'

const argv = process.argv.slice(2)
const flag = (n, d = null) => {
  const i = argv.indexOf('--' + n)
  if (i === -1) return d
  const v = argv[i + 1]
  return (v === undefined || v.startsWith('--')) ? true : v
}
const PATH_ = String(flag('path', '/api/whoami'))
const HOST = String(flag('host', '127.0.0.1'))
const MS = Number(flag('timeout', 2000))

/** Is anything accepting connections at all? Connect only. Never bind. */
function listening (port) {
  return new Promise((resolve) => {
    const s = connect({ host: HOST, port: Number(port) })
    const done = (v) => { try { s.destroy() } catch {} ; resolve(v) }
    s.setTimeout(MS)
    s.once('connect', () => done(true))
    s.once('timeout', () => done(false))
    s.once('error', () => done(false))
  })
}

/** Ask the service who it is. A non-answer is a stranger, not a maybe. */
async function whoami (port) {
  try {
    const r = await fetch(`http://${HOST}:${port}${PATH_}`, { signal: AbortSignal.timeout(MS) })
    if (!r.ok) return null
    const j = await r.json()
    return (j && typeof j === 'object') ? j : null
  } catch { return null }
}

const mode = argv[0]

if (mode === 'survey') {
  const ports = argv.slice(1).filter((a) => /^\d+$/.test(a))
  if (!ports.length) { console.error('usage: whoami-probe.mjs survey <port>...'); process.exit(1) }
  for (const p of ports) {
    if (!(await listening(p))) { console.log(`${p}  free`); continue }
    const j = await whoami(p)
    console.log(j
      ? `${p}  ${j.app ?? 'no app id'}  pid ${j.pid ?? '?'}  ${j.project ?? ''}`
      : `${p}  BUSY, does not identify itself. Treat as somebody else's.`)
  }
  process.exit(0)
}

if (mode === 'free') {
  const m = String(argv[1] || '').match(/^(\d+)-(\d+)$/)
  if (!m) { console.error('usage: whoami-probe.mjs free <from>-<to>'); process.exit(1) }
  const free = []
  for (let p = Number(m[1]); p <= Number(m[2]); p++) if (!(await listening(p))) free.push(p)
  console.log(free.length ? free.join(' ') : 'none free in that range')
  process.exit(free.length ? 0 : 3)
}

const port = Number(mode)
if (!port) {
  console.error('usage: whoami-probe.mjs <port> --app <id> [--pid n] [--project substr] | survey <port>... | free <a>-<b>')
  process.exit(1)
}

if (!(await listening(port))) { console.log(`nothing is listening on ${port}`); process.exit(4) }

const j = await whoami(port)
if (!j) {
  // This is the case that opened the wrong business. Something answered. It is
  // not ours, and a 200 on every path is exactly what another operator looks
  // like. Skip it, never share it, never take it over, never kill it.
  console.log(`${port} is BUSY and did not identify itself at ${PATH_}. Not ours.`)
  process.exit(3)
}

const wantApp = flag('app')
const wantPid = flag('pid')
const wantProject = flag('project')
const why = []
if (typeof wantApp === 'string' && j.app !== wantApp) why.push(`app is "${j.app}", wanted "${wantApp}"`)
if (typeof wantPid === 'string' && String(j.pid) !== String(wantPid)) why.push(`pid is ${j.pid}, wanted ${wantPid}, so this is a DIFFERENT INSTANCE of the same app`)
if (typeof wantProject === 'string' && !String(j.project ?? '').includes(wantProject)) why.push(`project is "${j.project}", wanted one containing "${wantProject}"`)

console.log(JSON.stringify(j))
if (why.length) { console.log('NOT OURS: ' + why.join('; ')); process.exit(3) }
console.log('ours')
process.exit(0)
