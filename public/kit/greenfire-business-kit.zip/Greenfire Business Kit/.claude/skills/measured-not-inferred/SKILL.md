---
name: measured-not-inferred
description: Keep measured facts, inferred estimates and assumptions apart, and refuse to quote a number that its sample size cannot support. Use WHEN writing any research file, README, proposal, pitch, price, status report or agent report that contains a figure, WHEN a subagent hands back a finding you are about to record as true, WHEN comparing competitors or comparables, and WHENEVER a number is about to be copied out of the place that explains it into a place that does not. It gives the provenance line format, the refuse-below-n rule, the re-confirmation rule for agent reports, and the shelf life rule for any measurement of somebody else's live site.
---

# Measured, not inferred

A corpus that had been wrong three separate times produced this rule, and the
rule is not "be careful". It is that **the refusal has to live in the code or the
template, because a caveat does not survive being copied.**

## The incidents

- **n=1 became a headline.** A differentiator that the whole positioning rested
  on had exactly one observation behind it.
- **Four "competitors" were not competitors.** Checked one by one, they turned
  out to be a recruitment consultancy, an HVAC web shop, a studio that does not
  serve residential at all, and a competitor's own product listed again under a
  different name. Four out of four.
- **Three price anchors were wrong**, carried forward from a different business
  with a different ticket size, and they would have anchored a $10,000 to
  $30,000 conversation at $750.
- **A brief was written against a website that had since changed.** The domain
  now redirects somewhere else, and the facts quoted from it, the staging dates
  and the founder's name, are no longer findable anywhere on the live site.
- **An agent's report was treated as a finding.** The fix was a line at the top
  of the defect file: *everything below was independently re-confirmed by the
  orchestrator before being written down, because an agent report is a claim and
  not a finding.* Several agent claims did not survive that re-check.

## The four rules

### 1. Every number carries source, date and n

One line, in this shape, and it travels with the number wherever the number goes:

```
0 of 89 measured        agent/measure.mjs over the EIA feed, 2026-09-17, n=89
34,359 transactions     Anderson, Freybote and Manis, JREFE 2022, not vendor funded
$16.40 / month          distributor statement, 2026-08, one month, not a trend
```

A number with no source line is not quotable, and a number whose source is
another document that also has no source line is worse, because it looks
established.

### 2. Encode the refusal, do not footnote it

The project that learned this has `quotableSaturation()`, a function that
**returns a refusal** below n=60 rather than returning the number with a caveat.
Its comparison view prints an interval on every arm and **will not rank** the
arms below about 25 observations each, because three arms of ten cannot be
separated at those rates and a ranking built on that is worse than no ranking:
it gets acted on with confidence.

So: put the threshold in the function that produces the number. A caveat in prose
is stripped the first time somebody pastes the figure into an email.

What is readable early, when n is small, is usually a different quantity
entirely: hours per outcome, which step is killing things, how long the loop
takes. Report those instead of a rate nobody can support.

### 3. An agent report is a claim, not a finding

Anything a subagent hands back gets independently re-confirmed before it is
written down as true, by running the command yourself or reading the file
yourself. Record who confirmed it, in the document, as a column:

```
| # | defect | confirmed by | status |
```

The value of that column is that a reader can tell a verified defect from a
plausible one six months later.

### 4. Label the three kinds, in the document

Use three words and use them literally.

- **MEASURED**, you ran it and here is the command and the output.
- **INFERRED**, it follows from something measured, and the step is stated.
- **ASSUMED**, nobody has checked; it is standing in until somebody does.

A file that mixes them without labels becomes an adverse-inference engine: a
confident document sitting beside a provenance note it contradicts is worse than
no note at all.

## Two specific traps worth naming

**A measurement of somebody else's live thing has a shelf life.** Websites,
prices, staffing pages and social handles all change. Date every such
measurement, and re-measure before quoting it to the person it is about.
Telling somebody a false fact about their own site is the mistake that cannot be
recovered.

**A name match is not an identification.** Before calling anything a competitor,
a comparable or the same company, confirm on a second independent axis: what they
actually sell, who they serve, whether the product is just a rename. Two of three
company identifications by name alone were wrong in one sample here, and four of
four "competitors" in another.
