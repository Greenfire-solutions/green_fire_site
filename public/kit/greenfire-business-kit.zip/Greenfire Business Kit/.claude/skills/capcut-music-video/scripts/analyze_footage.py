#!/usr/bin/env python3
"""Decode every source at 5fps/64x36 -> metrics + shot cuts + letterbox detect + contact sheets."""
import numpy as np, json, os, subprocess, argparse
FPS=5.0; W,H=64,36
def sources(project=None,files=None):
    if files: return [dict(path=f) for f in files]
    m=json.load(open(f"{project}/draft_meta_info.json"))
    out=[]
    for g in m.get('draft_materials',[]):
        for x in g.get('value',[]):
            if x.get('metetype')=='video':
                out.append(dict(path=x['file_Path'],dur=x['duration']/1e6,
                                w=x.get('width'),h=x.get('height')))
    return out
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--project"); ap.add_argument("--files",nargs="*")
    ap.add_argument("--out",required=True); a=ap.parse_args()
    for d in ("frames","sheets"): os.makedirs(os.path.join(a.out,d),exist_ok=True)
    src=sorted(sources(a.project,a.files),key=lambda s:s['path'])
    index=[];out={}
    for i,s in enumerate(src):
        k="v%02d"%i; p=s['path']
        index.append(dict(key=k,path=p,name=os.path.basename(p),dur=s.get('dur')))
        npy=os.path.join(a.out,"frames",k+".npy")
        if not os.path.exists(npy):
            raw=subprocess.run(["ffmpeg","-v","error","-i",p,"-vf",f"fps={FPS},scale={W}:{H}",
                "-pix_fmt","rgb24","-f","rawvideo","-"],capture_output=True).stdout
            n=len(raw)//(W*H*3)
            np.save(npy,np.frombuffer(raw[:n*W*H*3],np.uint8).reshape(n,H,W,3))
        arr=np.load(npy)
        if s.get('dur') is None:
            index[-1]['dur']=len(arr)/FPS; s['dur']=len(arr)/FPS
        sheet=os.path.join(a.out,"sheets",k+".jpg")
        if not os.path.exists(sheet):
            subprocess.run(["ffmpeg","-v","error","-y","-i",p,"-vf",
                f"fps=40/{s['dur']},scale=240:-1,tile=8x5","-frames:v","1","-q:v","4",sheet],
                capture_output=True)
        f=arr.astype(np.float32)/255.; N=len(f); g=f.mean(3)
        motion=np.concatenate([[0],np.abs(np.diff(f,axis=0)).mean((1,2,3))])
        mx,mn=f.max(3),f.min(3); rng=mx-mn+1e-6
        r,gg,b=f[...,0],f[...,1],f[...,2]
        hue=np.where(mx==r,(gg-b)/rng%6,np.where(mx==gg,(b-r)/rng+2,(r-gg)/rng+4))/6.
        huestd=np.array([np.std(hue[j][rng[j]>0.15]) if (rng[j]>0.15).sum()>20 else 0
                         for j in range(N)])
        thr=max(0.085,float(np.percentile(motion,99))*0.55)
        cuts=[j for j in range(1,N) if motion[j]>thr]
        # letterbox / pillarbox
        mimg=g.mean(0); rows,cols=mimg.mean(1),mimg.mean(0)
        tb=sum(1 for v in rows[:H//2] if v<0.05); bb=sum(1 for v in rows[::-1][:H//2] if v<0.05)
        lb=sum(1 for v in cols[:W//2] if v<0.05); rb=sum(1 for v in cols[::-1][:W//2] if v<0.05)
        ah,aw=H-tb-bb,W-lb-rb
        scale=round(float(max(H/ah if ah else 1, W/aw if aw else 1)),3)
        out[k]=dict(name=index[-1]['name'],path=p,dur=s['dur'],n=N,fps=FPS,scale=scale,
            bright=g.mean((1,2)).round(4).tolist(),
            sat=(mx-mn).mean((1,2)).round(4).tolist(),
            contrast=g.std((1,2)).round(4).tolist(),
            motion=motion.round(4).tolist(),huestd=huestd.round(4).tolist(),cuts=cuts)
        print(f"{k} n={N:>5} {s['dur']:>7.1f}s cuts={len(cuts):>4} bright={g.mean():.3f} "
              f"motion={motion.mean():.4f} scale={scale}  {index[-1]['name'][:44]}")
    json.dump(index,open(os.path.join(a.out,"index.json"),"w"),indent=1)
    json.dump(out,open(os.path.join(a.out,"vid.json"),"w"))
    print(f"\n-> {a.out}/vid.json  |  NOW READ EVERY SHEET IN {a.out}/sheets/ BEFORE PROCEEDING")
if __name__=="__main__": main()
