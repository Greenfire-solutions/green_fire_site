#!/usr/bin/env python3
"""One frame per shot, in edit order, tiled. The visual QC gate before building."""
import json, os, subprocess, argparse
from concurrent.futures import ThreadPoolExecutor
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--edl",required=True)
    ap.add_argument("--vid",required=True); ap.add_argument("--out",required=True)
    ap.add_argument("--cols",type=int,default=12); ap.add_argument("--rows",type=int,default=8)
    a=ap.parse_args()
    E=json.load(open(a.edl)); V=json.load(open(a.vid))
    d=os.path.join(os.path.dirname(a.out) or ".","_proof"); os.makedirs(d,exist_ok=True)
    def grab(i_s):
        i,s=i_s; t=s['t0']+(s['t1']-s['t0'])/2; sc=V[s['src']].get('scale',1.0)
        vf=(f"crop=iw:ih/{sc}," if sc>1.02 else "")+"scale=200:112"
        subprocess.run(["ffmpeg","-v","error","-y","-ss",f"{t:.3f}","-i",V[s['src']]['path'],
            "-frames:v","1","-vf",vf,"-q:v","3",f"{d}/{i:03d}.jpg"],capture_output=True)
    with ThreadPoolExecutor(8) as ex: list(ex.map(grab,enumerate(E)))
    per=a.cols*a.rows
    for p in range((len(E)+per-1)//per):
        o=a.out if p==0 else a.out.replace(".jpg",f"_{p+1}.jpg")
        subprocess.run(["ffmpeg","-v","error","-y","-f","image2","-start_number",str(p*per),
            "-i",f"{d}/%03d.jpg","-vf",f"tile={a.cols}x{a.rows}","-frames:v","1","-q:v","3",o],
            capture_output=True)
        print("wrote",o)
    print("\nLOOK AT THESE. Check: title cards, blank frames, near-black, source clumping.")
if __name__=="__main__": main()
