#!/usr/bin/env python3
"""Shot selection: pick the best unused window per planned cut. Vectorised over frames."""
import numpy as np, json, argparse
from collections import Counter
def main():
    ap=argparse.ArgumentParser()
    for f in ("song","vid","plan","out"): ap.add_argument("--"+f,required=True)
    a=ap.parse_args()
    S=json.load(open(a.song)); V=json.load(open(a.vid)); P=json.load(open(a.plan))
    BEAT=S['beat']; PH=S['beats'][0]; FPS=5.0
    EXC=P.get('exclude',{}); USE=P.get('use') or list(EXC) or list(V)
    TARGET=P.get('target',{}); BIAS=P.get('bias',{}); POOLS=P['pools']
    FLOOR=P.get('floors',{"bright_min":0.07,"bright_max":0.93,"contrast_min":0.055})
    D={}
    for k in USE:
        v=V[k]; N=v['n']
        d=dict(N=N,**{m:np.array(v[m]) for m in ('motion','bright','sat','contrast','huestd')})
        ok=np.ones(N,bool)
        for x,y in EXC.get(k,[]): ok[int(x*FPS):min(N,int(y*FPS))]=False
        ok&= (d['bright']>FLOOR['bright_min'])&(d['bright']<FLOOR['bright_max'])
        ok&= d['contrast']>FLOOR['contrast_min']
        d['valid']=ok; d['taken']=np.zeros(N,bool)
        d['cut']=np.zeros(N,bool); d['cut'][np.array(v['cuts'],int)]=True
        for m in ('motion','bright','sat','contrast','huestd'):
            d['c_'+m]=np.concatenate([[0],np.cumsum(d[m])])
        d['c_valid']=np.concatenate([[0],np.cumsum(ok)])
        d['c_cut']=np.concatenate([[0],np.cumsum(d['cut'])])
        D[k]=d; print(f"{k}: {ok.sum()/FPS:6.1f}s valid of {N/FPS:6.1f}s")
    G={m:(min(D[k][m].min() for k in USE),max(D[k][m].max() for k in USE))
       for m in ('motion','bright','sat','contrast','huestd')}
    nz=lambda m,x:(x-G[m][0])/(G[m][1]-G[m][0]+1e-9)
    SPENT=Counter()
    def pick(pool,dur,style,recent):
        w=max(2,int(round(dur*FPS))); best=None
        for k in pool:
            d=D[k]; N=d['N']
            if N-w-1<=1: continue
            st=np.arange(1,N-w-1)
            mean=lambda m:(d['c_'+m][st+w]-d['c_'+m][st])/w
            ok=(d['c_valid'][st+w]-d['c_valid'][st])==w
            ct=np.concatenate([[0],np.cumsum(d['taken'])]); pad=int(2.5*FPS)
            ok&= (ct[np.minimum(N,st+w+pad)]-ct[np.maximum(0,st-pad)])==0
            if not ok.any(): continue
            mo=mean('motion'); mm=mo/(0.06+mo)
            sa,co,hu=nz('sat',mean('sat')),nz('contrast',mean('contrast')),nz('huestd',mean('huestd'))
            if style=='energy': sc=1.7*mm+0.8*sa+0.7*co+0.5*hu
            elif style=='hero': sc=1.5*mm+1.0*sa+0.9*co+0.8*hu
            else:               sc=1.1*sa+0.9*co+0.5*hu-1.6*mm+0.3*nz('bright',mean('bright'))
            sc=sc+0.55*((d['c_cut'][st+w]-d['c_cut'][st])==0)      # prefer one continuous shot
            tot=sum(SPENT.values()) or 1e-9
            sc=sc+BIAS.get(k,0)-3.5*max(0.,SPENT[k]/tot-TARGET.get(k,1))*(tot>25)
            for i,s_ in enumerate(reversed(recent[-3:])):
                if s_==k: sc=sc-[1.4,0.7,0.35][i]
            sc=np.where(ok,sc,-1e9); j=int(np.argmax(sc))
            if best is None or sc[j]>best[0]: best=(sc[j],k,int(st[j]),w)
        if best is None: return None
        _,k,s0,w=best; D[k]['taken'][s0:s0+w]=True; SPENT[k]+=w/FPS
        return dict(src=k,t0=s0/FPS,t1=(s0+w)/FPS)
    secs=P['sections']; edl=[None]*len(secs)
    for i in sorted(range(len(secs)),key=lambda i:secs[i].get('priority',2)):
        s=secs[i]; pool=POOLS[s['pool']] if isinstance(s['pool'],str) else s['pool']
        segs=[]; rec=[]
        for j,b in enumerate(s['pattern']):
            p=pick(pool,b*BEAT,s.get('style','energy'),rec)
            if p is None: print("!! no shot for",s['name'],j); continue
            p.update(sec=s['name'],beats=b,dur=b*BEAT,
                     start=PH+(s['start_beat']+sum(s['pattern'][:j]))*BEAT)
            segs.append(p); rec.append(p['src'])
        edl[i]=segs
    flat=sorted([x for g in edl for x in g],key=lambda x:x['start'])
    json.dump(flat,open(a.out,"w"),indent=1)
    gaps=sum(1 for x,y in zip(flat,flat[1:]) if abs(y['start']-(x['start']+x['dur']))>1e-6)
    print(f"\n{len(flat)} shots, ends {flat[-1]['start']+flat[-1]['dur']:.2f}s "
          f"(song {S['dur']:.2f}s), continuity errors {gaps}")
    tot=Counter()
    for x in flat: tot[x['src']]+=x['dur']
    for k,n in Counter(x['src'] for x in flat).most_common():
        print(f"  {k} {n:>3} shots {tot[k]:>6.1f}s ({tot[k]/S['dur']*100:>4.1f}%)  {V[k]['name'][:40]}")
    print("adjacent same-source:",sum(1 for x,y in zip(flat,flat[1:]) if x['src']==y['src']))
    print("max same-source per 5:",max(Counter(x['src'] for x in flat[i:i+5]).most_common(1)[0][1]
                                        for i in range(max(1,len(flat)-5))))
if __name__=="__main__": main()
