#!/bin/bash
# CapCut UI driver. Requires Accessibility for the calling terminal app.
# AppleScript `System Events click at` does NOT work on CapCut (CEF UI) - use the CGEvent binary.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
[ -x "$D/capcut_click" ] || clang -O2 -o "$D/capcut_click" "$D/capcut_click.c" -framework ApplicationServices
case "$1" in
  check)  osascript -e 'tell application "System Events" to tell process "CapCut" to get position of window 1' \
            && echo "accessibility OK" \
            || echo "DENIED -> System Settings > Privacy & Security > Accessibility > enable your terminal app" ;;
  shot)   screencapture -x "${2:-shot.png}"; echo "${2:-shot.png}" ;;
  click)  osascript -e 'tell application "CapCut" to activate' >/dev/null; sleep 1
          "$D/capcut_click" "$2" "$3" "${4:-1}" ;;
  quit)   osascript -e 'quit app "CapCut"' >/dev/null 2>&1 || true
          for i in $(seq 1 25); do pgrep -x CapCut >/dev/null || break; sleep 1; done
          pgrep -x CapCut >/dev/null && echo "STILL RUNNING" || echo "closed" ;;
  open)   open -a CapCut; for i in $(seq 1 25); do pgrep -x CapCut >/dev/null && break; sleep 1; done
          sleep 8; echo "running" ;;
  *) echo "usage: capcut_ui.sh {check|shot [f]|click X Y [n]|quit|open}"; exit 2 ;;
esac
