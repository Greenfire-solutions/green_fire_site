#!/usr/bin/env python3
"""Generate a CapCut draft_info.json from an EDL.

Schema fields are copied from real drafts in the user's own CapCut library so every
field CapCut expects is present with valid defaults for THIS CapCut version.
"""
import json, uuid, copy, os, argparse, glob
ROOT=os.path.expanduser("~/Movies/CapCut/User Data/Projects/com.lveditor.draft")
UID=lambda: str(uuid.uuid4()).upper()
VORDER=['speeds','placeholder_infos','canvases','sound_channel_mappings',
        'material_colors','vocal_separations']
AORDER=['speeds','placeholder_infos','beats','sound_channel_mappings','vocal_separations']
def by_id(d):
    o={}
    for k,v in d['materials'].items():
        if isinstance(v,list):
            for it in v:
                if isinstance(it,dict) and 'id' in it: o[it['id']]=(k,it)
    return o
def find_protos(skip):
    """Scan drafts for a real video segment and a real audio segment to clone."""
    vid=aud=None
    for f in sorted(glob.glob(f"{ROOT}/*/draft_info.json"),key=os.path.getmtime,reverse=True):
        if os.path.basename(os.path.dirname(f))==skip: continue
        try: d=json.load(open(f))
        except Exception: continue
        o=by_id(d)
        if vid is None:
            for t in d.get('tracks',[]):
                if t['type']=='video' and t['segments'] and d['materials'].get('videos'):
                    sg=t['segments'][0]
                    if len(sg.get('extra_material_refs',[]))>=6:
                        vid=(copy.deepcopy(sg),copy.deepcopy(d['materials']['videos'][0]),
                             {o[r][0]:copy.deepcopy(o[r][1]) for r in sg['extra_material_refs']})
                        break
        if aud is None:
            for t in d.get('tracks',[]):
                if t['type']=='audio' and t['segments'] and d['materials'].get('audios'):
                    sg=t['segments'][0]
                    aud=(copy.deepcopy(sg),copy.deepcopy(d['materials']['audios'][0]),
                         {o[r][0]:copy.deepcopy(o[r][1]) for r in sg['extra_material_refs']})
                    break
        if vid and aud: break
    if not vid: raise SystemExit("No draft with a video segment found to use as a schema template.")
    if not aud: raise SystemExit("No draft with an audio segment found to use as a schema template.")
    return vid,aud
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--edl",required=True); ap.add_argument("--vid",required=True)
    ap.add_argument("--project",required=True); ap.add_argument("--out",required=True)
    ap.add_argument("--fps",type=float,default=30.0)
    ap.add_argument("--width",type=int,default=1920); ap.add_argument("--height",type=int,default=1080)
    ap.add_argument("--slow",default="",help='e.g. "70:0.6,71:0.6,184:0.75" shot_index:speed')
    a=ap.parse_args()
    FR=a.fps; us=lambda t:int(round(round(t*FR)/FR*1e6))
    E=json.load(open(a.edl)); V=json.load(open(a.vid))
    meta=json.load(open(f"{a.project}/draft_meta_info.json"))
    base=json.load(open(f"{a.project}/draft_info.json"))
    SRC={}
    for g in meta['draft_materials']:
        for m in g.get('value',[]): SRC[m['file_Path']]=m
    (VSEG,VMAT,VX),(ASEG,AMAT,AX)=find_protos(os.path.basename(a.project.rstrip("/")))
    SLOW={int(k):float(v) for k,v in (p.split(":") for p in a.slow.split(",") if p)}
    M={k:[] for k in ('videos','audios','speeds','placeholder_infos','canvases',
        'sound_channel_mappings','material_colors','vocal_separations','beats')}
    starts=[us(s['start']) for s in E]; END=us(E[-1]['start']+E[-1]['dur']); segs=[]
    for i,s in enumerate(E):
        path=V[s['src']]['path']; mm=SRC[path]
        t0=starts[i]; tdur=(starts[i+1] if i+1<len(E) else END)-t0
        sp=SLOW.get(i,1.0); sdur=int(round(tdur*sp)); s0=us(s['t0'])
        if s0+sdur>mm['duration']: s0=max(0,mm['duration']-sdur)
        vm=copy.deepcopy(VMAT); vm.update(id=UID(),path=path,duration=mm['duration'],
            width=mm['width'],height=mm['height'],material_name=os.path.basename(path),
            local_material_id=str(uuid.uuid4()))
        M['videos'].append(vm); refs=[]
        for kind in VORDER:
            x=copy.deepcopy(VX[kind]); x['id']=UID()
            if kind=='speeds': x['speed']=sp
            M[kind].append(x); refs.append(x['id'])
        sc=float(V[s['src']].get('scale',1.0))
        if sc<1.02: sc=1.0
        g=copy.deepcopy(VSEG)
        g.update(id=UID(),material_id=vm['id'],extra_material_refs=refs,
            source_timerange={"start":s0,"duration":sdur},
            target_timerange={"start":t0,"duration":tdur},
            speed=sp,volume=0.0,last_nonzero_volume=1.0,      # MUTE - sources have own audio
            render_index=0,track_render_index=0,
            clip={"scale":{"x":sc,"y":sc},"rotation":0.0,"transform":{"x":0.0,"y":0.0},
                  "flip":{"vertical":False,"horizontal":False},"alpha":1.0},
            uniform_scale={"on":True,"value":1.0})
        segs.append(g)
    song=[m for m in SRC.values() if m['metetype']=='music'][0]
    am=copy.deepcopy(AMAT); am.update(id=UID(),path=song['file_Path'],duration=song['duration'],
        name=os.path.basename(song['file_Path']),local_material_id=str(uuid.uuid4()),
        music_id=str(uuid.uuid4()))
    M['audios'].append(am); arefs=[]
    for kind in AORDER:
        x=copy.deepcopy(AX[kind]); x['id']=UID(); M[kind].append(x); arefs.append(x['id'])
    aseg=copy.deepcopy(ASEG)
    aseg.update(id=UID(),material_id=am['id'],extra_material_refs=arefs,
        source_timerange={"start":0,"duration":song['duration']},
        target_timerange={"start":0,"duration":song['duration']},
        volume=1.0,speed=1.0,render_index=0,track_render_index=1)
    d=copy.deepcopy(base)
    for k,v in M.items(): d['materials'][k]=v
    d['tracks']=[{"id":UID(),"type":"video","flag":0,"attribute":0,"name":"",
                  "is_default_name":True,"segments":segs},
                 {"id":UID(),"type":"audio","flag":0,"attribute":0,"name":"",
                  "is_default_name":True,"segments":[aseg]}]
    d['duration']=max(END,song['duration']); d['fps']=FR
    d['canvas_config']={"ratio":"original","width":a.width,"height":a.height,"background":None}
    json.dump(d,open(a.out,"w"))
    gaps=[(segs[i]['target_timerange']['start']+segs[i]['target_timerange']['duration'])
          -segs[i+1]['target_timerange']['start'] for i in range(len(segs)-1)]
    print(f"segments       : {len(segs)}")
    print(f"gaps/overlaps  : {sum(1 for g in gaps if g!=0)} (max {max(map(abs,gaps)) if gaps else 0} us)")
    print(f"all muted      : {all(s['volume']==0.0 for s in segs)}")
    print(f"timeline end   : {END/1e6:.3f}s   audio {song['duration']/1e6:.3f}s")
    print(f"-> {a.out}  ({os.path.getsize(a.out)/1e6:.2f} MB)")
if __name__=="__main__": main()
