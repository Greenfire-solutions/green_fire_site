#include <ApplicationServices/ApplicationServices.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
int main(int argc,char**argv){
  if(argc<3){fprintf(stderr,"usage: clicker x y [clicks]\n");return 2;}
  double x=atof(argv[1]), y=atof(argv[2]);
  int n=(argc>3)?atoi(argv[3]):1;
  CGPoint p=CGPointMake(x,y);
  CGEventRef mv=CGEventCreateMouseEvent(NULL,kCGEventMouseMoved,p,kCGMouseButtonLeft);
  CGEventPost(kCGHIDEventTap,mv); CFRelease(mv); usleep(120000);
  for(int i=1;i<=n;i++){
    CGEventRef d=CGEventCreateMouseEvent(NULL,kCGEventLeftMouseDown,p,kCGMouseButtonLeft);
    CGEventRef u=CGEventCreateMouseEvent(NULL,kCGEventLeftMouseUp,p,kCGMouseButtonLeft);
    CGEventSetIntegerValueField(d,kCGMouseEventClickState,i);
    CGEventSetIntegerValueField(u,kCGMouseEventClickState,i);
    CGEventPost(kCGHIDEventTap,d); usleep(45000);
    CGEventPost(kCGHIDEventTap,u); usleep(45000);
    CFRelease(d); CFRelease(u);
  }
  CGEventRef chk=CGEventCreate(NULL); CGPoint q=CGEventGetLocation(chk);
  printf("clicked %d at %.0f,%.0f (cursor now %.0f,%.0f)\n",n,x,y,q.x,q.y);
  CFRelease(chk); return 0;
}
