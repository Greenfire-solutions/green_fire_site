#!/usr/bin/env python3
"""Render the EDL with ffmpeg as an independent check. Duration MUST match the song."""
import json, os, subprocess, argparse, re
from concurrent.futures import ThreadPoolExecutor
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--edl",required=True); ap.add_argument("--vid",required=True)
    ap.add_argument("--audio",required=True); ap.add_argument("--out",required=True)
    ap.add_argument("--slow",default=""); ap.add_argument("--w",type=int,default=1280)
    ap.add_argument("--h",type=int,default=720); ap.add_argument("--fps",type=float,default=30.0)
    a=ap.parse_args()
    E=json.load(open(a.edl)); V=json.load(open(a.vid)); FR=a.fps
    SLOW={int(k):float(v) for k,v in (p.split(":") for p in a.slow.split(",") if p)}
    d=os.path.join(os.path.dirname(a.out) or ".","_parts"); os.makedirs(d,exist_ok=True)
    snap=lambda t: round(t*FR)/FR
    starts=[snap(s['start']) for s in E]; END=snap(E[-1]['start']+E[-1]['dur'])
    def job(i):
        s=E[i]; tgt=(starts[i+1] if i+1<len(E) else END)-starts[i]
        N=int(round(tgt*FR)); sp=SLOW.get(i,1.0); o=f"{d}/{i:04d}.mp4"
        if os.path.exists(o) and os.path.getsize(o)>2000: return N
        pre=["-ss",f"{s['t0']:.4f}"]
        if sp!=1.0: pre+=["-t",f"{tgt*sp+0.4:.4f}"]        # limit SOURCE read, never output
        vf=[]; sc=float(V[s['src']].get('scale',1.0))
        if sc>1.02: vf.append(f"crop=iw:ih/{sc}")
        if sp!=1.0: vf.append(f"setpts=PTS/{sp}")
        vf+=[f"scale={a.w}:{a.h}:force_original_aspect_ratio=increase",
             f"crop={a.w}:{a.h}",f"fps={FR}","setsar=1","format=yuv420p"]
        subprocess.run(["ffmpeg","-v","error","-y"]+pre+["-i",V[s['src']]['path'],"-an",
            "-vf",",".join(vf),"-frames:v",str(N),          # exact frame count = no drift
            "-c:v","libx264","-preset","veryfast","-crf","20","-g","30",
            "-video_track_timescale","30000",o],capture_output=True)
        return N
    with ThreadPoolExecutor(6) as ex: Ns=list(ex.map(job,range(len(E))))
    lst=os.path.join(d,"list.txt")
    with open(lst,"w") as f:
        for i in range(len(E)): f.write(f"file '{d}/{i:04d}.mp4'\n")
    subprocess.run(["ffmpeg","-v","error","-y","-f","concat","-safe","0","-i",lst,
        "-i",a.audio,"-map","0:v","-map","1:a","-c:v","copy","-c:a","aac","-b:a","192k",
        a.out],capture_output=True)
    o=subprocess.run(["ffmpeg","-i",a.out],capture_output=True).stderr.decode()
    print(f"frames {sum(Ns)} = {sum(Ns)/FR:.2f}s  target {END:.2f}s")
    print(re.search(r"Duration: [\d:.]+",o).group(0))
    print("If this duration does not match the song, the EDL or render is wrong.")
if __name__=="__main__": main()
