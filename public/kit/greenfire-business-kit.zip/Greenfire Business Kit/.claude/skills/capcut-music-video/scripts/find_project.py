#!/usr/bin/env python3
"""List CapCut drafts newest-first; flag the one currently open and show its media pool."""
import json, os, argparse, datetime
ROOT=os.path.expanduser("~/Movies/CapCut/User Data/Projects/com.lveditor.draft")
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--limit",type=int,default=12)
    ap.add_argument("--project",help="show media pool for this draft name")
    a=ap.parse_args()
    if a.project:
        p=os.path.join(ROOT,a.project)
        m=json.load(open(f"{p}/draft_meta_info.json"))
        print(f"{a.project}  duration={m.get('tm_duration',0)/1e6:.2f}s")
        for g in m.get('draft_materials',[]):
            for x in g.get('value',[]):
                ok="OK " if os.path.exists(x.get('file_Path','')) else "MISSING"
                print(f"  {ok} {x.get('metetype'):<6} {x.get('duration',0)/1e6:>8.2f}s "
                      f"{x.get('width')}x{x.get('height')}  {os.path.basename(x.get('file_Path',''))}")
        tl=f"{p}/Timelines/project.json"
        if os.path.exists(tl): print("  main_timeline_id =",json.load(open(tl)).get('main_timeline_id'))
        return
    rows=[]
    for n in os.listdir(ROOT):
        d=os.path.join(ROOT,n)
        f=os.path.join(d,"draft_info.json")
        if not os.path.isfile(f): continue
        rows.append((os.path.getmtime(f),n,os.path.exists(os.path.join(d,".locked"))))
    for mt,n,lk in sorted(rows,reverse=True)[:a.limit]:
        try:
            di=json.load(open(os.path.join(ROOT,n,"draft_info.json")))
            segs=sum(len(t['segments']) for t in di.get('tracks',[]))
            info=f"{di.get('duration',0)/1e6:>7.2f}s  {segs:>4} segs"
        except Exception: info="  (unreadable)"
        print(f"{'[OPEN] ' if lk else '       '}{n:<14} {info}  "
              f"{datetime.datetime.fromtimestamp(mt):%Y-%m-%d %H:%M}")
    print(f"\nroot: {ROOT}")
if __name__=="__main__": main()
