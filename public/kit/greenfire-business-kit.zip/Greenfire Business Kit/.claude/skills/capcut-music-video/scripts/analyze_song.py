#!/usr/bin/env python3
"""BPM + beat grid + section map, numpy only. Includes a mandatory grid QC gate."""
import numpy as np, json, os, subprocess, argparse
SR=22050; NFFT=2048; HOP=128
def decode(path,work):
    raw=os.path.join(work,"song.raw")
    subprocess.run(["ffmpeg","-v","error","-y","-i",path,"-ac","1","-ar",str(SR),
                    "-f","f32le",raw],check=True)
    return np.fromfile(raw,dtype=np.float32)
def spec(x):
    n=1+(len(x)-NFFT)//HOP
    idx=np.arange(NFFT)[None,:]+HOP*np.arange(n)[:,None]
    return np.abs(np.fft.rfft(x[idx]*np.hanning(NFFT).astype(np.float32),axis=1)).astype(np.float32)
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--audio",required=True)
    ap.add_argument("--out",required=True); a=ap.parse_args()
    os.makedirs(a.out,exist_ok=True)
    x=decode(a.audio,a.out); DUR=len(x)/SR; S=spec(x)
    fr=np.fft.rfftfreq(NFFT,1/SR); esr=SR/HOP
    # per-band normalised flux -> stops hi-hats dominating the tempogram
    edges=np.geomspace(30,10000,25); bands=[]
    for lo,hi in zip(edges[:-1],edges[1:]):
        b=np.log1p(S[:,(fr>=lo)&(fr<hi)].sum(1)*50)
        d=np.maximum(np.diff(b),0); bands.append(d/(d.std()+1e-9))
    oe=np.concatenate([[0],np.mean(bands,axis=0)]); oe=oe-oe.mean()
    def comb(bpm,step=0.25):
        per=60/bpm*esr; best=(-9,0.0)
        for p in np.arange(0,per,step):
            t=np.round(np.arange(p,len(oe)-1,per)).astype(int)
            v=oe[t].mean()
            if v>best[0]: best=(v,p)
        return best
    F=np.abs(np.fft.rfft(oe*np.hanning(len(oe))))
    bp=np.fft.rfftfreq(len(oe),1/esr)*60; sel=(bp>55)&(bp<210)
    coarse=float(bp[sel][np.argmax(F[sel])])
    print(f"Fourier tempogram peak: {coarse:.2f} BPM")
    cands=sorted({round(c,3) for c in (coarse,coarse/2,coarse*2) if 55<=c<=210})
    best=max(((b,)+comb(b) for b in cands),key=lambda r:r[1])
    BPM=max((( b,)+comb(b,0.25) for b in np.arange(best[0]-0.5,best[0]+0.5,0.005)),
            key=lambda r:r[1])
    BPM,score,phase=BPM
    per=60/BPM*esr; beats=np.arange(phase,len(oe)-1,per)/esr; bl=60/BPM
    # ---- QC GATE ----
    pk=[i for i in range(2,len(oe)-2) if oe[i]==max(oe[i-2:i+3]) and oe[i]>np.percentile(oe,97)]
    t=np.array(pk)/esr
    def qc(b,label):
        d=np.abs(t[:,None]-b[None,:]).min(1)
        print(f"  {label:26s} median {np.median(d)*1000:5.0f}ms  <40ms {(d<0.04).mean()*100:3.0f}%")
        return np.median(d)
    print(f"\nBPM={BPM:.4f}  beat={bl*1000:.2f}ms  bar={4*bl:.4f}s")
    m0=qc(beats,"refined grid"); m1=qc(beats+bl/2,"half-beat shifted (ctrl)")
    qc(beats+bl/4,"quarter-beat shifted (ctrl)")
    if not m0 < m1*0.5:
        print("\n*** QC FAILED: grid is no better than the control. BPM is WRONG. ***")
        print("*** Do not build an edit on this grid. ***")
    # ---- structure ----
    def band(lo,hi): return S[:,(fr>=lo)&(fr<hi)].sum(1)
    sub,mid,hi_=band(20,90),band(250,2000),band(2000,11000)
    rms=np.sqrt((S**2).mean(1))
    fsub=np.concatenate([[0],np.maximum(np.diff(np.log1p(sub*50)),0)])
    bi=np.clip((beats*esr).astype(int),0,len(rms)-1)
    kick=np.array([fsub[max(0,i-3):i+5].max() for i in bi])
    db=int(np.argmax([kick[k::4].mean() for k in range(4)]))
    print(f"downbeat offset = {db} (kick-by-beat-of-4: "
          f"{[round(kick[k::4].mean(),2) for k in range(4)]})")
    nz=lambda v:(v-v.min())/(v.max()-v.min()+1e-9)
    bars=[]
    for s in range(db,len(beats)-4,4):
        i0,i1=bi[s],bi[min(s+4,len(beats)-1)]
        bars.append(dict(bar=len(bars),t=float(beats[s]),rms=float(rms[i0:i1].mean()),
            sub=float(sub[i0:i1].mean()),mid=float(mid[i0:i1].mean()),hi=float(hi_[i0:i1].mean())))
    A=np.array([[b['rms'],b['sub'],b['mid'],b['hi']] for b in bars])
    A=(A-A.mean(0))/(A.std(0)+1e-9)
    nov=np.zeros(len(bars))
    for i in range(2,len(bars)-2):
        nov[i]=np.linalg.norm(A[max(0,i-4):i].mean(0)-A[i:i+4].mean(0))
    bounds=[i for i in range(2,len(bars)-2)
            if nov[i]==max(nov[i-2:i+3]) and nov[i]>np.percentile(nov,72)]
    for k in ('rms','sub','mid','hi'):
        v=nz(np.array([b[k] for b in bars]))
        for i,b in enumerate(bars): b[k]=round(float(v[i]),3)
    json.dump(dict(bpm=float(BPM),beat=bl,bar=4*bl,dur=DUR,db_off=db,
        beats=[round(float(b),4) for b in beats],bars=bars,boundaries=bounds),
        open(os.path.join(a.out,"song.json"),"w"))
    print(f"\n{len(bars)} bars, boundaries at {bounds}")
    for b in bars:
        print(f"{b['bar']:>3} {b['t']:>7.2f}s rms{b['rms']:.2f} sub{b['sub']:.2f} "
              f"mid{b['mid']:.2f} hi{b['hi']:.2f} |{'#'*int(b['rms']*34):<34}|"
              +(" <== BOUNDARY" if b['bar'] in bounds else ""))
if __name__=="__main__": main()
