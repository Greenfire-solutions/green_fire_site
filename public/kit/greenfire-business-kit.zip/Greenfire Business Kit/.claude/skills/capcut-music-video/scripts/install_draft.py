#!/usr/bin/env python3
"""Safely install a generated timeline into a CapCut project.

Backs up, quits CapCut, writes BOTH the root index and the active timeline
(Timelines/<main_timeline_id>/draft_info.json), refreshes metadata, relaunches.
"""
import json, os, shutil, subprocess, time, argparse, sys
def quit_capcut():
    subprocess.run(["osascript","-e",'quit app "CapCut"'],capture_output=True)
    for _ in range(25):
        if subprocess.run(["pgrep","-x","CapCut"],capture_output=True).returncode!=0: return True
        time.sleep(1)
    return False
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--project",required=True); ap.add_argument("--draft",required=True)
    ap.add_argument("--backup",default=None); ap.add_argument("--no-relaunch",action="store_true")
    a=ap.parse_args()
    P=a.project.rstrip("/")
    d=json.load(open(a.draft))            # validate before touching anything
    print(f"draft: tracks={[(t['type'],len(t['segments'])) for t in d['tracks']]} "
          f"dur={d['duration']/1e6:.2f}s")
    bak=a.backup or os.path.join(os.path.dirname(P),"_backup_"+os.path.basename(P))
    if os.path.exists(bak): shutil.rmtree(bak)
    shutil.copytree(P,bak); print("backed up ->",bak)
    if not quit_capcut(): sys.exit("CapCut would not quit; aborting (it would overwrite the draft).")
    print("CapCut closed")
    targets=[os.path.join(P,"draft_info.json")]
    tj=os.path.join(P,"Timelines","project.json")
    if os.path.exists(tj):
        mid=json.load(open(tj)).get("main_timeline_id")
        if mid:
            t=os.path.join(P,"Timelines",mid,"draft_info.json")
            if os.path.isdir(os.path.dirname(t)):
                targets.append(t)
            else:
                print(f"WARNING: main_timeline_id {mid} has no folder")
    else:
        print("note: single-timeline project (no Timelines/project.json)")
    lock=os.path.join(P,".locked")
    if os.path.exists(lock): os.remove(lock)
    for t in targets:
        shutil.copyfile(a.draft,t); print("wrote",t)
    if len(targets)==1:
        print("WARNING: only the root index was written. If the editor opens EMPTY, this "
              "project uses the Timelines/ layout and the active file was not found.")
    now=int(time.time()*1e6)
    mp=os.path.join(P,"draft_meta_info.json")
    m=json.load(open(mp)); m['tm_duration']=d['duration']; m['tm_draft_modified']=now
    json.dump(m,open(mp,"w"))
    if os.path.exists(tj):
        pj=json.load(open(tj)); pj['update_time']=now
        for t in pj.get('timelines',[]): t['update_time']=now
        json.dump(pj,open(tj,"w"))
    print(f"metadata updated (duration {d['duration']/1e6:.2f}s)")
    if not a.no_relaunch:
        subprocess.run(["open","-a","CapCut"])
        for _ in range(25):
            if subprocess.run(["pgrep","-x","CapCut"],capture_output=True).returncode==0: break
            time.sleep(1)
        print("CapCut relaunched - now OPEN the project and verify visually")
if __name__=="__main__": main()
