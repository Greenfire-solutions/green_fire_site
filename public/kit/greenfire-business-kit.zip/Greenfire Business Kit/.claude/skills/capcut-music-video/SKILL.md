---
name: capcut-music-video
description: Direct a music video end-to-end in CapCut Desktop by writing the project's draft JSON — analyze the song's BPM/beat grid/structure, triage footage with vision + metrics, design a beat-locked edit with an energy curve, generate the CapCut timeline, and verify it. Use when asked to edit, cut, build, or sync a music video, montage, supercut, or beat-synced edit in CapCut, or to automate/script CapCut Desktop on macOS.
---

# CapCut Music Video Director

Builds a complete, beat-locked music video by writing CapCut's draft JSON directly.
CapCut has **no public API** — the draft file *is* the API.

## Why this exists

Existing tools (see `reference/prior-art.md`) construct drafts: "add clip", "add text".
None make **editorial decisions**. This skill is the director layer: it decides *which*
frames, *how long*, and *in what order*, then writes a real CapCut timeline.

## Non-negotiables

1. **Never claim an edit happened without verifying it.** Screenshot or read back the file.
2. **Quit CapCut before writing.** It holds `.locked` and overwrites the draft on exit.
3. **Back up the project folder first.** Never touch files in the user's media folders.
4. **Mute every video segment** (`volume: 0.0`) — source clips carry their own audio.
5. **QC the beat grid before building anything.** A wrong BPM silently ruins all 185 cuts.

## Prerequisites

```bash
ffmpeg -version                     # required; ffprobe optional
python3 -m pip install --user numpy # required
```
No librosa/scipy needed — `scripts/analyze_song.py` is numpy-only.

## Workflow

### 1. Locate the project
```bash
python3 scripts/find_project.py            # lists drafts by mtime, flags the open one
```
Drafts live in `~/Movies/CapCut/User Data/Projects/com.lveditor.draft/<name>/`.
`.locked` present = currently open in CapCut.

**CRITICAL — multi-timeline layout.** In CapCut 8.9+ the root `draft_info.json` is only an
index. The timeline the editor actually loads is:
```
<project>/Timelines/<main_timeline_id>/draft_info.json
```
where `main_timeline_id` comes from `<project>/Timelines/project.json`.
Write **both**. Writing only the root gives a project that shows the right duration but
opens with an empty timeline. See `reference/capcut-draft-format.md`.

### 2. Analyze the song
```bash
python3 scripts/analyze_song.py --audio SONG --out WORK/
```
Emits `song.json`: BPM, beat grid, downbeat offset, per-bar energy (rms/sub/mid/hi),
and section boundaries from novelty detection.

**The QC gate is mandatory.** The script prints median onset offset for the chosen grid
and for half-beat / quarter-beat shifted controls. A valid grid looks like:
```
refined grid              median   14ms   <40ms 54%
half-beat shifted (ctrl)  median  247ms   <40ms 33%
```
If the real grid isn't dramatically better than the controls, **the BPM is wrong** —
autocorrelation alone routinely fails on trap/hip-hop because hi-hat rolls dominate.
The script uses a Fourier tempogram + comb filter and refines to 0.005 BPM. Sub-0.2 BPM
errors accumulate into visible drift by the end of a 4-minute track.

### 3. Analyze the footage
```bash
python3 scripts/analyze_footage.py --project PROJECT_DIR --out WORK/
```
Decodes every source at 5fps/64×36 into numpy: brightness, saturation, contrast,
motion (frame diff), hue spread, shot-cut boundaries, letterbox/pillarbox detection.
Also writes `sheets/*.jpg` contact sheets.

**Then actually look at the contact sheets.** Metrics cannot tell you a clip is a static
radio interview, has burned-in lyrics, or is a vertical video in a 16:9 frame. Read every
sheet and write down per-source: category, best material, and defects.

**Reject sources outright** when they are: static/talking-head, burned-in text that will
clash, pillarboxed vertical (needs >2× upscale), or resolution far below the timeline.
Cutting 5 of 15 sources produced a better edit than using all 15.

### 4. Design the edit
Author a **section plan** mapping song sections to cut-length patterns in beats.
This is the creative core — do not delegate it to a scoring function.

- **Intro** — long shots (6–8 beats), accelerate into the first drop
- **Drops** — mix 4/2/1-beat cuts so it breathes; never uniform
- **Peaks** — 1-beat cuts where hi-hats/energy max out
- **Half-time / heavy** — 4-beat shots, slower, weightier
- **Breakdowns** — 4–6 beats, atmosphere, let shots live
- **Stabs/fills** — one held shot on a single-bar accent
- **Final drop** — densest section; reserve the strongest footage
- **Outro** — longest shots, resolve

Assign **hero sections first** so they get first pick of the best material.
Set per-source `TARGET` screen-time shares and `BIAS` weights — without them the picker
gravitates to whichever source merely has the most usable footage.

```bash
python3 scripts/build_edl.py --song WORK/song.json --vid WORK/vid.json \
        --plan plan.json --out WORK/edl.json
```

### 5. Proof it visually — before building
```bash
python3 scripts/proof_sheet.py --edl WORK/edl.json --out WORK/proof.jpg
```
One frame per shot, in order. Look for: title cards, blank walls, near-black frames,
one source clumping, motion-blur mush. Fix by extending exclusions / adjusting shares,
then re-proof. Expect to iterate twice.

Note: `-ss` before `-i` is a *fast seek* and can land on a nearby keyframe, so proof
frames are approximate. Confirm suspected defects numerically against the 5fps arrays
before "fixing" something that isn't broken.

### 6. Build and install
```bash
python3 scripts/build_draft.py   --edl WORK/edl.json --project PROJECT_DIR --out WORK/draft_info.json
python3 scripts/install_draft.py --project PROJECT_DIR --draft WORK/draft_info.json
```
`install_draft.py` backs up, quits CapCut, writes root + active timeline, updates
`draft_meta_info.json` / `Timelines/project.json`, and relaunches.

### 7. Verify in CapCut
```bash
clang -O2 -o scripts/capcut_click scripts/capcut_click.c -framework ApplicationServices
scripts/capcut_click X Y 2      # double-click to open the project
screencapture -x shot.png
```
Requires **Accessibility** for the terminal app (System Settings → Privacy & Security →
Accessibility). AppleScript `System Events ... click at` is unreliable in CapCut's CEF
UI and often returns a window reference without clicking — use the CGEvent binary.

Confirm on screen: both tracks present, clip widths varied, audio track named correctly,
total timecode matches the song, and a scrubbed frame renders (proves media links resolve).

### 8. Independent preview
```bash
python3 scripts/render_preview.py --edl WORK/edl.json --audio SONG --out WORK/PREVIEW.mp4
```
Renders the same EDL with ffmpeg. **If its duration doesn't match the song, something is
wrong** — that check caught two real render bugs.

## Editorial rules

- **Hard cuts are the foundation.** Add transitions only where they earn their place.
- **No global grade over already-graded sources.** A blanket LUT across many different
  looks fights them rather than unifying them.
- **Effects last.** Timing and shot choice carry the edit.
- Prefer starting a clip just after a detected shot boundary so each cut is one continuous shot.
- Never place the same source in adjacent shots; cap it at ~3 per 5-shot window.
- Keep any single source under ~18% of total runtime.
- Reserve the strongest, most recognizable footage for the final peak.

## Rights

Supercuts of third-party footage/music are not clearable for commercial release.
State this once, plainly, then do the work — it is the user's call.
