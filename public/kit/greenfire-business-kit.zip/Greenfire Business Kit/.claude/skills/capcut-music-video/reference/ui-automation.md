# Driving CapCut Desktop on macOS

## What works
A compiled CGEvent binary (`capcut_click.c`). Nothing else reliably clicks CapCut.

```bash
clang -O2 -o capcut_click capcut_click.c -framework ApplicationServices
./capcut_click 383 642 2      # x y clicks  (2 = double-click)
```

## What does NOT work
- `osascript -e 'tell application "System Events" to click at {x,y}'`
  Returns a window reference and clicks nothing. CapCut is a Chromium/CEF app, so its
  project grid and timeline are web content with no AX elements to press.
- `open -a CapCut <project>` — CapCut registers **no** CFBundleDocumentTypes.
- `capcut://` URL scheme exists in Info.plist but the project's `draft_deeplink_url`
  field is empty; the format is undocumented. Don't fire guessed URLs at a live app.

## Permissions
Accessibility is required for the process that posts the events, attributed to the
**terminal app** (e.g. Warp/Terminal/iTerm), not to python.

macOS 12: System Preferences → Security & Privacy → Privacy → Accessibility → unlock → add the terminal.
macOS 13+: System Settings → Privacy & Security → Accessibility.

Probe it without clicking:
```bash
osascript -e 'tell application "System Events" to tell process "CapCut" to get position of window 1'
```
Success prints coordinates. Failure is `(-25211) osascript is not allowed assistive access`.
Note: some System Events queries succeed *without* the grant, so probe with a
process-targeted call like the one above, not a generic one.

## Coordinates
`screencapture` on Retina writes a PNG at backing-store resolution (e.g. 3584x2240) while
CGEvent takes **logical** points (e.g. 1792x1120). Divide PNG pixel coords by the scale
factor (usually 2). Verify with the window's own reported geometry:
```bash
osascript -e 'tell application "System Events" to tell process "CapCut" to get size of window 1'
```

## Verification loop
1. `capcut_ui.sh open`
2. screenshot, locate the project card, convert coords
3. `capcut_ui.sh click X Y 2`
4. screenshot; confirm timeline populated
5. click the ruler to scrub; confirm a frame renders (proves media links resolve)
