# Prior art (researched Sep 2026)

**There is no public CapCut API** for timeline editing, rendering, or batch export.
Everything below works by writing CapCut's draft files directly — same approach as this skill.

## Draft-construction libraries
- **pyJianYingDraft** — https://github.com/GuanYixuan/pyJianYingDraft
  Mature Python draft generator for JianYing (CapCut CN). `pip install pyjianyingdraft`.
- **pyCapCut** — https://github.com/GuanYixuan/pyCapCut
  The CapCut-targeted sibling. Tracks, segments, keyframes, masks, text animation,
  SRT import, template mode. Runs on macOS/Linux/Windows for *generation*; auto-export
  is Windows-only and broken on CapCut 7+.
  **Explicitly has no beat detection and no automatic shot selection.**
- **JianYingDraft.PY** — https://pypi.org/project/JianYingDraft.PY/
- Schema cheat sheet — https://gist.github.com/renezander030/80823f1d47081c312d2c1f9edd20dc22

## MCP servers (agent-drivable)
- https://github.com/Atx-Guy/capcut-mcp-server
- https://github.com/Rajbagus/rabbitorial-capcut-mcp
- Others by baizo7, dlyrr, JmsLdrn, migueduque (see glama.ai / pulsemcp listings)

These expose *primitives* — add clip, add audio, add text, add effect — and construct a
draft folder you drop into the drafts directory. They are a good alternative to
`build_draft.py` if you want a maintained dependency. They do **not** decide what to cut.

## Beat-sync products (not agent-drivable, not CapCut-native)
BeatSync PRO, MadSync, Bitcut, OpusClip. These do music analysis and auto-cutting as
closed products; you cannot direct them shot-by-shot or target a CapCut timeline.

## Where this skill differs
The gap in all of the above is **editorial judgment**. This skill adds:
1. Beat grid with a **falsifiable QC gate** (control grids must score worse)
2. Song structure -> section map -> hand-authored cut-length patterns (energy curve)
3. Footage triage combining numeric metrics with **actually looking at contact sheets**,
   including rejecting whole sources
4. Shot selection with target screen-time shares, anti-clustering, and quality floors
5. Verification: visual proof sheet, an independent ffmpeg render whose duration must
   match, and on-screen confirmation in CapCut

If you only need "put these clips on a timeline", use pyCapCut or an MCP server.
Use this skill when the question is *which* frames and *how long*.
