# CapCut draft format (macOS, verified against CapCut 8.9.1 / new_version 175.0.0)

There is no public CapCut API. The draft JSON *is* the API.

## Layout
```
~/Movies/CapCut/User Data/Projects/com.lveditor.draft/
  root_meta_info.json            # registry of all drafts (CapCut rewrites this on exit)
  <ProjectName>/
    .locked                      # present => open in CapCut right now
    draft_info.json              # INDEX ONLY in multi-timeline projects
    draft_meta_info.json         # media pool + tm_duration
    timeline_layout.json         # which timeline ids are docked
    Timelines/
      project.json               # { main_timeline_id, timelines[] }
      <main_timeline_id>/
        draft_info.json          # <-- THE TIMELINE THE EDITOR ACTUALLY LOADS
```

### The multi-timeline trap
Writing only the root `draft_info.json` produces a project whose duration updates in the
project grid but which **opens with an empty timeline**. Resolve the real target:
```python
mid = json.load(open(f"{P}/Timelines/project.json"))["main_timeline_id"]
target = f"{P}/Timelines/{mid}/draft_info.json"
```
Write both. Older single-timeline projects have no `Timelines/` folder — root only.

### Locking
CapCut holds the project and **rewrites the draft on exit**, silently discarding your
changes. Always quit CapCut before writing, and confirm with `pgrep -x CapCut`.

## Segment/material model
One **complete set of materials per segment** — CapCut does not share materials between
segments. 185 video segments produce 185 `videos` entries plus 185 of each extra type.

`extra_material_refs` is an ordered list; order matters.

Video segment refs, in order:
```
speeds, placeholder_infos, canvases, sound_channel_mappings, material_colors, vocal_separations
```
Audio segment refs, in order:
```
speeds, placeholder_infos, beats, sound_channel_mappings, vocal_separations
```

## Fields that matter
| Field | Note |
|---|---|
| `target_timerange` | position on timeline, microseconds |
| `source_timerange` | in-point + length within the source file |
| `volume` | **set 0.0 on every video segment** or all sources play their own audio |
| `speed` + `speeds[].speed` | must agree; `source.duration = target.duration * speed` |
| `clip.scale` | `{x,y}`; use to crop letterbox (2.39:1 in a 16:9 frame ≈ 1.30) |
| `materials.audios[].type` | `extract_music` — CapCut uses this even for imported MP3s |
| `canvas_config` | `{"ratio":"original","width":1920,"height":1080}` |

## Avoiding gaps
Snap every boundary to the project fps, then derive each duration from the *next* start:
```python
us = lambda t: int(round(round(t*fps)/fps * 1e6))
start_i    = us(t_i)
duration_i = us(t_{i+1}) - us(t_i)      # never round durations independently
```
Rounding durations independently accumulates sub-frame drift and leaves 1-frame gaps.

## Getting the schema right
Don't hand-write these dicts. Clone a real segment + its materials from another draft in
the user's own library (`build_draft.py:find_protos`). That guarantees every field the
installed CapCut version expects, with valid defaults, and survives version changes.
