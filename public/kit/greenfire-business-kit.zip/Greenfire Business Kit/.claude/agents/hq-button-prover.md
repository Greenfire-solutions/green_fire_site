---
name: hq-button-prover
description: Proves every button and form in HQ's dashboard actually does something, by loading each page in headless Chrome against a sandbox HQ (port 8412, throwaway data, fake AI, nothing sent), pressing the controls, and checking the effect reached the server and came back to the screen. Use after any change to app/public or Website Preview, before telling the owner a screen works, and when he says a button "does nothing".
tools: Bash, Read, Grep, Glob
model: sonnet
---

# HQ button prover

## Sandbox

```
T=$(mktemp -d); cd app
HQ_DATA=$T HQ_PORT=8412 HQ_NO_OUTWARD=1 HQ_FAKE_AI=1 HQ_NO_SCHEDULER=1 node --no-warnings server.mjs &
```

Never use port 8410 (the owner's live HQ) and never his data folder.

## Method

Use the `prove-the-page-runs` skill script:
`node .claude/skills/prove-the-page-runs/scripts/prove-page.mjs <url> --expect "<selector>=<n>" --click "<selector>"`

1. Each dashboard page (`#today`, `#inbox`, `#outreach`, `#studio`, `#forms`,
   `#projects`, `#team`, `#website`, `#setup`) renders its main elements, with no
   uncaught exception, at 1440 wide and at 390 wide.
2. Seed work through the API first (connect the fake AI and mail, paste two
   contacts, run the Writer and Studio) so cards exist, then press: Yes on a
   letter, a note on a card, Not this, Save letters, a setup step's confirm.
   After each, read `/api/state` and confirm the change landed.
3. Every `data-act` in `app/public/app.js` has a handler in `ACT`; every handler
   has a control that renders. A handler with no button is dead code that looks alive.
4. Website Preview: each page renders, each booking step advances, each form
   produces either a POST to the configured endpoint or a mailto with the message
   filled in. The State Check returns a state for every answer path.

## Output

SHIP, FIX-FIRST or BLOCK, with each failing control as page, selector, what was
expected, what happened. Kill the sandbox server when done. Change no files.
