# Greenfire HQ

A local AI command center for a business owner running one or several offers at
once, plus a library of skills, agents and workflows to build on. Open this
folder in Claude Code and every agent in `.claude/agents` and every skill in
`.claude/skills` is available. New here? Read `BUILD MY DASHBOARD.md`.

## Layout

- `START HERE.command` starts HQ (port 8410) and opens it. `Stop HQ.command` stops it.
- `app/` the HQ server and dashboard. Node 22.13+, zero dependencies, `node:sqlite`.
  - `server.mjs` HTTP API, scheduler, setup checks.
  - `lib/agents.mjs` the seven agents, approve and reply handling.
  - `lib/guards.mjs` every check outgoing words pass. `lib/voice.mjs` caption rules.
  - `lib/seed.mjs` the blank owner profile and the project templates.
  - `lib/mail/` IMAP/SMTP (read-only inbox, app passwords), bounce and auto-reply sorting.
  - `lib/forms.mjs`, `lib/browser.mjs` the form reader and filler (Chrome over a pipe).
  - `public/` the dashboard (plain JS).
  - `test/smoke.mjs` end-to-end test on port 8412, temp data, fake AI, nothing sent.
- `Website Preview/` empty until a website is built for the owner.
- `Playbooks/` how the system sells, and the business interview.
- `CATALOG.md` every skill, agent and workflow in this kit, one line each.
- Data lives in `~/Documents/Greenfire HQ Data` (database, secrets file, backups). Never commit or share it.

## Rules that must hold

- **Agents propose, the owner decides.** Every email, post and form send is a card the
  owner approves. Only two switches act alone (Comment-to-get DMs, form auto-submit),
  both off by default.
- **A yes always lands.** Over the daily cap a send is held, never refused.
- **A reply always shows its outcome** on the card (said / heard / outcome).
- **No agent holds strangers' words, the web and sending together.** The Scout searches
  but sees no mail; the Concierge reads mail but has no web; sending is code on a yes.
- **No long dashes** in anything public. **No claim** that is not on the credentials list.
  **No health, income or results promises** unless the owner's approved wording is in the facts.
- Addresses only from the organisation's own site, never guessed. Filters rank, never delete.
- Test with `cd app && npm test` before trusting any change. Never test against port 8410
  or the real data folder.
