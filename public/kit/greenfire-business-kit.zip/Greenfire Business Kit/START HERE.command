#!/bin/bash
#
#  START HERE: double-click this to open your HQ.
#
#  It finds Node.js (and offers to install it if it is missing), starts HQ in
#  the background, and opens it in your browser. Double-clicking again just
#  opens the page. Closing this window does not stop HQ; "Stop HQ.command" does.
#
#  First time on a new Mac: if macOS says it "cannot be opened", right-click
#  this file, choose Open, then Open again. If double-clicking opens it in a
#  text editor, see READ ME FIRST.txt (one line in Terminal fixes it).
#
set -u
ROOT="$(cd "$(dirname "$0")" && pwd)"
APP="$ROOT/app"
PORT=8410
URL="http://127.0.0.1:$PORT"
LOGDIR="$HOME/Library/Logs/GreenfireHQ"
mkdir -p "$LOGDIR"
LOG="$LOGDIR/server.log"

clear
echo ""
echo "   ●●  HQ"
echo "   ●●  Starting your command center..."
echo ""

dialog() { /usr/bin/osascript -e 'activate' -e "display dialog \"$1\" with title \"HQ\" buttons {\"OK\"} default button 1" >/dev/null 2>&1; }
ask() { /usr/bin/osascript -e 'activate' -e "button returned of (display dialog \"$1\" with title \"HQ\" buttons {\"Not now\", \"$2\"} default button 2)" 2>/dev/null; }

# 1. Node.js 22.13+ (it carries the built-in database HQ uses). Finder gives a bare PATH, so look everywhere.
find_node() {
  for c in /usr/local/bin/node /opt/homebrew/bin/node "$HOME"/.nvm/versions/node/*/bin/node "$HOME/.volta/bin/node" "$HOME/.local/bin/node" $(command -v node 2>/dev/null); do
    [ -x "$c" ] && "$c" --no-warnings --input-type=module -e "await import('node:sqlite')" >/dev/null 2>&1 && { NODE="$c"; return 0; }
  done
  return 1
}
if ! find_node; then
  echo "   HQ needs Node.js (free, from nodejs.org). It is not on this Mac yet."
  if [ "$(ask "HQ needs Node.js, a free program from nodejs.org.\n\nDownload and open the official installer now? Follow its steps, then double-click START HERE again." "Install Node.js")" = "Install Node.js" ]; then
    echo "   Downloading the official Node.js installer..."
    PKG=$(/usr/bin/curl -fsSL https://nodejs.org/dist/latest-v22.x/SHASUMS256.txt | /usr/bin/grep -o 'node-v22[0-9.]*\.pkg' | head -1)
    if [ -n "$PKG" ] && /usr/bin/curl -fL --progress-bar "https://nodejs.org/dist/latest-v22.x/$PKG" -o "/tmp/$PKG"; then
      /usr/bin/open "/tmp/$PKG"
      echo ""; echo "   The installer is open. When it finishes, double-click START HERE again."
    else
      /usr/bin/open "https://nodejs.org/en/download"
      echo "   Opened nodejs.org. Download the macOS installer, run it, then double-click START HERE again."
    fi
  fi
  exit 0
fi
export PATH="$(dirname "$NODE"):$HOME/.local/bin:/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin"
echo "   Node.js $("$NODE" -v) found."

# 2. Is HQ already running? Ask whatever is on the port who it is: liveness is not identity.
who() { /usr/bin/curl -s --max-time 3 "$URL/api/whoami" 2>/dev/null; }
is_ours() { who | /usr/bin/grep -q '"app":"greenfire-hq"' && who | /usr/bin/grep -qF "\"root\":\"$ROOT\""; }
if is_ours; then
  echo "   HQ is already running. Opening it."
  /usr/bin/open "$URL"; sleep 1; exit 0
fi
if /usr/sbin/lsof -ti tcp:$PORT -sTCP:LISTEN >/dev/null 2>&1; then
  if who | /usr/bin/grep -q '"app":"greenfire-hq"'; then dialog "Another copy of HQ is running from a different folder. Quit that one first (Stop HQ in its folder), then start this one."
  else dialog "Port $PORT is being used by a different program, so HQ was not started. Quit that program, then try again."; fi
  exit 1
fi

# 3. Start it in the background, then open the page.
chmod +x "$ROOT/Stop HQ.command" 2>/dev/null
cd "$APP" || exit 1
nohup "$NODE" --no-warnings server.mjs >> "$LOG" 2>&1 &
disown 2>/dev/null
for _ in $(seq 1 40); do is_ours && break; sleep 0.5; done
if is_ours; then
  echo "   HQ is running at $URL"
  echo ""
  echo "   Your browser is opening. Keep this Mac awake for posts and replies to go out."
  echo "   You can close this window."
  /usr/bin/open "$URL"
  sleep 2
else
  dialog "HQ did not start. Details are in ~/Library/Logs/GreenfireHQ/server.log"
  tail -20 "$LOG"
fi
