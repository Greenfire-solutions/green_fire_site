# The business interview

Used by BUILD MY DASHBOARD when there is no Project Brief. Ask one at a time,
in plain words, and write the answers to `My Project Brief.md`.

1. What is your business called, and what do you do, in one sentence?
2. List everything you sell: each offer, its price, and the link where people buy or book it.
3. For each offer: who buys it, and who decides? Where are those people found?
4. Who are your best clients so far, and why did they buy? (No names needed.)
5. What do you do every week that you wish ran itself? Rank the top five.
6. Which email, calendar, social accounts, website and payment tools do you use?
7. What can you truthfully say about yourself: years, numbers, places, names you have worked with? Only things you would put in writing.
8. How do you sound? Paste five to ten things you have written that sound most like you.
9. What must an agent never say or do on your behalf?
10. What would make this worth it in 30 days?
