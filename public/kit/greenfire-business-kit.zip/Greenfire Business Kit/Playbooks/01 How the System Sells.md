# How the system sells

One loop, run for every offer you have:

1. **Know who buys.** Each offer names who decides and where they are found
   (Projects > Audiences). The `audience-finder` skill helps you write them.
2. **Find a few right people.** The Audience Scout searches one audience per
   run and keeps only addresses printed on the organisation's own website,
   each with one true sentence about them.
3. **Write one honest letter.** The Pitch Writer drafts it in your voice: who
   you are in one line, what THEY get, one easy next step. You press yes.
4. **Follow up twice, then stop.** The Follow-up Keeper nudges at 3 and 6
   weeks. Silence after that is an answer.
5. **Answer everyone who writes in.** The Inbox Concierge sorts each message to
   an offer and drafts the reply. Paid work with a date comes first.
6. **Show up where they look.** Studio turns what you drop in `Drop Media Here`
   into posts with a weekly shape, and Comment-to-get turns attention into a
   private link.
7. **Read the week.** The Chief of Staff's morning brief says what is waiting
   for you and what moved. Change the offer, not the effort, when a loop is
   quiet for a month.

The rules that keep this safe are in `CLAUDE.md`. The numbers you quote come
only from your credentials list (`measured-not-inferred` explains why).
