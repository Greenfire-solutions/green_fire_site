# Build my AI dashboard

Copy everything below the line into Claude Code, opened in this folder.
Your **Project Brief** (the document from your Greenfire activation form,
step 6) should be in your project folder, the folder this kit sits in, or in
this folder next to this file. Either place works.

---

You are setting up my AI dashboard and agents. This folder is the Greenfire
Business Kit: a working command center (HQ) plus a library of skills, agents,
scripts and workflows. Your job is to build MY version of it, for my business,
from what is already here. Work in this order and do not skip the checks.

## 1. Learn my business

1. Find my Project Brief: a file whose name ends in "Project Brief" (Word, PDF
   or text), in this folder or in the folder that holds this kit. Read every
   word. If there is no brief, stop
   and ask me the questions in `Playbooks/02 The Business Interview.md`, one at
   a time, and write my answers to `My Project Brief.md` before going on.
2. From the brief, write down for yourself: what I sell (each offer, its
   price, its link), who buys each one and who decides, where those people are
   found, how I sound, what I can truthfully claim, what I do every week that I
   want off my plate, and what tools and accounts I already use.
3. Show me that summary in plain words and ask me to correct it. Do not build
   on anything I have not confirmed.

## 2. Read the whole kit before choosing anything

1. Read `CATALOG.md`. It lists every skill, agent, script and workflow in this
   kit, what each does, and where it lives.
2. Read every `SKILL.md` in `.claude/skills/` and every agent in
   `.claude/agents/` that the catalog marks as relevant to anything in my
   summary. Read `CLAUDE.md` for the rules that must hold.
3. Read `app/lib/agents.mjs` (the seven HQ agents) and `app/lib/seed.mjs` (the
   blank owner profile and project templates).
4. Make a table for me: each job I want off my plate, the kit piece that does
   it (skill, agent, HQ agent or script, by its exact name), and what that
   piece still needs from me (an account, a password, a choice). Mark anything
   the kit cannot do yet as **NOT IN THE KIT**. Never pretend a piece exists.

## 3. Fill in my HQ

1. Start HQ once (double-click `START HERE`, or `cd app && npm start`) so it
   creates its data folder, then stop it.
2. Fill my profile and projects through HQ's own screens or its API, never by
   editing the database by hand: my name, business, city, links, short and
   long bio, the credentials I confirmed (the ONLY claims agents may make),
   how I sound and 5 to 10 lines in my own words.
3. Add one project per offer, with its price, link, who buys it, the
   audiences to search (`label | exact search description`), the facts agents
   may use, and a Comment-to-get keyword if I want one.
4. Anything you are not sure of goes in `verify` on my profile, unticked, so
   no agent says it until I tick it.

## 4. Build what is missing, from the kit's own parts

For each row in your table that needs more than settings:

1. Reuse first. Copy or adapt the closest skill, agent or script in this kit.
   Say which one you started from.
2. Keep the kit's rules: agents propose and I decide; nothing is emailed,
   posted or submitted without my yes; addresses only from an organisation's
   own website, never guessed; no claim that is not on my credentials list;
   filters rank and never delete.
3. Put new skills in `.claude/skills/<name>/SKILL.md` and new agents in
   `.claude/agents/<name>.md`, in the same shape as the ones already there.
4. Add each new piece to `CATALOG.md`.

## 5. Prove it works

1. Run `cd app && npm test`. It must pass. Fix what fails; never weaken a test.
2. Use the `prove-the-page-runs` skill on HQ's dashboard and on any page you
   built. A page is working when its parts render, not when its text exists.
3. Start HQ, open Setup, and walk me through the steps that need me (connect
   email, Claude, social accounts). Tell me exactly what to click.

## 6. Hand it to me

Give me one short page, in plain words:

- what HQ now does for me each day and each week, by agent;
- what is waiting for my yes and where I press it;
- what still needs me (accounts, passwords, choices), as a numbered list;
- what is NOT IN THE KIT yet and would need a custom build.

Never use long dashes in anything I will read or send.
